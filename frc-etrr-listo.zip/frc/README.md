# FRC Virtual Hub · ETRR

Plataforma de gestión del equipo FRC: tareas, equipo, planificación (fases e hitos), actividad y cuentas con roles
(`admin`, `profesor`, `referente`, `estudiante`). Next.js 16 · React 19 · Tailwind 4 · Postgres · better-auth.

## Puesta en marcha

```bash
pnpm install
cp .env.example .env.local        # completá DATABASE_URL, BETTER_AUTH_SECRET y SEED_ADMINS
pnpm db:setup                     # crea tablas (db/schema.sql) y datos iniciales (db/seed.sql)
pnpm dev                          # http://localhost:3000
```

Al abrir `/sign-in` se crean las cuentas admin definidas en `SEED_ADMINS` (si no existen).
Las contraseñas **no** viven en el código: usá variables de entorno y cambiá cualquier contraseña
que haya estado en el repo anterior.

## Estructura

| Carpeta | Contenido |
|---|---|
| `app/(frc)/` | Páginas: panel, tareas, equipo, planificación, actividad, configuración, documentación y capacitación |
| `app/actions/` | Server actions (tareas, equipo/fases/hitos, cuentas) |
| `lib/frc/` | Sesión, roles, permisos (`permissions.ts`), cálculo de avance y auditoría |
| `db/` | `schema.sql` (idempotente) y `seed.sql` |
| `app/ecodesafio`, `app/api/ecodesafio` | Módulo anterior (Ecodesafío) |

## Pendiente / ideas

- Documentación y Capacitación: la tabla `frc_training_modules` existe, falta la interfaz.
- BOM / inventario, diseño de subsistemas y simulador de arena (mencionados en el sitio publicado).
- Migrar el SQL crudo a consultas tipadas de Drizzle.
