export type PlatformRole = 'admin' | 'profesor' | 'referente' | 'estudiante'

export const ROLE_LABELS: Record<PlatformRole, string> = {
  admin: 'Administrador',
  profesor: 'Profesor / mentor',
  referente: 'Referente de área',
  estudiante: 'Estudiante',
}

// Legacy Ecodesafío values are mapped without rewriting existing rows.
export function normalizeRole(value: unknown): PlatformRole {
  if (value === 'admin' || value === 'profesor' || value === 'referente' || value === 'estudiante') return value
  if (value === 'coordinacion') return 'profesor'
  return 'estudiante'
}

export const TASK_STATUSES = ['Pendiente', 'En curso', 'Bloqueada', 'En revisión', 'Completada', 'Cancelada'] as const
export type TaskStatus = (typeof TASK_STATUSES)[number]

export const TASK_PRIORITIES = ['Baja', 'Media', 'Alta', 'Crítica'] as const
export type TaskPriority = (typeof TASK_PRIORITIES)[number]

export const PRIORITY_WEIGHT: Record<TaskPriority, number> = { Baja: 1, Media: 2, Alta: 3, Crítica: 5 }

export const TEAM_ROLES = [
  'Capitán',
  'Líder de mecánica',
  'Líder de electrónica',
  'Líder de programación',
  'Líder de estrategia',
  'Integrante',
  'Mentor',
] as const
