import 'server-only'
import { cache } from 'react'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { sql } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { normalizeRole, type PlatformRole } from './roles'

export const PROJECT_ID = 1

export type FrcContext = {
  userId: string
  name: string
  email: string
  role: PlatformRole
  memberId: number | null
  leadSubsystemIds: number[]
}

async function loadContext(): Promise<FrcContext | null> {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return null
  const role = normalizeRole((session.user as { role?: string }).role)
  const member = await db.execute(
    sql`SELECT id FROM frc_team_members WHERE user_id = ${session.user.id} AND project_id = ${PROJECT_ID} LIMIT 1`,
  )
  const memberId = member.rows[0] ? Number(member.rows[0].id) : null
  let leadSubsystemIds: number[] = []
  if (memberId) {
    const leads = await db.execute(
      sql`SELECT subsystem_id FROM frc_member_subsystems WHERE member_id = ${memberId} AND is_lead = true`,
    )
    leadSubsystemIds = leads.rows.map((r) => Number(r.subsystem_id))
  }
  return {
    userId: session.user.id,
    name: session.user.name,
    email: session.user.email,
    role,
    memberId,
    leadSubsystemIds,
  }
}

export const getContext = cache(loadContext)

export async function requirePageContext() {
  const ctx = await getContext()
  if (!ctx) redirect('/sign-in')
  return ctx
}

export async function requireActionContext() {
  const ctx = await getContext()
  if (!ctx) throw new Error('No autorizado')
  return ctx
}
