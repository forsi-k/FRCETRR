import 'server-only'
import { sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import { PROJECT_ID } from './session'
import { weightedProgress, type ProgressTask } from './progress'

const str = (v: unknown) => (v === null || v === undefined ? null : String(v))
const num = (v: unknown) => (v === null || v === undefined ? null : Number(v))

export type Project = {
  id: number
  name: string
  institution: string
  competition: string
  season: string
  kickoffDate: string | null
  teamNumber: string | null
  eventName: string | null
  eventDate: string | null
  objective: string
  overloadOpen: number
  overloadCritical: number
}

export async function getProject(): Promise<Project> {
  const r = await db.execute(sql`SELECT *, kickoff_date::text AS kd, event_date::text AS ed FROM frc_projects WHERE id = ${PROJECT_ID}`)
  const p = r.rows[0]
  return {
    id: Number(p.id),
    name: String(p.name),
    institution: String(p.institution),
    competition: String(p.competition),
    season: String(p.season),
    kickoffDate: str(p.kd),
    teamNumber: str(p.team_number),
    eventName: str(p.event_name),
    eventDate: str(p.ed),
    objective: String(p.objective),
    overloadOpen: Number(p.overload_open_threshold),
    overloadCritical: Number(p.overload_critical_threshold),
  }
}

export type Subsystem = { id: number; name: string; parentId: number | null; sort: number }

export async function getSubsystems(): Promise<Subsystem[]> {
  const r = await db.execute(
    sql`SELECT id, name, parent_id, sort FROM frc_subsystems WHERE project_id = ${PROJECT_ID} ORDER BY COALESCE(parent_id, id), parent_id NULLS FIRST, sort, id`,
  )
  return r.rows.map((s) => ({ id: Number(s.id), name: String(s.name), parentId: num(s.parent_id), sort: Number(s.sort) }))
}

export type Member = {
  id: number
  userId: string | null
  fullName: string
  email: string | null
  teamRole: string
  primarySubsystemId: number | null
  availability: string
  status: string
  skills: string[]
  isDemo: boolean
  subsystems: { id: number; isLead: boolean }[]
  accountRole: string | null
}

export async function getMembers(): Promise<Member[]> {
  const r = await db.execute(sql`
    SELECT m.*, u.role AS account_role,
      COALESCE((SELECT json_agg(json_build_object('id', ms.subsystem_id, 'isLead', ms.is_lead))
                FROM frc_member_subsystems ms WHERE ms.member_id = m.id), '[]') AS subs
    FROM frc_team_members m LEFT JOIN "user" u ON u.id = m.user_id
    WHERE m.project_id = ${PROJECT_ID}
    ORDER BY m.participation_status, m.full_name`)
  return r.rows.map((m) => ({
    id: Number(m.id),
    userId: str(m.user_id),
    fullName: String(m.full_name),
    email: str(m.email),
    teamRole: String(m.team_role),
    primarySubsystemId: num(m.primary_subsystem_id),
    availability: String(m.availability),
    status: String(m.participation_status),
    skills: (m.skills as string[]) ?? [],
    isDemo: Boolean(m.is_demo),
    subsystems: (m.subs as { id: number; isLead: boolean }[]) ?? [],
    accountRole: str(m.account_role),
  }))
}

export type Task = ProgressTask & {
  id: number
  title: string
  description: string
  ownerMemberId: number | null
  ownerName: string | null
  subsystemId: number | null
  subsystemName: string | null
  phaseId: number | null
  phaseName: string | null
  milestoneId: number | null
  blockedReason: string | null
  startDate: string | null
  dueDate: string | null
  deliverable: string
  verifiedBy: string | null
  collaboratorIds: number[]
  dependsOnIds: number[]
  subtaskCount: number
  isDemo: boolean
  updatedAt: string
}

export async function getTasks(): Promise<Task[]> {
  const r = await db.execute(sql`
    SELECT t.*, t.start_date::text AS sd, t.due_date::text AS dd, t.verified_at::text AS va, t.updated_at::text AS ua,
      m.full_name AS owner_name, s.name AS subsystem_name, p.name AS phase_name,
      COALESCE((SELECT array_agg(member_id) FROM frc_task_collaborators c WHERE c.task_id = t.id), '{}') AS collabs,
      COALESCE((SELECT array_agg(depends_on_id) FROM frc_task_dependencies d WHERE d.task_id = t.id), '{}') AS deps,
      (SELECT count(*) FROM frc_tasks st WHERE st.parent_task_id = t.id) AS subtask_count
    FROM frc_tasks t
    LEFT JOIN frc_team_members m ON m.id = t.owner_member_id
    LEFT JOIN frc_subsystems s ON s.id = t.subsystem_id
    LEFT JOIN frc_phases p ON p.id = t.phase_id
    WHERE t.project_id = ${PROJECT_ID}
    ORDER BY t.due_date NULLS LAST, t.id`)
  return r.rows.map((t) => ({
    id: Number(t.id),
    title: String(t.title),
    description: String(t.description),
    ownerMemberId: num(t.owner_member_id),
    ownerName: str(t.owner_name),
    subsystemId: num(t.subsystem_id),
    subsystemName: str(t.subsystem_name),
    phaseId: num(t.phase_id),
    phaseName: str(t.phase_name),
    milestoneId: num(t.milestone_id),
    parentTaskId: num(t.parent_task_id),
    priority: String(t.priority),
    status: String(t.status),
    blockedReason: str(t.blocked_reason),
    startDate: str(t.sd),
    dueDate: str(t.dd),
    deliverable: String(t.deliverable),
    acceptanceCriteria: String(t.acceptance_criteria),
    verifiedAt: str(t.va),
    verifiedBy: str(t.verified_by),
    collaboratorIds: ((t.collabs as number[]) ?? []).map(Number),
    dependsOnIds: ((t.deps as number[]) ?? []).map(Number),
    subtaskCount: Number(t.subtask_count),
    isDemo: Boolean(t.is_demo),
    updatedAt: String(t.ua),
  }))
}

export type Comment = { id: number; authorName: string; body: string; createdAt: string }
export type AuditEntry = { id: number; actorName: string; action: string; summary: string; createdAt: string; entityType: string; entityId: number | null }

export async function getTaskActivity(taskId: number) {
  const [comments, history] = await Promise.all([
    db.execute(sql`SELECT id, author_name, body, created_at::text AS ca FROM frc_task_comments WHERE task_id = ${taskId} ORDER BY created_at`),
    db.execute(
      sql`SELECT id, actor_name, action, summary, created_at::text AS ca, entity_type, entity_id FROM frc_audit_logs WHERE entity_type = 'task' AND entity_id = ${taskId} ORDER BY created_at DESC LIMIT 30`,
    ),
  ])
  return {
    comments: comments.rows.map((c) => ({ id: Number(c.id), authorName: String(c.author_name), body: String(c.body), createdAt: String(c.ca) })) as Comment[],
    history: history.rows.map(mapAudit),
  }
}

const mapAudit = (a: Record<string, unknown>): AuditEntry => ({
  id: Number(a.id),
  actorName: String(a.actor_name),
  action: String(a.action),
  summary: String(a.summary),
  createdAt: String(a.ca),
  entityType: String(a.entity_type),
  entityId: num(a.entity_id),
})

export async function getRecentAudit(limit = 12) {
  const r = await db.execute(
    sql`SELECT id, actor_name, action, summary, created_at::text AS ca, entity_type, entity_id FROM frc_audit_logs ORDER BY created_at DESC LIMIT ${limit}`,
  )
  return r.rows.map(mapAudit)
}

export type Milestone = {
  id: number
  phaseId: number
  title: string
  description: string
  dueDate: string | null
  acceptanceCriteria: string
  status: string
  achievedAt: string | null
  isDemo: boolean
  progress: number | null
  taskCount: number
}

export type Phase = {
  id: number
  name: string
  description: string
  sort: number
  plannedStart: string | null
  plannedEnd: string | null
  actualStart: string | null
  actualEnd: string | null
  isDemo: boolean
  progress: number | null
  taskCount: number
  milestones: Milestone[]
}

export async function getPhases(tasks?: Task[]): Promise<Phase[]> {
  const allTasks = tasks ?? (await getTasks())
  const [phases, milestones] = await Promise.all([
    db.execute(sql`SELECT *, planned_start::text AS ps, planned_end::text AS pe, actual_start::text AS ast, actual_end::text AS aen
                   FROM frc_phases WHERE project_id = ${PROJECT_ID} ORDER BY sort, id`),
    db.execute(sql`SELECT ml.*, ml.due_date::text AS dd, ml.achieved_at::text AS aa FROM frc_milestones ml
                   JOIN frc_phases p ON p.id = ml.phase_id WHERE p.project_id = ${PROJECT_ID} ORDER BY ml.due_date NULLS LAST, ml.id`),
  ])
  const ms: Milestone[] = milestones.rows.map((m) => {
    const linked = allTasks.filter((t) => t.milestoneId === Number(m.id))
    return {
      id: Number(m.id),
      phaseId: Number(m.phase_id),
      title: String(m.title),
      description: String(m.description),
      dueDate: str(m.dd),
      acceptanceCriteria: String(m.acceptance_criteria),
      status: String(m.status),
      achievedAt: str(m.aa),
      isDemo: Boolean(m.is_demo),
      progress: weightedProgress(linked),
      taskCount: linked.length,
    }
  })
  return phases.rows.map((p) => {
    const linked = allTasks.filter((t) => t.phaseId === Number(p.id))
    return {
      id: Number(p.id),
      name: String(p.name),
      description: String(p.description),
      sort: Number(p.sort),
      plannedStart: str(p.ps),
      plannedEnd: str(p.pe),
      actualStart: str(p.ast),
      actualEnd: str(p.aen),
      isDemo: Boolean(p.is_demo),
      progress: weightedProgress(linked),
      taskCount: linked.length,
      milestones: ms.filter((m) => m.phaseId === Number(p.id)),
    }
  })
}

export async function getAccounts() {
  const r = await db.execute(sql`SELECT id, name, email, role FROM "user" ORDER BY "createdAt"`)
  return r.rows.map((u) => ({ id: String(u.id), name: String(u.name), email: String(u.email), role: String(u.role) }))
}
