import type { FrcContext } from './session'

type TaskScope = { ownerMemberId: number | null; collaboratorIds: number[]; subsystemId: number | null }

const isStaff = (ctx: Pick<FrcContext, 'role'>) => ctx.role === 'admin' || ctx.role === 'profesor'

export const can = {
  configure: (ctx: Pick<FrcContext, 'role'>) => ctx.role === 'admin',
  manageTeam: isStaff,
  managePlanning: isStaff,
  deleteCritical: isStaff,
  verifyMilestone: isStaff,

  createTask: (ctx: FrcContext, subsystemId: number | null) =>
    isStaff(ctx) || (ctx.role === 'referente' && subsystemId !== null && ctx.leadSubsystemIds.includes(subsystemId)),

  editTask: (ctx: FrcContext, task: TaskScope) =>
    isStaff(ctx) ||
    (ctx.role === 'referente' && task.subsystemId !== null && ctx.leadSubsystemIds.includes(task.subsystemId)),

  // Status changes and comments: anyone who manages the task, plus its owner and collaborators.
  workOnTask: (ctx: FrcContext, task: TaskScope) =>
    can.editTask(ctx, task) ||
    (ctx.memberId !== null && (task.ownerMemberId === ctx.memberId || task.collaboratorIds.includes(ctx.memberId))),

  verifyTask: (ctx: FrcContext, task: TaskScope) => can.editTask(ctx, task),
}
