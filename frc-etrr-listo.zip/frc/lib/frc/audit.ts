import 'server-only'
import { sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import type { FrcContext } from './session'

export async function audit(
  ctx: FrcContext,
  entry: { action: string; entityType: string; entityId?: number | null; summary: string; changes?: unknown },
) {
  await db.execute(
    sql`INSERT INTO frc_audit_logs (actor_user_id, actor_name, actor_role, action, entity_type, entity_id, summary, changes)
        VALUES (${ctx.userId}, ${ctx.name}, ${ctx.role}, ${entry.action}, ${entry.entityType}, ${entry.entityId ?? null}, ${entry.summary}, ${entry.changes ? JSON.stringify(entry.changes) : null}::jsonb)`,
  )
}
