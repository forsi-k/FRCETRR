import { PRIORITY_WEIGHT, type TaskPriority } from './roles'

export type ProgressTask = {
  priority: string
  status: string
  acceptanceCriteria: string
  verifiedAt: string | null
  parentTaskId: number | null
}

export const PROGRESS_RULES = [
  'Peso por prioridad: Baja 1, Media 2, Alta 3, Crítica 5.',
  'Las tareas canceladas y las subtareas no suman al cálculo (las subtareas cuentan dentro de su tarea padre).',
  'Una tarea cuenta como hecha cuando está Completada y, si tiene criterios de aceptación, además fue verificada.',
  'Avance = suma de pesos de tareas hechas / suma de pesos de tareas válidas. Nadie lo carga a mano.',
  'Un hito solo pasa a Alcanzado con verificación explícita de profesor o administrador.',
]

export const taskWeight = (priority: string) => PRIORITY_WEIGHT[priority as TaskPriority] ?? 2

export const isTaskDone = (t: ProgressTask) =>
  t.status === 'Completada' && (!t.acceptanceCriteria.trim() || t.verifiedAt !== null)

export function weightedProgress(tasks: ProgressTask[]) {
  const valid = tasks.filter((t) => t.status !== 'Cancelada' && t.parentTaskId === null)
  const total = valid.reduce((sum, t) => sum + taskWeight(t.priority), 0)
  if (total === 0) return null
  const done = valid.filter(isTaskDone).reduce((sum, t) => sum + taskWeight(t.priority), 0)
  return Math.round((done / total) * 100)
}

export const todayISO = () => new Date().toISOString().slice(0, 10)

export const isOverdue = (dueDate: string | null, status: string) =>
  !!dueDate && dueDate < todayISO() && status !== 'Completada' && status !== 'Cancelada'
