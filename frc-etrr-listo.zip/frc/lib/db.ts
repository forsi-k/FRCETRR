import { drizzle } from 'drizzle-orm/node-postgres'
import { Pool } from 'pg'

const connectionString = process.env.DATABASE_URL

// Key the dev cache by connection string so a pool created before DATABASE_URL
// was available (which falls back to PG* vars without SSL) is not reused.
const globalForDb = globalThis as unknown as { pool?: Pool; poolUrl?: string }

function createPool() {
  return new Pool({ connectionString })
}

export const pool =
  globalForDb.pool && globalForDb.poolUrl === connectionString ? globalForDb.pool : createPool()

if (process.env.NODE_ENV !== 'production') {
  globalForDb.pool = pool
  globalForDb.poolUrl = connectionString
}

export const db = drizzle(pool)
