import { sql } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'

type AdminAccount = { email: string; password: string; name: string }

// Las cuentas de administrador se definen en la variable de entorno SEED_ADMINS
// (JSON). Nunca van en el código. La función es idempotente: si la cuenta ya
// existe no vuelve a crearla ni toca su contraseña.
function readAdminAccounts(): AdminAccount[] {
  const raw = process.env.SEED_ADMINS
  if (!raw) return []
  try {
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed)
      ? parsed.filter((a) => a && typeof a.email === 'string' && typeof a.password === 'string' && typeof a.name === 'string')
      : []
  } catch {
    console.error('SEED_ADMINS no es un JSON válido')
    return []
  }
}

export async function ensureAdmins() {
  for (const account of readAdminAccounts()) {
    const email = account.email.trim().toLowerCase()
    const existing = await db.execute(sql`SELECT id FROM "user" WHERE email = ${email}`)
    if (existing.rows[0]) continue
    const result = await auth.api.signUpEmail({ body: { email, password: account.password, name: account.name } })
    const userId = result.user?.id
    if (userId) {
      await db.execute(sql`UPDATE "user" SET role = 'admin' WHERE id = ${userId}`)
    }
  }
}
