import { sql } from 'drizzle-orm'
import { db } from '@/lib/db'

export async function logActivity(
  actor: { name: string; role: string },
  action: string,
  entityType: string,
  entityLabel: string,
  detail?: string,
) {
  await db.execute(
    sql`INSERT INTO ecodesafio_activity_log (actor_name, actor_role, action, entity_type, entity_label, detail) VALUES (${actor.name}, ${actor.role}, ${action}, ${entityType}, ${entityLabel}, ${detail ?? null})`,
  )
}
