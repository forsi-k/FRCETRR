'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Activity, ArrowDownAZ, Cpu, ArrowUpAZ, CalendarClock, CalendarDays, Check, ClipboardList, Flag, GanttChart, Gift, HandCoins, Handshake, LayoutDashboard, LogOut, Menu, Package, Pencil, Plus, Search, Shield, Target, Trash2, User, Users, Wrench, X, Zap } from 'lucide-react'
import { jsPDF } from 'jspdf'
import { utils, writeFile } from 'xlsx'
import { authClient } from '@/lib/auth-client'
import { createAccount, deleteAccount, updateAccount } from '@/app/actions/users'

type Status = 'Completada' | 'En curso' | 'Pendiente' | 'Bloqueada'
type Area = 'Chasis' | 'Carrocería' | 'Pedales' | 'Dirección-Transmisión' | 'Electricidad'
type Role = 'admin' | 'coordinacion' | 'member'
type TeamRole = 'lider' | 'colaborador'
type Task = { id: number|string; title: string; area: Area; owner: string; due: string; startedAt?: string; status: Status; priority: string; progress: number }
type Tool = { id: number|string; tool: string; quantity: number; installed?: boolean }
type ModalType = 'task'|'tool'|'milestone'|'account'|'sponsor'|null
type Member = { id: string; name: string; role: Role; area: string; teamRole: TeamRole; initials: string }
type Account = { id: string; name: string; email: string; role: Role; area: string; teamRole: TeamRole }
type Milestone = { id: number|string; title: string; eventDate: string; tone: string; taskId?: number|string }
type Sponsor = { id: number|string; name: string; contribution: string; kind: 'Físico'|'Dinero'|'Servicio'; amount: number|string }
type LogEntry = { id: number|string; actorName: string; actorRole: string; action: string; entityType: string; entityLabel: string; detail?: string; createdAt: string }
const areas: Area[] = ['Chasis','Carrocería','Pedales','Dirección-Transmisión','Electricidad']
const seedTasks: Task[] = []
type SessionStatus = 'Pendiente'|'Cumplido'|'Parcial'|'No cumplido'
type DeliverableArea = 'Mecánica'|'Electrónica'|'Electricidad'
type Deliverable = { id: number; area: DeliverableArea; description: string; status: SessionStatus; comment: string; definedBy: string|null; reportedBy: string|null; updatedAt: string }
type WorkSession = { id: number|string; date: string; hours: number; deliverable: string; notes: string; deliverables: Deliverable[] }
const sessionStatuses: SessionStatus[] = ['Pendiente','Parcial','Cumplido','No cumplido']
const nav = [{label:'Resumen',icon:LayoutDashboard},{label:'Tareas',icon:ClipboardList},{label:'Jornadas',icon:Flag},{label:'Planificación',icon:GanttChart},{label:'Herramientas',icon:Wrench},{label:'Equipo',icon:Users},{label:'Sponsors',icon:Gift},{label:'Actividad',icon:Activity,adminOnly:true}]
const formatLogDate=(iso:string)=>{const d=new Date(iso);return d.toLocaleDateString('es-AR',{day:'2-digit',month:'short'})+' · '+d.toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'})}
const statusProgress = (s:Status) => s === 'Completada' ? 100 : s === 'En curso' ? 50 : s === 'Bloqueada' ? 25 : 0
const initialsOf = (name:string) => name.trim().split(/\s+/).slice(0,2).map(w=>w[0]?.toUpperCase()??'').join('')||'??'
const ownersOf = (owner:string) => owner ? owner.split(',').map(s=>s.trim()).filter(Boolean) : []
function RaceCountdown(){
 const raceLabel='5 de noviembre'
 const [daysLeft,setDaysLeft]=useState<number|null>(null)
 useEffect(()=>{
  const computeDays=()=>{
   const now=new Date();const today=new Date(now.getFullYear(),now.getMonth(),now.getDate())
   let race=new Date(today.getFullYear(),10,5)
   if(race<today)race=new Date(today.getFullYear()+1,10,5)
   setDaysLeft(Math.round((race.getTime()-today.getTime())/86400000))
  }
  computeDays()
  const id=setInterval(computeDays,1000*60*60)
  return ()=>clearInterval(id)
 },[])
 return <div className="race-countdown"><div className="race-countdown-icon"><Flag size={16}/></div><div className="race-countdown-copy"><span>Faltan para la carrera</span><strong>{daysLeft===null?'—':daysLeft===0?'¡Es hoy!':daysLeft===1?'1 día':`${daysLeft} días`}</strong><small>{raceLabel}</small></div></div>
}
function OwnerPicker({members,name,initialSelected}:{members:Member[];name:string;initialSelected:string[]}){
 const [selected,setSelected]=useState<string[]>(initialSelected)
 const [query,setQuery]=useState('')
 const [open,setOpen]=useState(false)
 const filtered=members.filter(m=>!selected.includes(m.name)&&m.name.toLowerCase().includes(query.trim().toLowerCase()))
 const addOwner=(nm:string)=>{setSelected(current=>current.includes(nm)?current:[...current,nm]);setQuery('');setOpen(false)}
 return <div className="owner-picker">
  <div className="owner-chips">
   {selected.map(nm=><span className="owner-chip" key={nm}>{nm}<input type="hidden" name={name} value={nm}/><button type="button" onClick={()=>setSelected(current=>current.filter(s=>s!==nm))} aria-label={`Quitar ${nm}`}><X size={12}/></button></span>)}
   <div className="owner-search">
    <Search size={14}/>
    <input type="text" value={query} placeholder={members.length?'Escribí un nombre...':'No hay integrantes cargados'} disabled={members.length===0} onChange={e=>{setQuery(e.target.value);setOpen(true)}} onFocus={()=>setOpen(true)} onBlur={()=>setTimeout(()=>setOpen(false),150)} onKeyDown={e=>{if(e.key==='Enter'){e.preventDefault();if(filtered[0])addOwner(filtered[0].name)}}}/>
   </div>
  </div>
  {open&&members.length>0&&<div className="owner-suggestions">{filtered.length===0?<span className="owner-empty">{query?'Sin resultados':'Ya agregaste a todos'}</span>:filtered.map(m=><button type="button" key={m.id} onMouseDown={e=>e.preventDefault()} onClick={()=>addOwner(m.name)}>{m.name}</button>)}</div>}
 </div>
}
const monthNames=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
const toDate2026=(month:string,day:string)=>month&&day?`2026-${month}-${day}`:''
function DateFields({prefix,defaultValue,required}:{prefix:string;defaultValue?:string;required?:boolean}){const dd=defaultValue?defaultValue.slice(8,10):'',mm=defaultValue?defaultValue.slice(5,7):'';return <div className="date-fields-pair"><select name={`${prefix}Day`} defaultValue={dd} required={required}><option value="">Día</option>{Array.from({length:31},(_,i)=>String(i+1).padStart(2,'0')).map(d=><option key={d} value={d}>{d}</option>)}</select><select name={`${prefix}Month`} defaultValue={mm} required={required}><option value="">Mes</option>{monthNames.map((m,i)=><option key={m} value={String(i+1).padStart(2,'0')}>{m}</option>)}</select></div>}
function badge(s:Status){return <span className={`status-badge ${s==='Completada'?'badge-success':s==='En curso'?'badge-warning':s==='Bloqueada'?'badge-danger':'badge-muted'}`}><span className="status-dot"/>{s}</span>}
const formatShortDate=(iso:string)=>{const[,m,d]=iso.split('-');return `${d} ${monthNames[Number(m)-1].slice(0,3)}`}
const isoToday=()=>{const n=new Date();return `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-${String(n.getDate()).padStart(2,'0')}`}
const daysBetween=(a:string,b:string)=>Math.round((new Date(b+'T00:00:00').getTime()-new Date(a+'T00:00:00').getTime())/86400000)
const statusColor=(s:Status):[number,number,number]=>s==='Completada'?[58,122,78]:s==='Bloqueada'?[178,58,58]:s==='En curso'?[196,140,30]:[120,112,101]
const sessionPdfColor=(s:SessionStatus):[number,number,number]=>s==='Cumplido'?[58,122,78]:s==='Parcial'?[196,140,30]:s==='No cumplido'?[178,58,58]:[150,143,132]
function renderSessionsPdf(d:jsPDF,sessions:WorkSession[],milestones:Milestone[],startY:number,newPage:()=>number){
 const marginX=18
 let y=startY
 const ensure=(h:number)=>{if(y+h>278)y=newPage()}
 const sorted=[...sessions].sort((a,b)=>a.date.localeCompare(b.date))
 if(!sorted.length){d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(140,132,120);d.text('No hay jornadas cargadas.',marginX,y);return y+10}
 sorted.forEach(s=>{
  const rows=deliverableAreas.map(area=>{
   const del=s.deliverables.find(x=>x.area===area)
   const desc=del?.description.trim()||'Sin entregable definido'
   const descLines=d.splitTextToSize(desc,108) as string[]
   const comment=del?.comment?.trim()
   const commentLines=comment?d.splitTextToSize(`Comentario: ${comment}${del?.reportedBy?` (${del.reportedBy})`:''}`,108) as string[]:[]
   return {area,del,defined:!!del?.description.trim(),descLines,commentLines,h:descLines.length*4.2+commentLines.length*3.8+4}
  })
  const milestone=milestoneForSession(s.date,milestones)
  ensure(14+(milestone?5:0)+rows.reduce((a,r)=>a+r.h,0))
  const st=sessionOverallStatus(s)
  const weekday=sessionDayLabel(s.date).weekday
  d.setFillColor(30,26,20);d.rect(marginX,y-5,174,9,'F')
  d.setFont('helvetica','bold');d.setFontSize(9.5);d.setTextColor(255,255,255)
  d.text(`${weekday.charAt(0).toUpperCase()+weekday.slice(1)} ${formatShortDate(s.date)} · ${s.hours} h`,marginX+3,y+0.8)
  const [r,g,b]=sessionPdfColor(st);d.setTextColor(r,g,b);d.setFontSize(8.5);d.text(st.toUpperCase(),189,y+0.8,{align:'right'})
  y+=10
  if(milestone){d.setFont('helvetica','normal');d.setFontSize(8);d.setTextColor(140,132,120);d.text(`Hacia el hito: ${milestone.title} (${formatShortDate(milestone.eventDate)})`,marginX+3,y);y+=5.5}
  rows.forEach(row=>{
   ensure(row.h)
   d.setFont('helvetica','bold');d.setFontSize(7.5);d.setTextColor(90,84,76);d.text(row.area.toUpperCase(),marginX+3,y)
   d.setFont('helvetica','normal');d.setFontSize(9);if(row.defined)d.setTextColor(11,11,11);else d.setTextColor(160,153,142)
   d.text(row.descLines,marginX+32,y)
   const status=row.del?.status??'Pendiente'
   const [sr,sg,sb]=sessionPdfColor(status);d.setFont('helvetica','bold');d.setFontSize(8);d.setTextColor(sr,sg,sb);d.text(row.defined?status:'-',189,y,{align:'right'})
   let yy=y+row.descLines.length*4.2
   if(row.commentLines.length){d.setFont('helvetica','italic');d.setFontSize(8);d.setTextColor(110,104,96);d.text(row.commentLines,marginX+32,yy-0.6);yy+=row.commentLines.length*3.8}
   d.setDrawColor(232,226,216);d.setLineWidth(0.2);d.line(marginX+3,yy,192,yy)
   y=yy+4.5
  })
  y+=4
 })
 return y
}
function downloadSessionsReport(sessions:WorkSession[],milestones:Milestone[]){
 const d=new jsPDF();d.setProperties({title:'FRC ETRR',subject:'FRC ETRR',author:'FRC ETRR',creator:'FRC ETRR',keywords:'FRC, ETRR'})
 const marginX=18
 const today=new Date().toLocaleDateString('es-AR',{day:'2-digit',month:'long',year:'numeric'})
 const drawHeader=()=>{d.setFillColor(234,88,12);d.rect(0,0,210,32,'F');d.setTextColor(255,255,255);d.setFont('helvetica','bold');d.setFontSize(18);d.text('FRC ETRR',marginX,16);d.setFont('helvetica','normal');d.setFontSize(9.5);d.text(`JORNADAS Y ENTREGABLES · Generado el ${today}`,marginX,24)}
 const newPage=()=>{d.addPage();drawHeader();return 46}
 const sectionTitle=(label:string,yy:number)=>{d.setTextColor(11,11,11);d.setFont('helvetica','bold');d.setFontSize(13);d.text(label,marginX,yy);d.setDrawColor(242,107,47);d.setLineWidth(0.6);d.line(marginX,yy+3,58,yy+3)}
 drawHeader()
 let y=46
 const items=sessions.flatMap(s=>s.deliverables.filter(x=>x.description.trim()))
 const count=(st:SessionStatus,list=items)=>list.filter(x=>x.status===st).length
 sectionTitle('Resumen',y);y+=11
 const stats=[{label:'Jornadas',value:String(sessions.length)},{label:'Entregables',value:String(items.length)},{label:'Cumplidos',value:String(count('Cumplido'))},{label:'Parciales',value:String(count('Parcial'))},{label:'No cumplidos',value:String(count('No cumplido'))}]
 const cardW=(174-4*3)/5
 stats.forEach((s,i)=>{const x=marginX+i*(cardW+3);d.setFillColor(250,247,242);d.rect(x,y-5,cardW,15,'F');d.setFont('helvetica','bold');d.setFontSize(7);d.setTextColor(140,132,120);d.text(s.label.toUpperCase(),x+3,y);d.setFontSize(13);d.setTextColor(11,11,11);d.text(s.value,x+3,y+7)})
 y+=20
 d.setFont('helvetica','bold');d.setFontSize(8);d.setTextColor(140,132,120);d.text('ÁREA',marginX,y);d.text('CUMPLIDOS',100,y);d.text('PARCIALES',130,y);d.text('NO CUMPLIDOS',160,y);d.setDrawColor(225,219,209);d.setLineWidth(0.3);d.line(marginX,y+3,192,y+3);y+=9
 deliverableAreas.forEach(area=>{const list=items.filter(x=>x.area===area);d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(11,11,11);d.text(area,marginX,y);d.text(`${count('Cumplido',list)} / ${list.length}`,100,y);d.text(String(count('Parcial',list)),130,y);d.text(String(count('No cumplido',list)),160,y);y+=8})
 y+=6
 const linked=[...milestones].filter(m=>m.eventDate).sort((a,b)=>a.eventDate.localeCompare(b.eventDate)).map(m=>{const ss=sessionsForMilestone(m,milestones,sessions);const list=ss.flatMap(s=>s.deliverables.filter(x=>x.description.trim()));return {m,jornadas:ss.length,total:list.length,done:count('Cumplido',list)}}).filter(x=>x.jornadas>0)
 if(linked.length){
  if(y>240)y=newPage()
  sectionTitle('Avance hacia cada hito',y);y+=12
  linked.forEach((l,i)=>{if(y>272)y=newPage();if(i%2===0){d.setFillColor(250,247,242);d.rect(marginX,y-5.5,174,10,'F')}d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(11,11,11);d.text(l.m.title.length>44?l.m.title.slice(0,42)+'…':l.m.title,marginX+2,y);d.setTextColor(90,84,76);d.setFontSize(8);d.text(`${l.jornadas} jornada${l.jornadas===1?'':'s'} · ${l.done}/${l.total} cumplidos`,130,y);d.setFont('helvetica','bold');d.setTextColor(242,107,47);d.text(formatShortDate(l.m.eventDate),190,y,{align:'right'});y+=10})
  y+=6
 }
 if(y>240)y=newPage()
 sectionTitle('Detalle por jornada',y);y+=13
 renderSessionsPdf(d,sessions,milestones,y,newPage)
 const pages=d.getNumberOfPages()
 for(let p=1;p<=pages;p++){d.setPage(p);d.setFont('helvetica','normal');d.setFontSize(8);d.setTextColor(170,163,152);d.text('FRC ETRR · Etapa final · Jornadas y entregables',marginX,290);d.text(`Página ${p} de ${pages}`,192,290,{align:'right'})}
 d.save('jornadas-entregables-frc-etrr.pdf')
}
function downloadTasksReport(tasks:Task[],scope:'Global'|Area){
 const d=new jsPDF();d.setProperties({title:'FRC ETRR',subject:'FRC ETRR',author:'FRC ETRR',creator:'FRC ETRR',keywords:'FRC, ETRR'})
 const today=new Date().toLocaleDateString('es-AR',{day:'2-digit',month:'long',year:'numeric'})
 const marginX=18
 const drawHeader=()=>{d.setFillColor(242,107,47);d.rect(0,0,210,32,'F');d.setTextColor(11,11,11);d.setFont('helvetica','bold');d.setFontSize(18);d.text('FRC ETRR · TAREAS',marginX,16);d.setFont('helvetica','normal');d.setFontSize(9.5);d.text(`${scope==='Global'?'Todas las áreas':`Área: ${scope}`} · Situación actual · Generado el ${today}`,marginX,24)}
 const colTitle=marginX,colArea=90,colOwner=136,colStatus=168
 const drawTableHead=(yy:number)=>{d.setFont('helvetica','bold');d.setFontSize(8);d.setTextColor(140,132,120);d.text('TAREA',colTitle,yy);d.text('ÁREA',colArea,yy);d.text('RESPONSABLE',colOwner,yy);d.text('ESTADO',colStatus,yy);d.setDrawColor(225,219,209);d.setLineWidth(0.3);d.line(marginX,yy+3,192,yy+3)}
 const drawFooter=(page:number,pages:number)=>{d.setFont('helvetica','normal');d.setFontSize(8);d.setTextColor(170,163,152);d.text('FRC ETRR · Listado de tareas y situación actual',marginX,290);d.text(`Página ${page} de ${pages}`,192,290,{align:'right'})}
 drawHeader();let y=46;drawTableHead(y);y+=10
 const sortedTasks=[...tasks].sort((a,b)=>a.area.localeCompare(b.area,'es')||a.title.localeCompare(b.title,'es'))
 if(sortedTasks.length===0){d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(140,132,120);d.text('No hay tareas cargadas en este alcance.',marginX,y);y+=10}
 sortedTasks.forEach((t,i)=>{
   if(y>272){d.addPage();drawHeader();y=46;drawTableHead(y);y+=10}
   if(i%2===0){d.setFillColor(250,247,242);d.rect(marginX,y-5.5,174,10,'F')}
   const title=t.title.length>32?t.title.slice(0,30)+'…':t.title
   const area=t.area.length>16?t.area.slice(0,14)+'…':t.area
   const owner=(t.owner||'—').length>16?t.owner.slice(0,14)+'…':(t.owner||'—')
   d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(11,11,11);d.text(title,colTitle,y)
   d.setFontSize(8);d.setTextColor(90,84,76);d.text(area,colArea,y)
   d.text(owner,colOwner,y)
   const [r,g,b]=statusColor(t.status);d.setFont('helvetica','bold');d.setFontSize(8);d.setTextColor(r,g,b);d.text(t.status,colStatus,y)
   y+=10
 })
 const totalPages=d.getNumberOfPages()
 for(let p=1;p<=totalPages;p++){d.setPage(p);drawFooter(p,totalPages)}
 const scopeSlug=scope!=='Global'?'-'+scope.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-'):''
 d.save(`tareas-situacion-frc-etrr${scopeSlug}.pdf`)
}

export function AppShell({role,userName,accounts:initialAccounts}:{role:Role;userName:string;accounts:Account[]}){
 const router=useRouter()
 const isAdmin=role==='admin'
 const [active,setActive]=useState('Resumen'),[tasks,setTasks]=useState<Task[]>(seedTasks),[tools,setTools]=useState<Tool[]>([]),[members,setMembers]=useState<Member[]>([]),[accounts,setAccounts]=useState<Account[]>(initialAccounts),[milestones,setMilestones]=useState<Milestone[]>([]),[sponsors,setSponsors]=useState<Sponsor[]>([]),[logs,setLogs]=useState<LogEntry[]>([]),[mobile,setMobile]=useState(false),[modal,setModal]=useState<ModalType>(null),[selected,setSelected]=useState<Task|null>(null),[selectedAccount,setSelectedAccount]=useState<Account|null>(null),[selectedTool,setSelectedTool]=useState<Tool|null>(null),[scope,setScope]=useState<'Global'|Area>('Global'),[toast,setToast]=useState(''),[calendarMonth,setCalendarMonth]=useState(()=>{const now=new Date();return new Date(now.getFullYear(),now.getMonth(),1)}),[confirmDelete,setConfirmDelete]=useState<{type:'task'|'tool'|'account'|'sponsor';id:number|string}|null>(null)
 const [sessions,setSessions]=useState<WorkSession[]>([])
 const refreshLogs=()=>fetch('/api/ecodesafio').then(r=>r.ok?r.json():null).then(d=>{if(d?.logs)setLogs(d.logs)}).catch(()=>{})
 useEffect(()=>{fetch('/api/ecodesafio').then(r=>r.ok?r.json():null).then(d=>{if(d?.tasks?.length)setTasks(d.tasks.map((t:Task)=>({...t,area:t.area as Area})));if(d?.tools)setTools(d.tools);if(d?.members)setMembers(d.members.map((m:Member)=>({...m,teamRole:m.teamRole||'colaborador',initials:initialsOf(m.name)})));if(d?.milestones)setMilestones(d.milestones);if(d?.sponsors)setSponsors(d.sponsors);if(d?.sessions)setSessions(d.sessions);if(d?.logs)setLogs(d.logs)}).catch(()=>{})},[])
 const replaceSession=(saved:WorkSession)=>setSessions(list=>list.map(s=>s.id===saved.id?saved:s))
 const saveSessionPlan=async(id:WorkSession['id'],deliverable:string,plan:Record<DeliverableArea,string>)=>{const res=await fetch('/api/ecodesafio',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'session-plan',id,deliverable,deliverables:plan})});if(!res.ok){const err=await res.json().catch(()=>null);notify(err?.error??'No se pudieron guardar los entregables');return false}replaceSession(await res.json());refreshLogs();notify('Entregables definidos');return true}
 const reportDeliverable=async(id:number,status:SessionStatus,comment:string)=>{const res=await fetch('/api/ecodesafio',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'deliverable-report',id,status,comment})});if(!res.ok){notify('No se pudo registrar el entregable');return false}replaceSession(await res.json());refreshLogs();notify('Entregable registrado');return true}
 useEffect(()=>{if(!isAdmin&&active==='Actividad')setActive('Resumen')},[isAdmin,active])
 const notify=(s:string)=>{setToast(s);setTimeout(()=>setToast(''),2300)}
 const handleSignOut=async()=>{await authClient.signOut();router.push('/sign-in');router.refresh()}
 const updateStatus=async(task:Task,status:Status)=>{if(status==='En curso'&&!task.startedAt){notify('Ingresá la fecha de inicio para poner la tarea en curso');return}const updated={...task,status,progress:statusProgress(status)};setTasks(ts=>ts.map(t=>t.id===task.id?updated:t));setSelected(updated);await fetch('/api/ecodesafio',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'task',...updated})});refreshLogs();notify(status==='En curso'?'Tarea iniciada y marcada en calendario':'Estado actualizado')}
 const updateTask=async(form:HTMLFormElement)=>{if(!selected)return;const formData=new FormData(form);const data=Object.fromEntries(formData) as Record<string,string>;const owner=formData.getAll('owner').join(', ');const status=data.status as Status;const due=toDate2026(data.dueMonth,data.dueDay);const startedAt=toDate2026(data.startedAtMonth,data.startedAtDay)||undefined;if(status==='En curso'&&!startedAt){notify('Ingresá la fecha de inicio para poner la tarea en curso');return}const updated={...selected,title:String(data.title),area:String(data.area) as Area,owner,due,startedAt,status,priority:String(data.priority),progress:statusProgress(status)};const response=await fetch('/api/ecodesafio',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'task',id:selected.id,...updated})});if(!response.ok){notify(response.status===400?'Ingresá la fecha de inicio para poner la tarea en curso':'No se pudo guardar la tarea');return}const saved=await response.json();setTasks(ts=>ts.map(t=>t.id===selected.id?{...saved,area:saved.area as Area}:t));setSelected(null);refreshLogs();notify('Tarea actualizada')}
 const updateTool=async(form:HTMLFormElement)=>{if(!selectedTool)return;const data=Object.fromEntries(new FormData(form)) as Record<string,string>;const response=await fetch('/api/ecodesafio',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'tool',id:selectedTool.id,tool:data.tool,quantity:Number(data.quantity),installed:data.installed==='on'})});if(!response.ok){notify('No se pudo guardar la herramienta');return}const saved=await response.json();setTools(ts=>ts.map(t=>t.id===selectedTool.id?saved:t));setSelectedTool(null);refreshLogs();notify('Herramienta actualizada')}
 const toggleToolInstalled=async(tool:Tool)=>{const updated={...tool,installed:!tool.installed};setTools(ts=>ts.map(t=>t.id===tool.id?updated:t));const response=await fetch('/api/ecodesafio',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'tool',id:tool.id,tool:tool.tool,quantity:tool.quantity,installed:updated.installed})});if(!response.ok){setTools(ts=>ts.map(t=>t.id===tool.id?tool:t));notify('No se pudo actualizar');return}refreshLogs()}
 const add=async(type:string,form:HTMLFormElement)=>{
  const formData=new FormData(form)
  const data=Object.fromEntries(formData) as Record<string,string>
  if(type==='task'){data.due=toDate2026(data.dueMonth,data.dueDay);data.owner=formData.getAll('owner').join(', ')}
  if(type==='milestone')data.eventDate=toDate2026(data.eventDateMonth,data.eventDateDay)
  if(type==='account'){
   try{
    const created=await createAccount({name:data.name,email:data.email,password:data.password,role:toRole(data.role),area:data.area,teamRole:data.teamRole}) as Account
    setAccounts(current=>[...current,created])
    setMembers(current=>[...current,{id:created.id,name:created.name,role:created.role,area:created.area,teamRole:created.teamRole,initials:initialsOf(created.name)}])
    setModal(null)
    refreshLogs()
    notify('Cuenta creada correctamente')
   }catch(err){
    notify(err instanceof Error?err.message:'No se pudo crear la cuenta')
   }
   return
  }
  const r=await fetch('/api/ecodesafio',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type,...data})})
  if(!r.ok){notify('No se pudo guardar');return}
  const item=await r.json()
  if(type==='task')setTasks(ts=>[...ts,{...item,area:item.area as Area}])
  if(type==='tool')setTools(ts=>[...ts,item])
  if(type==='milestone')setMilestones(ms=>[...ms,item])
  if(type==='sponsor')setSponsors(ss=>[item,...ss])
  setModal(null)
  refreshLogs()
  notify('Guardado correctamente')
 }
 const removeMilestone=async(id:number|string)=>{await fetch('/api/ecodesafio',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'milestone',id})});setMilestones(ms=>ms.filter(m=>m.id!==id));refreshLogs();notify('Hito eliminado')}
 const removeTask=async(id:number|string)=>{const response=await fetch('/api/ecodesafio',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'task',id})});if(!response.ok){notify('No se pudo eliminar la tarea');setConfirmDelete(null);return}setTasks(current=>current.filter(task=>task.id!==id));setSelected(current=>current?.id===id?null:current);setConfirmDelete(null);refreshLogs();notify('Tarea eliminada')}
 const removeTool=async(id:number|string)=>{const response=await fetch('/api/ecodesafio',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'tool',id})});if(!response.ok){notify('No se pudo eliminar la herramienta');setConfirmDelete(null);return}setTools(current=>current.filter(t=>t.id!==id));setSelectedTool(current=>current?.id===id?null:current);setConfirmDelete(null);refreshLogs();notify('Herramienta eliminada')}
 const removeSponsor=async(id:number|string)=>{const response=await fetch('/api/ecodesafio',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'sponsor',id})});if(!response.ok){notify('No se pudo eliminar el sponsor');setConfirmDelete(null);return}setSponsors(current=>current.filter(s=>s.id!==id));setConfirmDelete(null);refreshLogs();notify('Sponsor eliminado')}
 const updateAccountInfo=async(form:HTMLFormElement)=>{
  if(!selectedAccount)return
  const data=Object.fromEntries(new FormData(form)) as Record<string,string>
  try{
   const saved=await updateAccount({id:selectedAccount.id,name:data.name,email:data.email,role:toRole(data.role),area:data.area,teamRole:data.teamRole,password:data.password||undefined}) as Account
   setAccounts(current=>current.map(a=>a.id===selectedAccount.id?saved:a))
   setMembers(current=>current.map(m=>m.id===selectedAccount.id?{id:saved.id,name:saved.name,role:saved.role,area:saved.area,teamRole:saved.teamRole,initials:initialsOf(saved.name)}:m))
   setSelectedAccount(null)
   refreshLogs()
   notify('Cuenta actualizada')
  }catch(err){
   notify(err instanceof Error?err.message:'No se pudo actualizar la cuenta')
  }
 }
 const removeAccount=async(id:string)=>{
  try{
   await deleteAccount(id)
   setAccounts(current=>current.filter(a=>a.id!==id))
   setMembers(current=>current.filter(m=>m.id!==id))
   setConfirmDelete(null)
   refreshLogs()
   notify('Cuenta eliminada')
  }catch(err){
   setConfirmDelete(null)
   notify(err instanceof Error?err.message:'No se pudo eliminar la cuenta')
  }
 }
 const scoped=tasks.filter(t=>scope==='Global'||t.area===scope),filtered=tasks.filter(t=>scope==='Global'||t.area===scope)
 function downloadTools(){
  const today=new Date().toLocaleDateString('es-AR',{day:'2-digit',month:'2-digit',year:'numeric'})
  const headerRows=[
   ['LISTADO DE MATERIALES / HERRAMIENTAS / EPP / OTROS (A PRÉSTAMO)'],
   ['Fecha ','Material/Elemento','Cant','Apellido/nombre','Curso','Profesor','Taller / Salón','Devolución'],
  ]
  const dataRows=tools.length>0
   ? tools.map(t=>[today,t.tool,t.quantity,userName,'6to año','Francisco Sarrachini','',''])
   : [['','Sin herramientas cargadas','','','','','','']]
  const sheet=utils.aoa_to_sheet([...headerRows,...dataRows])
  sheet['!merges']=[{s:{r:0,c:0},e:{r:0,c:7}}]
  sheet['!cols']=[{wch:12},{wch:30},{wch:7},{wch:22},{wch:12},{wch:22},{wch:16},{wch:14}]
  const workbook=utils.book_new()
  utils.book_append_sheet(workbook,sheet,'Hoja1')
  workbook.Props={Title:'Pedido de herramientas - FRC ETRR',Subject:'FRC ETRR',Author:'FRC ETRR',Company:'FRC ETRR'}
  writeFile(workbook,'pedido-herramientas-frc-etrr.xlsx')
 }
 function downloadPlanning(){
  const d=new jsPDF();d.setProperties({title:'FRC ETRR',subject:'FRC ETRR',author:'FRC ETRR',creator:'FRC ETRR',keywords:'FRC, ETRR'})
  const today=new Date().toLocaleDateString('es-AR',{day:'2-digit',month:'long',year:'numeric'})
  const marginX=18
  const parseIso=(iso:string)=>{const[y,m,dd]=iso.split('-').map(Number);return new Date(y,m-1,dd)}
  const drawHeader=()=>{d.setFillColor(234,88,12);d.rect(0,0,210,32,'F');d.setTextColor(255,255,255);d.setFont('helvetica','bold');d.setFontSize(18);d.text('FRC ETRR',marginX,16);d.setFont('helvetica','normal');d.setFontSize(9.5);d.text(`PLANIFICACIÓN DEL PROYECTO · Generado el ${today}`,marginX,24)}
  const drawFooter=(page:number,pages:number)=>{d.setFont('helvetica','normal');d.setFontSize(8);d.setTextColor(170,163,152);d.text('FRC ETRR · Cronograma de tareas e hitos',marginX,290);d.text(`Página ${page} de ${pages}`,192,290,{align:'right'})}
  const sectionTitle=(label:string,yy:number)=>{d.setTextColor(11,11,11);d.setFont('helvetica','bold');d.setFontSize(13);d.text(label,marginX,yy);d.setDrawColor(242,107,47);d.setLineWidth(0.6);d.line(marginX,yy+3,58,yy+3)}
  drawHeader()
  let y=46
  const now=new Date(),todayDate=new Date(now.getFullYear(),now.getMonth(),now.getDate()),isoTodayStr=isoToday()
  const raceDate=(()=>{let race=new Date(now.getFullYear(),10,5);if(race<todayDate)race=new Date(now.getFullYear()+1,10,5);return race})()
  const raceDaysLeft=Math.round((raceDate.getTime()-todayDate.getTime())/86400000)
  const nextMilestone=[...milestones].filter(m=>m.eventDate>=isoTodayStr).sort((a,b)=>a.eventDate.localeCompare(b.eventDate))[0]
  const nextDeadline=[...tasks].filter(t=>t.due&&t.status!=='Completada').sort((a,b)=>a.due.localeCompare(b.due))[0]
  sectionTitle('Fechas importantes',y);y+=11
  const importantDates=[{label:'Día de la carrera',value:`5 de noviembre · faltan ${raceDaysLeft} días`},{label:'Próximo hito',value:nextMilestone?`${nextMilestone.title} · ${formatShortDate(nextMilestone.eventDate)}`:'Sin hitos próximos'},{label:'Próximo vencimiento',value:nextDeadline?`${nextDeadline.title} · ${formatShortDate(nextDeadline.due)}`:'Sin tareas con vencimiento'},{label:'Próxima jornada',value:(()=>{const next=[...sessions].filter(s=>s.date>=isoTodayStr).sort((a,b)=>a.date.localeCompare(b.date))[0];if(!next)return 'Sin jornadas próximas';const n=next.deliverables.filter(x=>x.description.trim()).length;const m=milestoneForSession(next.date,milestones);return `${formatShortDate(next.date)} · ${n} entregable${n===1?'':'s'} definido${n===1?'':'s'}${m?` · hacia ${m.title}`:''}`})()}]
  importantDates.forEach((item,i)=>{d.setFillColor(250,247,242);d.rect(marginX,y-5.5,174,10,'F');d.setDrawColor(242,107,47);d.setLineWidth(1.4);d.line(marginX,y-5.5,marginX,y+4.5);d.setFont('helvetica','bold');d.setFontSize(8.5);d.setTextColor(140,132,120);d.text(item.label.toUpperCase(),marginX+4,y-1);d.setFont('helvetica','normal');d.setFontSize(9.5);d.setTextColor(11,11,11);d.text(item.value,marginX+4,y+3.5);y+=13})
  y+=6
  if(y>230){d.addPage();drawHeader();y=46}
  sectionTitle('Diagrama de Gantt',y);y+=11
  const bars=tasks.map(t=>{const s=t.startedAt||t.due,e=t.due||t.startedAt;if(!s||!e)return null;let start=s,end=e;if(start>end){start=e;end=s}return{id:t.id,title:t.title,area:t.area,status:t.status,start,end}}).filter(Boolean) as {id:number|string;title:string;area:Area;status:Status;start:string;end:string}[]
  const points=milestones.filter(m=>m.eventDate).map(m=>({id:m.id,title:m.title,date:m.eventDate}))
  const jornadaPoints=sessions.filter(s=>s.date).map(s=>({id:s.id,date:s.date,status:sessionOverallStatus(s)}))
  if(bars.length===0&&points.length===0&&jornadaPoints.length===0){d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(140,132,120);d.text('No hay tareas con fechas ni hitos cargados para graficar.',marginX,y);y+=10}
  else{
   const DAY=86400000
   const dates=[...bars.flatMap(b=>[b.start,b.end]),...points.map(p=>p.date),...jornadaPoints.map(p=>p.date)].map(parseIso)
   let min=dates[0],max=dates[0];dates.forEach(dt=>{if(dt<min)min=dt;if(dt>max)max=dt})
   const rangeStart=new Date(min.getFullYear(),min.getMonth(),1),rangeEnd=new Date(max.getFullYear(),max.getMonth()+1,0)
   const totalDays=Math.round((rangeEnd.getTime()-rangeStart.getTime())/DAY)+1
   const chartX=marginX+40,chartW=192-chartX
   const xOf=(iso:string)=>chartX+Math.round((parseIso(iso).getTime()-rangeStart.getTime())/DAY)/totalDays*chartW
   const months:{label:string;x:number}[]=[];let cur=new Date(rangeStart)
   while(cur<=rangeEnd){months.push({label:monthNames[cur.getMonth()].slice(0,3)+" '"+String(cur.getFullYear()).slice(2),x:xOf(`${cur.getFullYear()}-${String(cur.getMonth()+1).padStart(2,'0')}-01`)});cur=new Date(cur.getFullYear(),cur.getMonth()+1,1)}
   const drawGanttHead=(yy:number)=>{d.setFillColor(24,24,24);d.rect(marginX,yy-5,174,7,'F');d.setFont('helvetica','bold');d.setFontSize(7);d.setTextColor(200,193,184);months.forEach(m=>d.text(m.label,m.x,yy-0.5))}
   let ganttY=y+6
   drawGanttHead(ganttY);ganttY+=10
   const drawTodayLine=(yTop:number,yBottom:number)=>{if(todayDate>=rangeStart&&todayDate<=rangeEnd){const tx=xOf(isoTodayStr);d.setDrawColor(242,107,47);d.setLineWidth(0.4);d.line(tx,yTop,tx,yBottom)}}
   if(points.length>0){
     if(ganttY>268){d.addPage();drawHeader();ganttY=46;drawGanttHead(ganttY);ganttY+=10}
     d.setFont('helvetica','bold');d.setFontSize(7.5);d.setTextColor(90,84,76);d.text('HITOS',marginX,ganttY+1)
     points.forEach(p=>{const px=xOf(p.date);d.setFillColor(242,107,47);d.triangle(px-1.6,ganttY-2.6,px+1.6,ganttY-2.6,px,ganttY+0.6,'F')})
     drawTodayLine(ganttY-6,ganttY+4)
     ganttY+=11
   }
   if(jornadaPoints.length>0){
     if(ganttY>268){d.addPage();drawHeader();ganttY=46;drawGanttHead(ganttY);ganttY+=10}
     d.setFont('helvetica','bold');d.setFontSize(7.5);d.setTextColor(90,84,76);d.text('JORNADAS',marginX,ganttY+1)
     jornadaPoints.forEach(p=>{const px=xOf(p.date);const [r,g,b]=sessionPdfColor(p.status);d.setFillColor(r,g,b);d.rect(px-1.1,ganttY-2.4,2.2,3.4,'F')})
     drawTodayLine(ganttY-6,ganttY+4)
     ganttY+=11
   }
   areas.forEach(area=>{
     const areaBars=bars.filter(b=>b.area===area)
     if(areaBars.length===0)return
     if(ganttY>262){d.addPage();drawHeader();ganttY=46;drawGanttHead(ganttY);ganttY+=10}
     d.setFillColor(30,26,20);d.rect(marginX,ganttY-4.2,174,6,'F');d.setFont('helvetica','bold');d.setFontSize(7);d.setTextColor(255,155,98);d.text(area.toUpperCase(),marginX+2,ganttY)
     ganttY+=8
     areaBars.forEach(b=>{
       if(ganttY>268){d.addPage();drawHeader();ganttY=46;drawGanttHead(ganttY);ganttY+=10}
       const title=b.title.length>26?b.title.slice(0,24)+'…':b.title
       d.setFont('helvetica','normal');d.setFontSize(7.5);d.setTextColor(70,64,58);d.text(title,marginX+1,ganttY+2.6)
       const x1=xOf(b.start),x2=Math.max(xOf(b.end),x1+1.5)
       const [r,g,bl]=statusColor(b.status);d.setFillColor(r,g,bl);d.roundedRect(x1,ganttY,x2-x1,4.6,1,1,'F')
       drawTodayLine(ganttY-1,ganttY+5.6)
       ganttY+=9
     })
   })
   y=ganttY+4
  }
  y+=4
  if(y>250){d.addPage();drawHeader();y=46}
  sectionTitle('Hitos del cronograma',y);y+=13
  const sortedMilestones=[...milestones].filter(m=>m.eventDate).sort((a,b)=>a.eventDate.localeCompare(b.eventDate))
  if(sortedMilestones.length===0){d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(140,132,120);d.text('No hay hitos cargados.',marginX,y);y+=10}
  sortedMilestones.forEach((m,i)=>{
    if(y>272){d.addPage();drawHeader();y=46}
    if(i%2===0){d.setFillColor(250,247,242);d.rect(marginX,y-5.5,174,10,'F')}
    d.setFont('helvetica','normal');d.setFontSize(9.5);d.setTextColor(11,11,11);d.text(m.title,marginX+2,y)
    d.setFont('helvetica','bold');d.setFontSize(8.5);d.setTextColor(242,107,47);d.text(formatShortDate(m.eventDate),168,y)
    y+=11
  })
  y+=8
  if(y>240){d.addPage();drawHeader();y=46}
  sectionTitle('Jornadas y entregables',y);y+=13
  y=renderSessionsPdf(d,sessions,milestones,y,()=>{d.addPage();drawHeader();return 46})
  y+=4
  if(y>250){d.addPage();drawHeader();y=46}
  sectionTitle('Cronograma de tareas',y);y+=13
  const colTitle=marginX,colInicio=100,colVence=132,colStatus=164
  const drawTableHead=(yy:number)=>{d.setFont('helvetica','bold');d.setFontSize(8);d.setTextColor(140,132,120);d.text('TAREA',colTitle,yy);d.text('INICIO',colInicio,yy);d.text('VENCE',colVence,yy);d.text('ESTADO',colStatus,yy);d.setDrawColor(225,219,209);d.setLineWidth(0.3);d.line(marginX,yy+3,192,yy+3)}
  drawTableHead(y)
  y+=10
  const scheduled=[...tasks].filter(t=>t.startedAt||t.due).sort((a,b)=>(a.startedAt||a.due).localeCompare(b.startedAt||b.due))
  if(scheduled.length===0){d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(140,132,120);d.text('No hay tareas con fechas asignadas.',marginX,y);y+=10}
  scheduled.forEach((t,i)=>{
    if(y>272){d.addPage();drawHeader();y=46;drawTableHead(y);y+=10}
    if(i%2===0){d.setFillColor(250,247,242);d.rect(marginX,y-5.5,174,10,'F')}
    const title=t.title.length>28?t.title.slice(0,26)+'…':t.title
    d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(11,11,11);d.text(title,colTitle,y)
    d.setFontSize(8);d.setTextColor(90,84,76);d.text(t.startedAt?formatShortDate(t.startedAt):'—',colInicio,y)
    d.text(t.due?formatShortDate(t.due):'—',colVence,y)
    const [r,g,b]=statusColor(t.status);d.setFont('helvetica','bold');d.setFontSize(8);d.setTextColor(r,g,b);d.text(t.status,colStatus,y)
    y+=10
  })
  const totalPages=d.getNumberOfPages()
  for(let p=1;p<=totalPages;p++){d.setPage(p);drawFooter(p,totalPages)}
  d.save('planificacion-frc-etrr.pdf')
 }
 return <main className="app-shell"><aside className={`sidebar ${mobile?'sidebar-open':''}`}><div className="brand"><div className="brand-mark"><Zap size={18}/></div><div><strong>FRC<span> ETRR</span></strong><small>Robótica</small></div><button className="icon-button mobile-close" onClick={()=>setMobile(false)}><X size={18}/></button></div><nav className="main-nav"><span className="nav-label">ESPACIO DE TRABAJO</span>{nav.filter(n=>!n.adminOnly||isAdmin).map(n=><button key={n.label} className={`nav-item ${active===n.label?'active':''}`} onClick={()=>{setActive(n.label);setMobile(false)}}><n.icon size={18}/>{n.label}{n.label==='Tareas'&&<em>{tasks.length}</em>}</button>)}</nav><div className="sidebar-bottom"><RaceCountdown/><div className="sidebar-account"><div className="sidebar-account-avatar">{userName.slice(0,2).toUpperCase()}</div><div className="sidebar-account-copy"><strong>{userName}</strong><span>{roleLabel[role]}</span></div><button type="button" className="icon-button" onClick={handleSignOut} aria-label="Cerrar sesión"><LogOut size={16}/></button></div></div></aside>{mobile&&<button className="sidebar-overlay" onClick={()=>setMobile(false)} aria-label="Cerrar menú"/>}<section className="main-content"><header className="topbar"><button className="icon-button mobile-menu" onClick={()=>setMobile(true)}><Menu size={20}/></button><div className="breadcrumbs"><span>FRC ETRR</span><span>/</span><strong>{active}</strong></div></header><div className="page-body">{active==='Resumen'&&<Summary tasks={scoped} scope={scope} setScope={setScope} onNew={()=>setModal('task')} onTasks={()=>setActive('Tareas')}/>} {active==='Tareas'&&<Kanban tasks={filtered} scope={scope} onNew={()=>setModal('task')} onOpen={task=>{setModal(null);setSelected(task)}}/>} {active==='Planificación'&&<Planning tasks={tasks} milestones={milestones} sessions={sessions} onOpenSessions={()=>setActive('Jornadas')} month={calendarMonth} onMonthChange={setCalendarMonth} onNewMilestone={()=>setModal('milestone')} onDeleteMilestone={removeMilestone} onDownload={downloadPlanning}/>} {active==='Herramientas'&&<Tools tools={tools} onNew={()=>setModal('tool')} onDownload={downloadTools} onDelete={id=>setConfirmDelete({type:'tool',id})} onEdit={setSelectedTool} onToggleInstalled={toggleToolInstalled}/>} {active==='Equipo'&&<Team members={members} role={role} accounts={accounts} onNewAccount={()=>setModal('account')} onOpenAccount={acc=>{setModal(null);setSelectedAccount(acc)}} onDeleteAccount={id=>setConfirmDelete({type:'account',id})}/>} {active==='Sponsors'&&<Sponsors sponsors={sponsors} onNew={()=>setModal('sponsor')} onDelete={id=>setConfirmDelete({type:'sponsor',id})}/>} {active==='Jornadas'&&<WorkSessions sessions={sessions} milestones={milestones} canDefine={role==='admin'||role==='coordinacion'} onSavePlan={saveSessionPlan} onReport={reportDeliverable}/>} {active==='Actividad'&&<ActivityLogView logs={logs}/>}</div>{selected&&!modal&&<TaskModal members={members} task={selected} onClose={()=>setSelected(null)} onStatus={s=>updateStatus(selected,s)} onDelete={()=>setConfirmDelete({type:'task',id:selected.id})} onSave={updateTask}/>} {selectedAccount&&!modal&&isAdmin&&<AccountModal account={selectedAccount} onClose={()=>setSelectedAccount(null)} onDelete={()=>setConfirmDelete({type:'account',id:selectedAccount.id})} onSave={updateAccountInfo}/>} {selectedTool&&!modal&&<ToolModal tool={selectedTool} onClose={()=>setSelectedTool(null)} onDelete={()=>setConfirmDelete({type:'tool',id:selectedTool.id})} onSave={updateTool}/>} {modal&&<CreateModal members={members} type={modal} onClose={()=>setModal(null)} onSubmit={add}/>} {confirmDelete&&<div className="modal-backdrop" role="presentation" onMouseDown={event=>{if(event.target===event.currentTarget)setConfirmDelete(null)}}><div className="modal confirm-modal" role="alertdialog" aria-modal="true"><h2>{confirmDelete.type==='task'?'¿Eliminar esta tarea?':confirmDelete.type==='account'?'¿Eliminar esta cuenta?':confirmDelete.type==='sponsor'?'¿Eliminar este sponsor?':'¿Eliminar esta herramienta?'}</h2><p>Esta acción no se puede deshacer.</p><div className="modal-footer"><button type="button" className="button secondary" onClick={()=>setConfirmDelete(null)}>Cancelar</button><button type="button" className="button danger-button" onClick={()=>confirmDelete.type==='task'?removeTask(confirmDelete.id):confirmDelete.type==='account'?removeAccount(String(confirmDelete.id)):confirmDelete.type==='sponsor'?removeSponsor(confirmDelete.id):removeTool(confirmDelete.id)}><Trash2 size={15}/> Eliminar</button></div></div></div>} {toast&&<div className="toast"><Check size={15}/>{toast}</div>}</section></main>
}
function Summary({tasks,scope,setScope,onNew,onTasks}:{tasks:Task[];scope:'Global'|Area;setScope:(s:'Global'|Area)=>void;onNew:()=>void;onTasks:()=>void}){const downloadSummary=()=>{
  const d=new jsPDF();d.setProperties({title:'FRC ETRR',subject:'FRC ETRR',author:'FRC ETRR',creator:'FRC ETRR',keywords:'FRC, ETRR'})
  const today=new Date().toLocaleDateString('es-AR',{day:'2-digit',month:'long',year:'numeric'})
  const marginX=18
  const drawCoverHeader=()=>{
    d.setFillColor(242,107,47);d.rect(0,0,210,36,'F')
    d.setTextColor(11,11,11);d.setFont('helvetica','bold');d.setFontSize(19);d.text('FRC ETRR · RESUMEN',marginX,17)
    d.setFont('helvetica','normal');d.setFontSize(10);d.text(`${scope==='Global'?'Vista global del proyecto':`Área: ${scope}`} · Generado el ${today}`,marginX,26)
    d.setFont('helvetica','bold');d.setFontSize(30);d.text(`${completion}%`,192,20,{align:'right'})
    d.setFont('helvetica','normal');d.setFontSize(9);d.text('completado',192,28,{align:'right'})
  }
  const drawPageFooter=(page:number,pages:number)=>{
    d.setDrawColor(230,224,214);d.setLineWidth(0.3);d.line(marginX,285,192,285)
    d.setFont('helvetica','normal');d.setFontSize(8);d.setTextColor(170,163,152)
    d.text('FRC ETRR · Documento generado automáticamente desde el HUB',marginX,291)
    d.text(`Página ${page} de ${pages}`,192,291,{align:'right'})
  }
  drawCoverHeader()
  const metrics:[string,string|number][]=[['Total',tasks.length],['En curso',inCourse],['Pendientes',pending],['Bloqueadas',blocked],['Completadas',done]]
  const cardW=34.4,cardH=25,gap=3,startX=18,startY=46
  metrics.forEach((m,i)=>{
    const x=startX+i*(cardW+gap)
    d.setFillColor(250,247,242);d.roundedRect(x,startY,cardW,cardH,2,2,'F')
    d.setDrawColor(230,224,214);d.setLineWidth(0.3);d.roundedRect(x,startY,cardW,cardH,2,2,'S')
    d.setTextColor(242,107,47);d.setFont('helvetica','bold');d.setFontSize(15);d.text(String(m[1]),x+cardW/2,startY+13,{align:'center'})
    d.setTextColor(120,112,101);d.setFont('helvetica','normal');d.setFontSize(7);d.text(String(m[0]),x+cardW/2,startY+20,{align:'center'})
  })
  d.setFont('helvetica','normal');d.setFontSize(8.5);d.setTextColor(120,112,101);d.text(`Tareas vencidas sin completar: ${overdue}`,marginX,startY+cardH+8)
  let y=startY+cardH+18
  d.setTextColor(11,11,11);d.setFont('helvetica','bold');d.setFontSize(13);d.text('Avance por área',marginX,y)
  d.setDrawColor(242,107,47);d.setLineWidth(0.6);d.line(marginX,y+3,58,y+3)
  y+=13
  d.setFont('helvetica','bold');d.setFontSize(8);d.setTextColor(140,132,120)
  d.text('ÁREA',marginX,y);d.text('TOTAL',126,y);d.text('HECHAS',148,y);d.text('BLOQ.',168,y);d.text('AVANCE',186,y)
  y+=3
  d.setDrawColor(225,219,209);d.setLineWidth(0.3);d.line(marginX,y,192,y)
  y+=8
  areaData.forEach(a=>{
    const pct=a.total?Math.round(a.done/a.total*100):0
    d.setFont('helvetica','normal');d.setFontSize(9);d.setTextColor(11,11,11)
    d.text(a.area,marginX,y)
    d.setFillColor(240,236,229);d.roundedRect(marginX,y+3,60,2.2,1.1,1.1,'F')
    d.setFillColor(242,107,47);d.roundedRect(marginX,y+3,Math.max(pct/100*60,2),2.2,1.1,1.1,'F')
    d.text(String(a.total),126,y)
    d.text(String(a.done),148,y)
    d.text(String(a.blocked),168,y)
    d.setFont('helvetica','bold');d.setTextColor(242,107,47);d.text(`${pct}%`,186,y)
    y+=14
  })
  const totalPages=d.getNumberOfPages()
  for(let p=1;p<=totalPages;p++){d.setPage(p);drawPageFooter(p,totalPages)}
  const scopeSlug=scope!=='Global'?'-'+scope.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-'):''
  d.save(`resumen-frc-etrr${scopeSlug}.pdf`)
};const todayIso=isoToday();const done=tasks.filter(t=>t.status==='Completada').length,inCourse=tasks.filter(t=>t.status==='En curso').length,blocked=tasks.filter(t=>t.status==='Bloqueada').length,pending=tasks.filter(t=>t.status==='Pendiente').length,overdue=tasks.filter(t=>t.due&&t.due<todayIso&&t.status!=='Completada').length,completion=tasks.length?Math.round(done/tasks.length*100):0,realizable=tasks.length?Math.round((tasks.length-blocked)/tasks.length*100):0;const areaData=areas.map(area=>({area,total:tasks.filter(t=>t.area===area).length,done:tasks.filter(t=>t.area===area&&t.status==='Completada').length,blocked:tasks.filter(t=>t.area===area&&t.status==='Bloqueada').length}));return <div className="section-view"><div className="page-heading"><div><div className="eyebrow"><Activity size={14}/> VISTA GENERAL DEL PROYECTO</div><h1>Resumen {scope!=='Global'&&<span>· {scope}</span>}</h1><p>Estado actualizado del proyecto y cada subgrupo.</p></div><div className="heading-actions"><button className="button secondary" onClick={downloadSummary}>Descargar resumen</button><button className="button secondary" onClick={onTasks}>Ver Kanban</button><button className="button primary" onClick={onNew}><Plus size={17}/> Nueva tarea</button></div></div><div className="filter-row"><span className="filter-label">Filtrar por área:</span><button className={`filter-pill ${scope==='Global'?'active':''}`} onClick={()=>setScope('Global')}>Global</button>{areas.map(area=><button key={area} className={`filter-pill ${scope===area?'active':''}`} onClick={()=>setScope(area)}>{area}</button>)}</div><div className="metrics-grid"><Metric label="Total de tareas" value={tasks.length}/><Metric label="En curso" value={inCourse}/><Metric label="Bloqueadas" value={blocked}/><Metric label="Completadas" value={done}/><Metric label="Tareas realizables" value={`${realizable}%`}/></div><Analytics tasks={tasks}/></div>}
function Analytics({tasks}:{tasks:Task[]}){const counts=[{label:'Completadas',value:tasks.filter(t=>t.status==='Completada').length,color:'done'},{label:'En curso',value:tasks.filter(t=>t.status==='En curso').length,color:'course'},{label:'Pendientes',value:tasks.filter(t=>t.status==='Pendiente').length,color:'pending'},{label:'Bloqueadas',value:tasks.filter(t=>t.status==='Bloqueada').length,color:'blocked'}];const total=Math.max(tasks.length,1);const areasData=areas.map(area=>{const areaTasks=tasks.filter(t=>t.area===area);return {area,total:areaTasks.length,done:areaTasks.filter(t=>t.status==='Completada').length}});const todayIso=isoToday();const upcoming=[...tasks].filter(t=>t.due&&t.status!=='Completada').sort((a,b)=>a.due.localeCompare(b.due)).slice(0,5).map(t=>{const d=daysBetween(todayIso,t.due);return {...t,daysLeft:d}});return <div className="analytics-grid"><div className="panel analytics-card"><div className="analytics-heading"><div><span className="eyebrow">LECTURA RÁPIDA</span><h2>Estado de tareas</h2></div><strong>{Math.round(counts[0].value/total*100)}%</strong></div><div className="analytics-bars">{counts.map(item=><div className="analytics-row" key={item.label}><div><span>{item.label}</span><b>{item.value}</b></div><div className="bar-track"><i className={item.color} style={{width:String(Math.round(item.value/total*100))+'%'}}/></div></div>)}</div></div><div className="panel analytics-card"><div className="analytics-heading"><div><span className="eyebrow">DISTRIBUCIÓN</span><h2>Carga por área</h2></div><span className="analytics-note">{tasks.length} tareas</span></div><div className="area-bars">{areasData.map(item=><div className="area-bar" key={item.area}><div><span>{item.area}</span><b>{item.done}/{item.total}</b></div><div className="bar-track"><i style={{width:String(item.total?Math.round(item.done/item.total*100):0)+'%'}}/></div></div>)}</div></div><div className="panel analytics-card deadline-card"><div className="analytics-heading"><div><span className="eyebrow">AGENDA</span><h2>Próximos vencimientos</h2></div><span className="analytics-note">{upcoming.length} de {tasks.filter(t=>t.status!=='Completada').length} activas</span></div>{upcoming.length===0?<p className="deadline-empty">No hay tareas pendientes con fecha de vencimiento.</p>:<div className="deadline-list">{upcoming.map(t=><div className="deadline-row" key={t.id}><span className={`deadline-dot ${t.daysLeft<0?'overdue':t.daysLeft<=3?'soon':'ok'}`}/><div className="deadline-copy"><strong>{t.title}</strong><small>{t.area}{t.owner?` · ${t.owner}`:''}</small></div><span className={`deadline-tag ${t.daysLeft<0?'overdue':t.daysLeft<=3?'soon':'ok'}`}>{t.daysLeft<0?`Vencida hace ${Math.abs(t.daysLeft)}d`:t.daysLeft===0?'Vence hoy':`Vence en ${t.daysLeft}d`}</span></div>)}</div>}</div></div>}
 function Metric({label,value}:{label:string;value:number|string}){return <div className="metric-card"><div className="metric-icon orange"><Target size={18}/></div><div className="metric-copy"><span>{label}</span><strong>{value}</strong><small>Actualizado en vivo</small></div></div>}
function Kanban({tasks,scope,onNew,onOpen}:{tasks:Task[];scope:'Global'|Area;onNew:()=>void;onOpen:(t:Task)=>void}){return <div className="section-view"><div className="page-heading"><div><div className="eyebrow"><ClipboardList size={14}/> PLANIFICACIÓN KANBAN</div><h1>Tareas por equipo</h1><p>Abrí una tarjeta para actualizar su estado.</p></div><div className="heading-actions"><button className="button secondary" onClick={()=>downloadTasksReport(tasks,scope)}>Descargar tareas</button><button className="button primary" onClick={onNew}><Plus size={17}/> Nueva tarea</button></div></div><div className="kanban-grid kanban-scroll" onWheel={e=>{if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){e.currentTarget.scrollLeft+=e.deltaY}}}>{areas.map(area=><div className="kanban-column" key={area}><div className="kanban-header"><h2>{area}</h2><span>{tasks.filter(t=>t.area===area).length}</span></div>{tasks.filter(t=>t.area===area).map(t=><button className="task-card task-card-button" key={t.id} onClick={()=>onOpen(t)}><div className="task-card-top"><span className={`priority-tag priority-${t.priority.toLowerCase()}`}>{t.priority}</span>{badge(t.status)}</div><h3>{t.title}</h3><div className="task-card-meta"><span><User size={12}/> {t.owner||'Sin asignar'}</span>{t.startedAt&&<span><CalendarClock size={12}/> Inicio {formatShortDate(t.startedAt)}</span>}<span><CalendarDays size={12}/> Vence {t.due?formatShortDate(t.due):'sin fecha'}</span></div><div className="task-card-progress"><div className="task-progress-track"><i style={{width:`${t.progress}%`}}/></div><small>{t.progress}%</small></div></button>)}</div>)}</div></div>}
function TaskModal({task,members,onClose,onStatus,onDelete,onSave}:{task:Task;members:Member[];onClose:()=>void;onStatus:(s:Status)=>void;onDelete:()=>void;onSave:(form:HTMLFormElement)=>void}){const [statusValue,setStatusValue]=useState<Status>(task.status);const needsStart=statusValue==='En curso'&&!task.startedAt;return <div className="modal-backdrop" role="presentation" onMouseDown={event=>{if(event.target===event.currentTarget)onClose()}}><form className="modal task-detail-modal" role="dialog" aria-modal="true" onSubmit={event=>{event.preventDefault();onSave(event.currentTarget)}}><div className="modal-heading"><div className="modal-title-block"><div className="modal-kicker">Editar tarea · {task.area}</div><h2>{task.title}</h2><p>Actualizá todos los datos y guardá los cambios.</p></div><button type="button" className="modal-close" onClick={onClose} aria-label="Cerrar"><X size={17}/></button></div><div className="modal-fields task-edit-fields"><label><span>Título</span><input name="title" defaultValue={task.title} required/></label><label><span>Área</span><select name="area" defaultValue={task.area}>{areas.map(area=><option key={area}>{area}</option>)}</select></label><label className="owner-field"><span>Responsables</span><OwnerPicker members={members} name="owner" initialSelected={ownersOf(task.owner)}/><small className="field-hint">Escribí un nombre y hacé clic (o Enter) para agregarlo. Podés sumar varios.</small></label><label><span>Prioridad</span><select name="priority" defaultValue={task.priority}><option>Alta</option><option>Media</option><option>Baja</option></select></label><label><span>Fecha de inicio {needsStart&&<em className="required-mark">* obligatoria</em>}</span><DateFields prefix="startedAt" defaultValue={task.startedAt} required={needsStart}/>{needsStart&&<small className="field-hint">Poné en marcha la tarea indicando cuándo empieza.</small>}</label><label><span>Fecha de vencimiento</span><DateFields prefix="due" defaultValue={task.due} required/></label><label><span>Estado</span><select name="status" defaultValue={task.status} onChange={e=>setStatusValue(e.target.value as Status)}>{(['Pendiente','En curso','Completada','Bloqueada'] as Status[]).map(status=><option key={status}>{status}</option>)}</select></label><div className="locked-progress"><span>Avance automático</span><strong>{statusProgress(task.status)}%</strong><small>Se calcula según el estado</small></div></div><div className="modal-footer"><button type="button" className="button danger-button" onClick={()=>{onClose();onDelete()}}><Trash2 size={15}/> Eliminar tarea</button><button type="button" className="button secondary" onClick={onClose}>Cancelar</button><button type="submit" className="button primary"><Check size={15}/> Guardar cambios</button></div></form></div>}
function CalendarView({milestones,tasks,sessions,onOpenSessions,month,onMonthChange,onDelete}:{milestones:Milestone[];tasks:Task[];sessions:WorkSession[];onOpenSessions:()=>void;month:Date;onMonthChange:(month:Date)=>void;onDelete:(id:number|string)=>void}){const year=month.getFullYear(),monthIndex=month.getMonth(),monthName=month.toLocaleDateString('es-AR',{month:'long',year:'numeric'}),daysInMonth=new Date(year,monthIndex+1,0).getDate(),firstDay=(new Date(year,monthIndex,1).getDay()+6)%7,days=Array.from({length:firstDay+daysInMonth},(_,i)=>i<firstDay?null:i-firstDay+1);const now=new Date();const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());const events=[...milestones.map(m=>{const n=sessionsForMilestone(m,milestones,sessions).length;return{date:m.eventDate,title:m.title,detail:n?`${n} jornada${n>1?'s':''} de trabajo hacia este hito`:'',type:'hito'}}),...sessions.map(s=>{const m=milestoneForSession(s.date,milestones);const defined=s.deliverables.filter(d=>d.description.trim());const done=defined.filter(d=>d.status==='Cumplido').length;const summary=deliverableSummary(s);return{date:s.date,title:`Jornada · ${defined.length?`${done}/${defined.length} entregables`:'sin entregables'}`,detail:`${summary}${m?`${summary?'\n':''}Hacia: ${m.title}`:''}`,type:'jornada'}}),...tasks.filter(t=>t.startedAt).map(t=>({date:t.startedAt!,title:`Inicio: ${t.title}`,detail:'',type:'inicio'})),...tasks.filter(t=>t.due).map(t=>({date:t.due,title:`Vence: ${t.title}`,detail:'',type:'vencimiento'}))];const eventForDay=(day:number)=>events.filter(event=>event.date===`${year}-${String(monthIndex+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`);return <><div className="calendar-legend"><span className="calendar-legend-item"><i className="legend-dot orange"/> Hito</span><span className="calendar-legend-item"><i className="legend-dot jornada"/> Jornada</span><span className="calendar-legend-item"><i className="legend-dot green"/> Inicio de tarea</span><span className="calendar-legend-item"><i className="legend-dot red"/> Vencimiento de tarea</span></div><div className="month-calendar panel"><div className="calendar-title"><button className="icon-button calendar-nav" onClick={()=>onMonthChange(new Date(year,monthIndex-1,1))} aria-label="Mes anterior">‹</button><strong>{monthName.charAt(0).toUpperCase()+monthName.slice(1)}</strong><div className="calendar-actions"><button className="button secondary calendar-today" onClick={()=>{const now=new Date();onMonthChange(new Date(now.getFullYear(),now.getMonth(),1))}}>Hoy</button><button className="icon-button calendar-nav" onClick={()=>onMonthChange(new Date(year,monthIndex+1,1))} aria-label="Mes siguiente">›</button></div></div><div className="calendar-weekdays">{['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'].map(d=><span key={d}>{d}</span>)}</div><div className="calendar-layout">{days.map((day,i)=><div className={`calendar-cell ${day&&year===today.getFullYear()&&monthIndex===today.getMonth()&&day===today.getDate()?'today':''}`} key={i}>{day&&<><span>{day}</span><div className="calendar-cell-events">{eventForDay(day).map((event,j)=>{const cls=`calendar-event ${event.type==='hito'?'orange':event.type==='jornada'?'jornada':event.type==='inicio'?'green':'red'}`;const tip=event.detail?`${event.title}\n${event.detail}`:event.title;return event.type==='jornada'?<button type="button" className={cls} key={j} title={tip} onClick={onOpenSessions}>{event.title}</button>:<div className={cls} key={j} title={tip}>{event.title}</div>})}</div></>}</div>)}</div></div></>}
function GanttView({tasks,milestones,sessions,onOpenSessions}:{tasks:Task[];milestones:Milestone[];sessions:WorkSession[];onOpenSessions:()=>void}){
 const parse=(iso:string)=>{const[y,m,d]=iso.split('-').map(Number);return new Date(y,m-1,d)}
 const bars=tasks.map(t=>{const s=t.startedAt||t.due,e=t.due||t.startedAt;if(!s||!e)return null;let start=s,end=e;if(start>end){start=e;end=s}return{id:t.id,title:t.title,area:t.area,status:t.status,progress:t.progress,start,end}}).filter(Boolean) as {id:number|string;title:string;area:Area;status:Status;progress:number;start:string;end:string}[]
 const points=milestones.filter(m=>m.eventDate).map(m=>({id:m.id,title:m.title,date:m.eventDate}))
 const jornadas=sessions.map(s=>{const m=milestoneForSession(s.date,milestones);const st=sessionOverallStatus(s);const summary=deliverableSummary(s);return{id:s.id,date:s.date,status:st,title:`Jornada ${formatShortDate(s.date)} · ${st}${m?` · Hacia: ${m.title}`:''}${summary?'\n'+summary:''}`}})
 if(bars.length===0&&points.length===0&&jornadas.length===0)return <div className="panel empty-state"><GanttChart size={22}/><strong>No hay datos para el Gantt</strong><span>Agregá tareas con fecha de inicio o vencimiento, o cargá hitos, para verlos acá.</span></div>
 const dates=[...bars.flatMap(b=>[b.start,b.end]),...points.map(p=>p.date),...jornadas.map(j=>j.date)].map(parse)
 let min=dates[0],max=dates[0];dates.forEach(d=>{if(d<min)min=d;if(d>max)max=d})
 const rangeStart=new Date(min.getFullYear(),min.getMonth(),1),rangeEnd=new Date(max.getFullYear(),max.getMonth()+1,0),DAY=86400000
 const totalDays=Math.round((rangeEnd.getTime()-rangeStart.getTime())/DAY)+1
 const offsetPct=(iso:string)=>Math.round((parse(iso).getTime()-rangeStart.getTime())/DAY)/totalDays*100
 const widthPct=(a:string,b:string)=>Math.max((Math.round((parse(b).getTime()-parse(a).getTime())/DAY)+1)/totalDays*100,1.5)
 const months:{label:string;widthPct:number}[]=[];let cur=new Date(rangeStart)
 while(cur<=rangeEnd){const dim=new Date(cur.getFullYear(),cur.getMonth()+1,0).getDate();months.push({label:monthNames[cur.getMonth()].slice(0,3)+" '"+String(cur.getFullYear()).slice(2),widthPct:dim/totalDays*100});cur=new Date(cur.getFullYear(),cur.getMonth()+1,1)}
 const now=new Date(),today=new Date(now.getFullYear(),now.getMonth(),now.getDate())
 const todayPct=today>=rangeStart&&today<=rangeEnd?Math.round((today.getTime()-rangeStart.getTime())/DAY)/totalDays*100:null
 const statusClass=(s:Status)=>s==='Completada'?'gantt-done':s==='En curso'?'gantt-course':s==='Bloqueada'?'gantt-blocked':'gantt-pending'
 const todayLine=todayPct!==null?<span className="gantt-today" style={{left:todayPct+'%'}}/>:null
 return <><div className="calendar-legend"><span className="calendar-legend-item"><i className="legend-dot green"/> Completada</span><span className="calendar-legend-item"><i className="legend-dot orange"/> En curso</span><span className="calendar-legend-item"><i className="legend-dot gray"/> Pendiente</span><span className="calendar-legend-item"><i className="legend-dot red"/> Bloqueada</span><span className="calendar-legend-item"><i className="legend-diamond"/> Hito</span><span className="calendar-legend-item"><i className="legend-jornada"/> Jornada</span>{todayPct!==null&&<span className="calendar-legend-item"><i className="legend-line"/> Hoy</span>}</div><div className="panel gantt-panel"><div className="gantt-scroll"><div className="gantt-chart" style={{minWidth:totalDays>150?'980px':totalDays>75?'760px':'620px'}}><div className="gantt-row gantt-head"><div className="gantt-label gantt-head-label">Tarea / Hito</div><div className="gantt-track gantt-months">{months.map((m,i)=><div key={i} className="gantt-month" style={{width:m.widthPct+'%'}}>{m.label}</div>)}{todayLine}</div></div>{points.length>0&&<div className="gantt-row gantt-milestone-row"><div className="gantt-label">Hitos</div><div className="gantt-track">{todayLine}{points.map(p=><span key={p.id} className="gantt-milestone" style={{left:offsetPct(p.date)+'%'}} title={`${p.title} · ${formatShortDate(p.date)}`}><i/></span>)}</div></div>}{jornadas.length>0&&<div className="gantt-row gantt-jornada-row"><div className="gantt-label">Jornadas</div><div className="gantt-track">{todayLine}{jornadas.map(j=><button type="button" key={j.id} className={`gantt-jornada ${sessionStatusClass[j.status]}`} style={{left:offsetPct(j.date)+'%'}} title={j.title} aria-label={j.title} onClick={onOpenSessions}/>)}</div></div>}{areas.map(area=>{const areaBars=bars.filter(b=>b.area===area);if(areaBars.length===0)return null;return <div key={area} className="gantt-area-group"><div className="gantt-area-name">{area}</div>{areaBars.map(b=><div key={b.id} className="gantt-row"><div className="gantt-label" title={b.title}>{b.title}</div><div className="gantt-track">{todayLine}<div className={`gantt-bar ${statusClass(b.status)}`} style={{left:offsetPct(b.start)+'%',width:widthPct(b.start,b.end)+'%'}} title={`${b.title} · ${formatShortDate(b.start)} – ${formatShortDate(b.end)} · ${b.progress}%`}><span className="gantt-bar-fill" style={{width:b.progress+'%'}}/></div></div></div>)}</div>})}</div></div></div></>
}
function PlanningOverview({tasks,milestones,sessions}:{tasks:Task[];milestones:Milestone[];sessions:WorkSession[]}){
 const now=new Date(),today=new Date(now.getFullYear(),now.getMonth(),now.getDate())
 const isoToday=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`
 const nextMilestone=[...milestones].filter(m=>m.eventDate>=isoToday).sort((a,b)=>a.eventDate.localeCompare(b.eventDate))[0]
 const overdue=tasks.filter(t=>t.due&&t.due<isoToday&&t.status!=='Completada').length
 const withDates=tasks.filter(t=>t.startedAt||t.due).length
 const scheduledPct=tasks.length?Math.round(withDates/tasks.length*100):0
 return <div className="planning-overview">
  <div className="planning-overview-card"><span>Próximo hito</span><strong>{nextMilestone?nextMilestone.title:'Sin hitos próximos'}</strong><small>{nextMilestone?formatShortDate(nextMilestone.eventDate):'—'}</small></div>
  <div className="planning-overview-card"><span>Tareas vencidas</span><strong className={overdue>0?'planning-overview-alert':''}>{overdue}</strong><small>sin completar</small></div>
  {(()=>{const next=sessions.find(s=>s.date>=isoToday);const defined=next?next.deliverables.filter(d=>d.description.trim()):[];const linked=next?milestoneForSession(next.date,milestones):undefined;return <div className="planning-overview-card"><span>Próxima jornada</span><strong>{next?formatShortDate(next.date):'Sin jornadas'}</strong><small>{next?`${defined.length} entregable${defined.length===1?'':'s'}${linked?` · hacia ${linked.title}`:''}`:'—'}</small></div>})()}
  <div className="planning-overview-card"><span>Tareas planificadas</span><strong>{scheduledPct}%</strong><small>con fecha asignada</small></div>
 </div>
}
function Planning({tasks,milestones,sessions,onOpenSessions,month,onMonthChange,onNewMilestone,onDeleteMilestone,onDownload}:{tasks:Task[];milestones:Milestone[];sessions:WorkSession[];onOpenSessions:()=>void;month:Date;onMonthChange:(month:Date)=>void;onNewMilestone:()=>void;onDeleteMilestone:(id:number|string)=>void;onDownload:()=>void}){
 const [view,setView]=useState<'gantt'|'calendario'>('gantt')
 return <div className="section-view"><div className="page-heading"><div><div className="eyebrow"><GanttChart size={14}/> PLANIFICACIÓN DEL PROYECTO</div><h1>Planificación</h1><p>Cronograma de tareas e hitos, en vista de línea de tiempo o de calendario.</p></div><div className="heading-actions"><div className="view-toggle"><button type="button" className={`view-toggle-btn ${view==='gantt'?'active':''}`} onClick={()=>setView('gantt')}><GanttChart size={14}/> Gantt</button><button type="button" className={`view-toggle-btn ${view==='calendario'?'active':''}`} onClick={()=>setView('calendario')}><CalendarDays size={14}/> Calendario</button></div><button className="button secondary" onClick={onDownload}>Descargar planificación</button><button className="button primary" onClick={onNewMilestone}><Plus size={17}/> Nuevo hito</button></div></div><PlanningOverview tasks={tasks} milestones={milestones} sessions={sessions}/>{view==='gantt'?<GanttView tasks={tasks} milestones={milestones} sessions={sessions} onOpenSessions={onOpenSessions}/>:<CalendarView milestones={milestones} tasks={tasks} sessions={sessions} onOpenSessions={onOpenSessions} month={month} onMonthChange={onMonthChange} onDelete={onDeleteMilestone}/>}</div>
}
function Tools({tools,onNew,onDownload,onDelete,onEdit,onToggleInstalled}:{tools:Tool[];onNew:()=>void;onDownload:()=>void;onDelete:(id:number|string)=>void;onEdit:(tool:Tool)=>void;onToggleInstalled:(tool:Tool)=>void}){
 const [query,setQuery]=useState('')
 const [sort,setSort]=useState<'az'|'za'>('az')
 const filtered=tools.filter(t=>t.tool.toLowerCase().includes(query.trim().toLowerCase())).sort((a,b)=>sort==='az'?a.tool.localeCompare(b.tool,'es'):b.tool.localeCompare(a.tool,'es'))
 return <div className="section-view"><div className="page-heading"><div><div className="eyebrow"><Wrench size={14}/> GESTIÓN DE HERRAMIENTAS</div><h1>Pedido de herramientas</h1></div><div className="heading-actions"><button className="button secondary" onClick={onNew}><Plus size={16}/> Agregar</button><button className="button primary" onClick={onDownload}>Descargar Excel</button></div></div>
 <div className="tools-toolbar"><div className="tools-search"><Search size={15}/><input type="text" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Buscar herramienta..."/></div><button type="button" className="button secondary" onClick={()=>setSort(s=>s==='az'?'za':'az')}>{sort==='az'?<ArrowDownAZ size={15}/>:<ArrowUpAZ size={15}/>} {sort==='az'?'A-Z':'Z-A'}</button></div>
 {tools.length===0?<div className="panel empty-state"><Wrench size={22}/><strong>No hay herramientas cargadas</strong><span>Agregá herramientas al pedido semanal del equipo.</span></div>:filtered.length===0?<div className="panel empty-state"><Search size={22}/><strong>Sin resultados</strong><span>Probá con otro nombre de herramienta.</span></div>:<div className="panel tools-list">{filtered.map(t=><div className="tool-row" key={t.id}><Wrench size={15}/><strong>{t.tool}</strong><span>{t.quantity} unidad(es)</span><button type="button" className={`installed-toggle ${t.installed?'installed-yes':'installed-no'}`} onClick={()=>onToggleInstalled(t)}>{t.installed?'La tenemos':'No la tenemos'}</button><button type="button" className="icon-button" onClick={()=>onEdit(t)} aria-label={`Editar ${t.tool}`}><Pencil size={15}/></button><button type="button" className="icon-button danger-button tool-delete" onClick={()=>onDelete(t.id)} aria-label={`Eliminar ${t.tool}`}><Trash2 size={15}/></button></div>)}</div>}</div>}
const sponsorKindIcon={Dinero:HandCoins,Físico:Package,Servicio:Handshake} as const
const sessionStatusClass: Record<SessionStatus,string> = { 'Pendiente':'pending', 'Parcial':'partial', 'Cumplido':'done', 'No cumplido':'missed' }
const deliverableAreas: DeliverableArea[] = ['Mecánica','Electrónica','Electricidad']
const reportStatuses: SessionStatus[] = ['Cumplido','Parcial','No cumplido']
const sessionOverallStatus=(session:WorkSession):SessionStatus=>{const defined=session.deliverables.filter(d=>d.description.trim());if(!defined.length||defined.every(d=>d.status==='Pendiente'))return 'Pendiente';if(defined.every(d=>d.status==='Cumplido'))return 'Cumplido';if(defined.every(d=>d.status==='No cumplido'))return 'No cumplido';return 'Parcial'}
const roleLabel: Record<Role,string> = { admin:'Administrador', coordinacion:'Coordinación', member:'Miembro' }
const milestoneForSession=(date:string,milestones:Milestone[])=>[...milestones].filter(m=>m.eventDate&&m.eventDate>=date).sort((a,b)=>a.eventDate.localeCompare(b.eventDate))[0]
const sessionsForMilestone=(m:Milestone,milestones:Milestone[],sessions:WorkSession[])=>{const prev=[...milestones].filter(x=>x.eventDate&&x.eventDate<m.eventDate).sort((a,b)=>b.eventDate.localeCompare(a.eventDate))[0];return sessions.filter(s=>s.date<=m.eventDate&&(!prev||s.date>prev.eventDate))}
const deliverableSummary=(s:WorkSession)=>s.deliverables.filter(d=>d.description.trim()).map(d=>`${d.area}: ${d.description} (${d.status})`).join('\n')
const toRole=(value:unknown):Role=>value==='admin'||value==='coordinacion'?value:'member'
const sessionDayLabel=(iso:string)=>{const d=new Date(`${iso}T12:00:00`);return { weekday:d.toLocaleDateString('es-AR',{weekday:'long'}), day:d.getDate(), month:d.toLocaleDateString('es-AR',{month:'short'}).replace('.','') }}
function WorkSessions({sessions,milestones,canDefine,onSavePlan,onReport}:{sessions:WorkSession[];milestones:Milestone[];canDefine:boolean;onSavePlan:(id:WorkSession['id'],deliverable:string,plan:Record<DeliverableArea,string>)=>Promise<boolean>;onReport:(id:number,status:SessionStatus,comment:string)=>Promise<boolean>}){
 const today=isoToday()
 const allItems=sessions.flatMap(s=>s.deliverables.filter(d=>d.description.trim()))
 const done=allItems.filter(d=>d.status==='Cumplido').length
 const partial=allItems.filter(d=>d.status==='Parcial').length
 const missed=allItems.filter(d=>d.status==='No cumplido').length
 const nextSession=sessions.find(s=>s.date>=today&&sessionOverallStatus(s)!=='Cumplido')
 const totalHours=sessions.reduce((sum,s)=>sum+Number(s.hours||0),0)
 const weeks=sessions.reduce<{key:string;items:WorkSession[]}[]>((acc,s)=>{const d=new Date(`${s.date}T12:00:00`);const monday=new Date(d);monday.setDate(d.getDate()-((d.getDay()+6)%7));const key=monday.toISOString().slice(0,10);const group=acc.find(g=>g.key===key);if(group)group.items.push(s);else acc.push({key,items:[s]});return acc},[])
 const pct=allItems.length?Math.round((done/allItems.length)*100):0
 const areaStats=deliverableAreas.map(area=>{const items=allItems.filter(d=>d.area===area);return {area,total:items.length,done:items.filter(d=>d.status==='Cumplido').length}})
 return <div className="section-view"><div className="page-heading"><div><div className="eyebrow"><Flag size={14}/> ETAPA FINAL · VIERNES Y SÁBADOS</div><h1>Jornadas y entregables</h1><p>{canDefine?'Como coordinación, definí qué debe entregar cada área en cada jornada. El equipo registra si se cumplió.':'La coordinación define los entregables de cada área. Al terminar la jornada, registrá si se cumplió y dejá un comentario.'}</p></div><div className="heading-actions"><button className="button secondary" onClick={()=>downloadSessionsReport(sessions,milestones)} disabled={sessions.length===0}>Descargar jornadas</button></div></div>
 {sessions.length===0?<div className="panel empty-state"><Flag size={22}/><strong>No hay jornadas cargadas</strong><span>Las jornadas del cronograma aparecerán acá.</span></div>:<>
 <div className="panel session-overview"><div className="session-progress-block"><div className="session-progress-head"><strong>{done} de {allItems.length} entregables cumplidos</strong><span>{pct}%</span></div><div className="session-track" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Entregables cumplidos">{sessions.map(s=>{const st=sessionOverallStatus(s);return <span key={s.id} className={`session-seg ${sessionStatusClass[st]}`} title={`${s.date} · ${st}`}/>})}</div><small>{partial} parcial{partial===1?'':'es'} · {missed} no cumplido{missed===1?'':'s'} · {totalHours} horas en total</small><div className="area-stats">{areaStats.map(a=><span key={a.area} className="area-stat"><AreaIcon area={a.area} size={13}/>{a.area}<b>{a.done}/{a.total}</b></span>)}</div></div>
 <div className="session-next">{nextSession?<><span className="session-next-label">Próxima jornada · {(()=>{const l=sessionDayLabel(nextSession.date);return `${l.weekday} ${l.day} ${l.month}`})()}</span><p>{`${nextSession.deliverables.filter(d=>d.description.trim()).length} de ${deliverableAreas.length} áreas con entregable definido`}</p></>:<><span className="session-next-label">Etapa completa</span><p>No quedan entregables pendientes.</p></>}</div></div>
 {weeks.map((week,i)=><section key={week.key} className="session-week" aria-labelledby={`week-${week.key}`}><h2 id={`week-${week.key}`} className="session-week-title">Semana {i+1}</h2><div className="session-week-grid">{week.items.map(s=><SessionCard key={s.id} session={s} milestone={milestoneForSession(s.date,milestones)} isNext={nextSession?.id===s.id} isPast={s.date<today} canDefine={canDefine} onSavePlan={onSavePlan} onReport={onReport}/>)}</div></section>)}</>}
 </div>
}
function AreaIcon({area,size=14}:{area:string;size?:number}){const Icon=area==='Mecánica'?Wrench:area==='Electrónica'?Cpu:Zap;return <Icon size={size} aria-hidden="true"/>}
function SessionCard({session,milestone,isNext,isPast,canDefine,onSavePlan,onReport}:{session:WorkSession;milestone?:Milestone;isNext:boolean;isPast:boolean;canDefine:boolean;onSavePlan:(id:WorkSession['id'],deliverable:string,plan:Record<DeliverableArea,string>)=>Promise<boolean>;onReport:(id:number,status:SessionStatus,comment:string)=>Promise<boolean>}){
 const label=sessionDayLabel(session.date)
 const byArea=(area:DeliverableArea)=>session.deliverables.find(d=>d.area===area)
 const buildPlan=()=>Object.fromEntries(deliverableAreas.map(a=>[a,byArea(a)?.description??''])) as Record<DeliverableArea,string>
 const [editing,setEditing]=useState(false),[saving,setSaving]=useState(false)
 const [general,setGeneral]=useState(session.deliverable),[plan,setPlan]=useState(buildPlan)
 const overall=sessionOverallStatus(session)
 const definedCount=session.deliverables.filter(d=>d.description.trim()).length
 const overdue=isPast&&definedCount>0&&session.deliverables.some(d=>d.description.trim()&&d.status==='Pendiente')
 const startEdit=()=>{setGeneral(session.deliverable);setPlan(buildPlan());setEditing(true)}
 const savePlan=async()=>{setSaving(true);const ok=await onSavePlan(session.id,general,plan);setSaving(false);if(ok)setEditing(false)}
 return <article className={`panel session-card ${sessionStatusClass[overall]} ${isNext?'is-next':''}`}>
 <header className="session-card-head"><div className="session-date"><span className="session-weekday">{label.weekday}</span><strong>{label.day}</strong><span>{label.month}</span></div><div className="session-meta"><span className="session-hours"><CalendarClock size={13}/> {session.hours} horas</span>{milestone&&<span className="session-milestone" title={`Esta jornada aporta al hito "${milestone.title}" (${formatShortDate(milestone.eventDate)})`}><Flag size={12} aria-hidden="true"/> Hacia: {milestone.title} · {formatShortDate(milestone.eventDate)}</span>}{isNext&&<span className="session-flag next">Próxima</span>}{overdue&&<span className="session-flag overdue">Sin registrar</span>}</div></header>
 {editing?<div className="plan-editor">{deliverableAreas.map(area=><label key={area}><span className="plan-area-label"><AreaIcon area={area} size={12}/>{area}</span><textarea rows={2} value={plan[area]} onChange={e=>setPlan({...plan,[area]:e.target.value})} placeholder={`Qué debe entregar ${area.toLowerCase()} esta jornada…`}/></label>)}<div className="plan-editor-actions"><button type="button" className="button secondary" disabled={saving} onClick={()=>setEditing(false)}>Cancelar</button><button type="button" className="button primary" disabled={saving} onClick={savePlan}>{saving?'Guardando…':'Guardar entregables'}</button></div></div>:<>
 <div className="session-deliverable"><div className="session-deliverable-head"><span>Entregables por área</span>{canDefine&&<button type="button" className="plan-edit-btn" onClick={startEdit}><Pencil size={12}/> Definir entregables</button>}</div></div>
 <ul className="area-deliverables">{deliverableAreas.map(area=>{const d=byArea(area);return <AreaDeliverableRow key={`${area}-${d?.id}-${d?.status}-${d?.comment}`} area={area} deliverable={d} onReport={onReport}/>})}</ul></>}
 </article>
}
function AreaDeliverableRow({area,deliverable,onReport}:{area:DeliverableArea;deliverable?:Deliverable;onReport:(id:number,status:SessionStatus,comment:string)=>Promise<boolean>}){
 const [comment,setComment]=useState(deliverable?.comment??''),[saving,setSaving]=useState(false)
 const defined=Boolean(deliverable?.description.trim())
 const status=deliverable?.status??'Pendiente'
 const dirty=comment!==(deliverable?.comment??'')
 const report=async(next:SessionStatus)=>{if(!deliverable)return;setSaving(true);await onReport(deliverable.id,next,comment);setSaving(false)}
 return <li className={`area-deliverable ${defined?sessionStatusClass[status]:'undefined'}`}>
 <div className="area-deliverable-head"><span className="area-name"><AreaIcon area={area}/>{area}</span>{defined&&<span className={`area-status-pill ${sessionStatusClass[status]}`}>{status}</span>}</div>
 {defined?<><p className="area-description">{deliverable!.description}</p>
 <div className="area-report" role="group" aria-label={`Estado del entregable de ${area}`}>{reportStatuses.map(st=><button key={st} type="button" disabled={saving} aria-pressed={status===st} className={`session-status-btn ${sessionStatusClass[st]} ${status===st?'active':''}`} onClick={()=>report(status===st?'Pendiente':st)}>{st==='Cumplido'&&<Check size={12}/>}{st==='No cumplido'&&<X size={12}/>}{st}</button>)}</div>
 <label className="area-comment"><span className="sr-only">Comentario sobre {area}</span><textarea rows={2} value={comment} placeholder="Comentario sobre la realización…" onChange={e=>setComment(e.target.value)}/></label>
 <div className="area-deliverable-foot"><small>{deliverable!.reportedBy?`Registrado por ${deliverable!.reportedBy}`:deliverable!.definedBy?`Definido por ${deliverable!.definedBy}`:''}</small>{dirty&&<button type="button" className="button primary session-save" disabled={saving} onClick={()=>report(status)}>{saving?'Guardando…':'Guardar comentario'}</button>}</div></>
 :<p className="area-description muted">La coordinación todavía no definió el entregable.</p>}
 </li>
}
function Sponsors({sponsors,onNew,onDelete}:{sponsors:Sponsor[];onNew:()=>void;onDelete:(id:number|string)=>void}){
 return <div className="section-view"><div className="page-heading"><div><div className="eyebrow"><Gift size={14}/> ALIANZAS DEL PROYECTO</div><h1>Sponsors</h1><p>Registrá quién apoya al equipo y qué aportó.</p></div><button className="button primary" onClick={onNew}><Plus size={16}/> Agregar sponsor</button></div>
 {sponsors.length===0?<div className="panel empty-state"><Gift size={22}/><strong>No hay sponsors cargados</strong><span>Agregá un sponsor y qué donó o aportó al equipo.</span></div>:<div className="panel tools-list">{sponsors.map(s=>{const KindIcon=sponsorKindIcon[s.kind]||Package;return <div className="tool-row" key={s.id}><KindIcon size={15}/><strong>{s.name}</strong><span className="sponsor-kind-tag">{s.kind}</span><span>{s.contribution||'Sin detalle'}</span><button type="button" className="icon-button danger-button tool-delete" onClick={()=>onDelete(s.id)} aria-label={`Eliminar ${s.name}`}><Trash2 size={15}/></button></div>})}</div>}</div>}
function Team({members,role,accounts,onNewAccount,onOpenAccount,onDeleteAccount}:{members:Member[];role:Role;accounts:Account[];onNewAccount:()=>void;onOpenAccount:(a:Account)=>void;onDeleteAccount:(id:string)=>void}){const isAdmin=role==='admin';const [areaFilter,setAreaFilter]=useState<'Todos'|Area>('Todos'),[teamRoleFilter,setTeamRoleFilter]=useState<'Todos'|TeamRole>('Todos');const openMember=(member:Member)=>{const account=accounts.find(a=>a.id===member.id);if(account)onOpenAccount(account)};const filteredMembers=members.filter(m=>(areaFilter==='Todos'||m.area===areaFilter)&&(teamRoleFilter==='Todos'||m.teamRole===teamRoleFilter));return <div className="section-view"><div className="page-heading"><div><div className="eyebrow"><Users size={14}/> PERSONAS</div><h1>Equipo FRC ETRR</h1><p>{filteredMembers.length} integrante{filteredMembers.length===1?'':'s'} {areaFilter!=='Todos'||teamRoleFilter!=='Todos'?'coinciden con el filtro':'registrado'+(filteredMembers.length===1?'':'s')+' en el equipo'}. {isAdmin?'Tocá una tarjeta para editar sus datos.':'Vista de solo lectura.'}</p></div>{isAdmin&&<button className="button primary" onClick={onNewAccount}><Plus size={16}/> Agregar integrante</button>}</div><div className="filter-row"><select value={areaFilter} onChange={e=>setAreaFilter(e.target.value as 'Todos'|Area)}><option value="Todos">Todas las áreas</option>{areas.map(area=><option key={area} value={area}>{area}</option>)}</select><select value={teamRoleFilter} onChange={e=>setTeamRoleFilter(e.target.value as 'Todos'|TeamRole)}><option value="Todos">Todos los roles</option><option value="lider">Líder</option><option value="colaborador">Colaborador</option></select></div>{filteredMembers.length===0?<div className="panel empty-state"><Users size={22}/><strong>No hay integrantes que coincidan</strong><span>Probá con otro filtro de área o rol.</span></div>:<div className="team-grid">{filteredMembers.map(member=>isAdmin?<button className="panel member-card member-card-button" key={member.id} onClick={()=>openMember(member)}><div className="member-avatar">{member.initials}</div><div><h2>{member.name}</h2><p>{member.teamRole==='lider'?'Líder':'Colaborador'} · {member.area||'Sin área asignada'}</p></div></button>:<div className="panel member-card" key={member.id}><div className="member-avatar">{member.initials}</div><div><h2>{member.name}</h2><p>{member.teamRole==='lider'?'Líder':'Colaborador'} · {member.area||'Sin área asignada'}</p></div></div>)}</div>}{isAdmin&&<div className="panel accounts-panel"><div className="accounts-panel-heading"><div><div className="eyebrow"><Shield size={14}/> ACCESO AL SISTEMA</div><h2>Cuentas de inicio de sesión</h2><p>Administrá quién puede entrar al HUB y con qué permisos.</p></div><button className="button secondary" onClick={onNewAccount}><Plus size={15}/> Crear cuenta</button></div><div className="accounts-list">{accounts.map(acc=><div className="account-row" key={acc.id}><button type="button" className="account-row-main" onClick={()=>onOpenAccount(acc)}><div className="account-avatar">{acc.name.slice(0,2).toUpperCase()}</div><div className="account-copy"><strong>{acc.name}</strong><span>{acc.email}</span></div></button><span className={`role-tag role-${acc.role}`}>{roleLabel[acc.role]}</span><button type="button" className="icon-button danger-button" onClick={()=>onDeleteAccount(acc.id)} aria-label={`Eliminar cuenta de ${acc.name}`}><Trash2 size={15}/></button></div>)}</div></div>}</div>}
function AccountModal({account,onClose,onDelete,onSave}:{account:Account;onClose:()=>void;onDelete:()=>void;onSave:(form:HTMLFormElement)=>void}){const [showPassword,setShowPassword]=useState(false);return <div className="modal-backdrop" role="presentation" onMouseDown={event=>{if(event.target===event.currentTarget)onClose()}}><form className="modal task-detail-modal" role="dialog" aria-modal="true" onSubmit={event=>{event.preventDefault();onSave(event.currentTarget)}}><div className="modal-heading"><div className="modal-title-block"><div className="modal-kicker">Editar cuenta</div><h2>{account.name}</h2><p>Modificá el nombre, el email o la contraseña de acceso.</p></div><button type="button" className="modal-close" onClick={onClose} aria-label="Cerrar"><X size={17}/></button></div><div className="modal-fields task-edit-fields"><label><span>Nombre completo</span><input name="name" defaultValue={account.name} required/></label><label><span>Email</span><input name="email" type="email" defaultValue={account.email} required/></label><label><span>Permisos</span><select name="role" defaultValue={account.role}><option value="member">Miembro</option><option value="coordinacion">Coordinación</option><option value="admin">Administrador</option></select></label><label><span>Área / equipo</span><select name="area" defaultValue={account.area}><option value="">Sin área asignada</option>{areas.map(area=><option key={area} value={area}>{area}</option>)}</select></label><label><span>Rol dentro del equipo</span><select name="teamRole" defaultValue={account.teamRole}><option value="colaborador">Colaborador</option><option value="lider">Líder</option></select></label><label><span>Nueva contraseña</span><div className="password-field"><input name="password" type={showPassword?'text':'password'} placeholder="Dejar en blanco para no cambiarla"/><button type="button" className="password-toggle" onClick={()=>setShowPassword(v=>!v)}>{showPassword?'Ocultar':'Mostrar'}</button></div><small className="field-hint">Por seguridad no podemos mostrar la contraseña actual; solo podés definir una nueva.</small></label></div><div className="modal-footer"><button type="button" className="button danger-button" onClick={()=>{onClose();onDelete()}}><Trash2 size={15}/> Eliminar cuenta</button><button type="button" className="button secondary" onClick={onClose}>Cancelar</button><button type="submit" className="button primary"><Check size={15}/> Guardar cambios</button></div></form></div>}
function ToolModal({tool,onClose,onDelete,onSave}:{tool:Tool;onClose:()=>void;onDelete:()=>void;onSave:(form:HTMLFormElement)=>void}){return <div className="modal-backdrop" role="presentation" onMouseDown={event=>{if(event.target===event.currentTarget)onClose()}}><form className="modal task-detail-modal" role="dialog" aria-modal="true" onSubmit={event=>{event.preventDefault();onSave(event.currentTarget)}}><div className="modal-heading"><div className="modal-title-block"><div className="modal-kicker">Editar herramienta</div><h2>{tool.tool}</h2><p>Modificá el nombre, la cantidad o si ya la tenemos en el equipo.</p></div><button type="button" className="modal-close" onClick={onClose} aria-label="Cerrar"><X size={17}/></button></div><div className="modal-fields"><label><span>Herramienta</span><input name="tool" defaultValue={tool.tool} required/></label><label><span>Cantidad</span><input name="quantity" type="number" min="1" defaultValue={tool.quantity} required/></label><label className="checkbox-inline"><input type="checkbox" name="installed" defaultChecked={tool.installed}/> Ya la tenemos en el equipo</label></div><div className="modal-footer"><button type="button" className="button danger-button" onClick={()=>{onClose();onDelete()}}><Trash2 size={15}/> Eliminar</button><button type="button" className="button secondary" onClick={onClose}>Cancelar</button><button type="submit" className="button primary"><Check size={15}/> Guardar cambios</button></div></form></div>}
function ActivityLogView({logs}:{logs:LogEntry[]}){return <div className="section-view"><div className="page-heading"><div><div className="eyebrow"><Activity size={14}/> TRAZABILIDAD DEL HUB</div><h1>Registro de actividad</h1><p>Historial de todo lo que se creó, editó o eliminó en el HUB.</p></div></div>{logs.length===0?<div className="panel empty-state"><Activity size={22}/><strong>Todavía no hay movimientos</strong><span>Cuando se cree, edite o elimine algo, va a aparecer acá.</span></div>:<div className="panel log-list">{logs.map(entry=><div className="log-row" key={entry.id}><div className={`log-icon log-icon-${entry.action==='Eliminó'?'delete':entry.action==='Actualizó'?'update':'create'}`}>{entry.action==='Eliminó'?<Trash2 size={14}/>:entry.action==='Actualizó'?<Wrench size={14}/>:<Plus size={14}/>}</div><div className="log-copy"><p><strong>{entry.actorName}</strong> {entry.action.toLowerCase()} {entry.entityType} <strong>{entry.entityLabel}</strong></p>{entry.detail&&<span className="log-detail">{entry.detail}</span>}</div><div className="log-meta"><span className={`role-tag role-${entry.actorRole}`}>{entry.actorRole==='admin'?'Admin':entry.actorRole==='coordinacion'?'Coordinación':'Miembro'}</span><time>{formatLogDate(entry.createdAt)}</time></div></div>)}</div>}</div>}
function SponsorFields(){
 return <><label><span>Nombre del sponsor</span><input name="name" placeholder="Ej. Taller Rodríguez" required/></label><label><span>¿Con qué aportó?</span><select name="kind" defaultValue="Físico"><option value="Físico">Algo físico (materiales, herramientas)</option><option value="Servicio">Un servicio</option></select></label><label><span>¿Qué aportó?</span><input name="contribution" placeholder="Ej. Donación de materiales y herramientas" required/></label></>
}
function CreateModal({type,members,onClose,onSubmit}:{type:'task'|'tool'|'milestone'|'account'|'sponsor';members:Member[];onClose:()=>void;onSubmit:(type:string,form:HTMLFormElement)=>void}){const copy={task:['Nueva tarea','Organizá una nueva actividad del auto eléctrico.'],tool:['Agregar herramienta','Sumá elementos al pedido semanal de herramientas.'],milestone:['Nuevo hito','Marcá una fecha importante del proyecto.'],account:['Crear cuenta','Dale acceso al HUB a un integrante del equipo.'],sponsor:['Agregar sponsor','Registrá un sponsor y qué aportó al equipo.']}[type];return <div className="modal-backdrop" role="presentation" onMouseDown={event=>{if(event.target===event.currentTarget)onClose()}}><form className="modal create-modal" onSubmit={e=>{e.preventDefault();onSubmit(type,e.currentTarget)}}><div className="modal-heading"><div className="modal-title-block"><div className="modal-kicker">FRC ETRR</div><h2>{copy[0]}</h2><p>{copy[1]}</p></div><button type="button" className="modal-close" onClick={onClose} aria-label="Cerrar"><X size={17}/></button></div><div className="modal-divider"/ ><div className="modal-fields">{type==='task'&&<><label><span>Título de la tarea</span><input name="title" placeholder="Ej. Montar soportes de batería" required/></label><label className="owner-field"><span>Responsables</span><OwnerPicker members={members} name="owner" initialSelected={[]}/><small className="field-hint">Escribí un nombre y hacé clic (o Enter) para agregarlo. Podés sumar varios.</small></label><label><span>Equipo responsable</span><select name="area">{areas.map(a=><option key={a}>{a}</option>)}</select></label><label><span>Fecha límite</span><DateFields prefix="due" required/></label></>}{type==='tool'&&<><label><span>Herramienta</span><input name="tool" placeholder="Ej. Soldadora MIG" required/></label><label><span>Cantidad</span><input name="quantity" type="number" min="1" defaultValue="1" required/></label><label className="checkbox-inline"><input type="checkbox" name="installed"/> Ya la tenemos en el equipo</label></>}{type==='account'&&<><label><span>Nombre completo</span><input name="name" placeholder="Ej. Nombre Apellido" required/></label><label><span>Email</span><input name="email" type="email" placeholder="nombre@etrr.edu.ar" required/></label><label><span>Contraseña</span><input name="password" type="password" placeholder="Contraseña" required/></label><label><span>Permisos</span><select name="role" defaultValue="member"><option value="member">Miembro</option><option value="coordinacion">Coordinación</option><option value="admin">Administrador</option></select></label><label><span>Área / equipo</span><select name="area" defaultValue=""><option value="">Sin área asignada</option>{areas.map(area=><option key={area} value={area}>{area}</option>)}</select></label><label><span>Rol dentro del equipo</span><select name="teamRole" defaultValue="colaborador"><option value="colaborador">Colaborador</option><option value="lider">Líder</option></select></label></>}{type==='milestone'&&<><label><span>Nombre del hito</span><input name="title" placeholder="Ej. Revisión de seguridad" required/></label><label><span>Fecha del hito</span><DateFields prefix="eventDate" defaultValue="2026-09-06" required/></label></>}{type==='sponsor'&&<SponsorFields/>}</div><div className="modal-footer"><button type="button" className="button secondary" onClick={onClose}>Cancelar</button><button className="button primary" type="submit"><Check size={16}/> Guardar cambios</button></div></form></div>}
