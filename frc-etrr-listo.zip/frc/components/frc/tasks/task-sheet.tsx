'use client'

import { useState, useTransition } from 'react'
import useSWR from 'swr'
import { toast } from 'sonner'
import { AlertTriangle, CheckCircle2, Copy, Pencil, Trash2 } from 'lucide-react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { NativeSelect } from '@/components/frc/field'
import { DemoBadge, PriorityTag, StatusBadge } from '@/components/frc/shared'
import { formatDate, formatDateTime } from '@/components/frc/format'
import { addTaskComment, changeTaskStatus, deleteTask, loadTaskActivity, verifyTask } from '@/app/actions/frc-tasks'
import { TASK_STATUSES } from '@/lib/frc/roles'
import { isOverdue, isTaskDone } from '@/lib/frc/progress'
import type { Member, Task } from '@/lib/frc/data'

export type TaskPerms = { edit: boolean; work: boolean; verify: boolean; remove: boolean }

export function TaskSheet({
  task,
  tasks,
  members,
  perms,
  onClose,
  onEdit,
  onDuplicate,
  onOpenTask,
}: {
  task: Task | null
  tasks: Task[]
  members: Member[]
  perms: TaskPerms
  onClose: () => void
  onEdit: (t: Task) => void
  onDuplicate: (t: Task) => void
  onOpenTask: (id: number) => void
}) {
  return (
    <Sheet open={!!task} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
        {task && (
          <TaskDetail
            key={task.id}
            task={task}
            tasks={tasks}
            members={members}
            perms={perms}
            onClose={onClose}
            onEdit={onEdit}
            onDuplicate={onDuplicate}
            onOpenTask={onOpenTask}
          />
        )}
      </SheetContent>
    </Sheet>
  )
}

function TaskDetail({
  task,
  tasks,
  members,
  perms,
  onClose,
  onEdit,
  onDuplicate,
  onOpenTask,
}: Omit<Parameters<typeof TaskSheet>[0], 'task'> & { task: Task }) {
  const [pending, startTransition] = useTransition()
  const [comment, setComment] = useState('')
  const [blockReason, setBlockReason] = useState('')
  const [pendingBlock, setPendingBlock] = useState(false)
  const { data, mutate } = useSWR(['task-activity', task.id], () => loadTaskActivity(task.id))

  const byId = new Map(tasks.map((t) => [t.id, t]))
  const memberName = (id: number) => members.find((m) => m.id === id)?.fullName ?? '—'
  const deps = task.dependsOnIds.map((id) => byId.get(id)).filter(Boolean) as Task[]
  const openDeps = deps.filter((d) => !isTaskDone(d) && d.status !== 'Cancelada')
  const subtasks = tasks.filter((t) => t.parentTaskId === task.id)
  const overdue = isOverdue(task.dueDate, task.status)
  const needsVerify = task.status === 'En revisión' || (task.status === 'Completada' && !isTaskDone(task))

  function run(fn: () => Promise<{ ok: boolean; error?: string }>, success: string) {
    startTransition(async () => {
      const res = await fn()
      if (res.ok) toast.success(success)
      else toast.error(res.error)
      mutate()
    })
  }

  function onStatus(next: string) {
    if (next === 'Bloqueada') {
      setPendingBlock(true)
      return
    }
    run(() => changeTaskStatus(task.id, next), 'Estado actualizado')
  }

  return (
    <div className="flex flex-col gap-6 px-4 pb-8">
      <SheetHeader className="px-0">
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={task.status} />
          <PriorityTag priority={task.priority} />
          {task.isDemo && <DemoBadge />}
        </div>
        <SheetTitle className="text-lg leading-snug text-balance">{task.title}</SheetTitle>
        <SheetDescription className="text-pretty">{task.description || 'Sin descripción.'}</SheetDescription>
      </SheetHeader>

      {(overdue || task.status === 'Bloqueada' || openDeps.length > 0) && (
        <div className="flex flex-col gap-1.5 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm">
          {overdue && <Alert>Vencida el {formatDate(task.dueDate, true)}.</Alert>}
          {task.status === 'Bloqueada' && <Alert>Bloqueada: {task.blockedReason}</Alert>}
          {openDeps.length > 0 && <Alert>Espera {openDeps.length} dependencia(s) sin terminar.</Alert>}
        </div>
      )}

      <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-2 text-sm">
        <Meta label="Responsable">{task.ownerName ?? 'Sin asignar'}</Meta>
        <Meta label="Colaboradores">{task.collaboratorIds.length ? task.collaboratorIds.map(memberName).join(', ') : '—'}</Meta>
        <Meta label="Subsistema">{task.subsystemName ?? 'General'}</Meta>
        <Meta label="Fase">{task.phaseName ?? '—'}</Meta>
        <Meta label="Fechas">
          <span className="font-mono text-xs">
            {formatDate(task.startDate)} → {formatDate(task.dueDate)}
          </span>
        </Meta>
        <Meta label="Entregable">{task.deliverable || '—'}</Meta>
        <Meta label="Aceptación">{task.acceptanceCriteria || '—'}</Meta>
        {task.verifiedBy && <Meta label="Verificada por">{task.verifiedBy}</Meta>}
      </dl>

      {perms.work && (
        <div className="flex flex-col gap-2">
          <label htmlFor="sheet-status" className="text-xs font-medium text-muted-foreground">
            Cambiar estado
          </label>
          <NativeSelect id="sheet-status" value={task.status} disabled={pending} onChange={(e) => onStatus(e.target.value)}>
            {TASK_STATUSES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </NativeSelect>
          {pendingBlock && (
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault()
                run(() => changeTaskStatus(task.id, 'Bloqueada', blockReason), 'Tarea bloqueada')
                setPendingBlock(false)
              }}
            >
              <Input autoFocus required placeholder="Motivo del bloqueo" value={blockReason} onChange={(e) => setBlockReason(e.target.value)} />
              <Button type="submit" size="sm" variant="destructive">
                Bloquear
              </Button>
            </form>
          )}
          {needsVerify && perms.verify && (
            <Button size="sm" disabled={pending} onClick={() => run(() => verifyTask(task.id), 'Tarea verificada')}>
              <CheckCircle2 /> Verificar y completar
            </Button>
          )}
        </div>
      )}

      {(deps.length > 0 || subtasks.length > 0) && (
        <div className="flex flex-col gap-3">
          {[
            ['Dependencias', deps],
            ['Subtareas', subtasks],
          ].map(([label, list]) =>
            (list as Task[]).length === 0 ? null : (
              <div key={label as string} className="flex flex-col gap-1">
                <h3 className="text-xs font-medium text-muted-foreground">{label as string}</h3>
                {(list as Task[]).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => onOpenTask(t.id)}
                    className="flex items-center justify-between gap-2 rounded-md border px-2.5 py-1.5 text-left text-sm hover:bg-muted"
                  >
                    <span className="truncate">{t.title}</span>
                    <StatusBadge status={t.status} />
                  </button>
                ))}
              </div>
            ),
          )}
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        {perms.edit && (
          <>
            <Button size="sm" variant="outline" onClick={() => onEdit(task)}>
              <Pencil /> Editar
            </Button>
            <Button size="sm" variant="outline" onClick={() => onDuplicate(task)}>
              <Copy /> Duplicar
            </Button>
          </>
        )}
        {perms.remove && (
          <Button
            size="sm"
            variant="ghost"
            className="text-destructive"
            disabled={pending}
            onClick={() => {
              if (!window.confirm(`¿Eliminar «${task.title}»? Esta acción no se puede deshacer.`)) return
              startTransition(async () => {
                const res = await deleteTask(task.id)
                if (res.ok) {
                  toast.success('Tarea eliminada')
                  onClose()
                } else toast.error(res.error)
              })
            }}
          >
            <Trash2 /> Eliminar
          </Button>
        )}
      </div>

      <section className="flex flex-col gap-3 border-t pt-5">
        <h3 className="text-sm font-medium">Comentarios</h3>
        {data?.comments.length === 0 && <p className="text-sm text-muted-foreground">Todavía no hay comentarios.</p>}
        <ul className="flex flex-col gap-3">
          {data?.comments.map((c) => (
            <li key={c.id} className="flex flex-col gap-0.5 text-sm">
              <span className="text-xs text-muted-foreground">
                <span className="font-medium text-foreground">{c.authorName}</span> · {formatDateTime(c.createdAt)}
              </span>
              <p className="leading-relaxed whitespace-pre-wrap">{c.body}</p>
            </li>
          ))}
        </ul>
        {perms.work && (
          <form
            className="flex flex-col gap-2"
            onSubmit={(e) => {
              e.preventDefault()
              const body = comment
              startTransition(async () => {
                const res = await addTaskComment(task.id, body)
                if (res.ok) {
                  setComment('')
                  mutate()
                } else toast.error(res.error)
              })
            }}
          >
            <Textarea rows={2} placeholder="Escribí un comentario…" value={comment} onChange={(e) => setComment(e.target.value)} />
            <Button type="submit" size="sm" className="self-end" disabled={pending || !comment.trim()}>
              Comentar
            </Button>
          </form>
        )}
      </section>

      <section className="flex flex-col gap-2 border-t pt-5">
        <h3 className="text-sm font-medium">Historial</h3>
        {data?.history.length === 0 && <p className="text-sm text-muted-foreground">Sin cambios registrados.</p>}
        <ol className="flex flex-col gap-1.5">
          {data?.history.map((h) => (
            <li key={h.id} className="grid grid-cols-[auto_1fr] gap-x-3 text-xs">
              <span className="font-mono text-muted-foreground">{formatDateTime(h.createdAt)}</span>
              <span>
                <span className="font-medium">{h.actorName}</span> · {h.summary}
              </span>
            </li>
          ))}
        </ol>
      </section>
    </div>
  )
}

function Meta({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="min-w-0 text-pretty">{children}</dd>
    </>
  )
}

function Alert({ children }: { children: React.ReactNode }) {
  return (
    <p className="flex items-start gap-2 text-destructive">
      <AlertTriangle className="mt-0.5 size-3.5 shrink-0" aria-hidden />
      <span>{children}</span>
    </p>
  )
}
