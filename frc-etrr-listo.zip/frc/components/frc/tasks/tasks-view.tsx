'use client'

import { useMemo, useState } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { ListChecks, Plus, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { NativeSelect } from '@/components/frc/field'
import { DemoBadge, EmptyState, PageHeader, PriorityTag, StatusBadge } from '@/components/frc/shared'
import { daysBetween, formatDate, todayISO } from '@/components/frc/format'
import { TaskFormDialog, taskToInput, type TaskFormRefs } from './task-form-dialog'
import { TaskSheet } from './task-sheet'
import { can } from '@/lib/frc/permissions'
import { isOverdue } from '@/lib/frc/progress'
import { TASK_STATUSES } from '@/lib/frc/roles'
import type { FrcContext } from '@/lib/frc/session'
import type { TaskInput } from '@/app/actions/frc-tasks'
import type { Task } from '@/lib/frc/data'
import { cn } from '@/lib/utils'

const VIEWS = [
  { id: 'lista', label: 'Lista' },
  { id: 'kanban', label: 'Kanban' },
  { id: 'mias', label: 'Mis tareas' },
  { id: 'responsable', label: 'Por responsable' },
  { id: 'subsistema', label: 'Por subsistema' },
  { id: 'vencimiento', label: 'Por vencimiento' },
] as const
type View = (typeof VIEWS)[number]['id']

const PRIORITY_ORDER: Record<string, number> = { Crítica: 0, Alta: 1, Media: 2, Baja: 3 }

export function TasksView({ refs, ctx, initialView }: { refs: TaskFormRefs; ctx: FrcContext; initialView: string }) {
  const router = useRouter()
  const pathname = usePathname()
  const params = useSearchParams()
  const [view, setView] = useState<View>(VIEWS.some((v) => v.id === initialView) ? (initialView as View) : 'lista')
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState('')
  const [subsystem, setSubsystem] = useState('')
  const [owner, setOwner] = useState('')
  const [sort, setSort] = useState<'vencimiento' | 'prioridad' | 'actualizada'>('vencimiento')
  const [openId, setOpenId] = useState<number | null>(null)
  const [formInitial, setFormInitial] = useState<Partial<TaskInput> | null>(null)

  const { tasks, subsystems, members } = refs
  const canCreate = ctx.role === 'admin' || ctx.role === 'profesor' || ctx.leadSubsystemIds.length > 0
  const canCreateHere = (subId: number | null) => can.createTask(ctx, subId)

  function changeView(next: View) {
    setView(next)
    const sp = new URLSearchParams(params.toString())
    sp.set('vista', next)
    router.replace(`${pathname}?${sp.toString()}`, { scroll: false })
  }

  const subtreeIds = (id: number) => [id, ...subsystems.filter((s) => s.parentId === id).map((s) => s.id)]

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    const subIds = subsystem ? subtreeIds(Number(subsystem)) : null
    return tasks
      .filter((t) => (view === 'mias' ? ctx.memberId !== null && (t.ownerMemberId === ctx.memberId || t.collaboratorIds.includes(ctx.memberId)) : true))
      .filter((t) => !status || t.status === status)
      .filter((t) => !subIds || (t.subsystemId !== null && subIds.includes(t.subsystemId)))
      .filter((t) => !owner || (owner === 'none' ? t.ownerMemberId === null : t.ownerMemberId === Number(owner)))
      .filter((t) => !q || `${t.title} ${t.description} ${t.ownerName ?? ''} ${t.subsystemName ?? ''}`.toLowerCase().includes(q))
      .sort((a, b) => {
        if (sort === 'prioridad') return (PRIORITY_ORDER[a.priority] ?? 9) - (PRIORITY_ORDER[b.priority] ?? 9)
        if (sort === 'actualizada') return b.updatedAt.localeCompare(a.updatedAt)
        return (a.dueDate ?? '9999').localeCompare(b.dueDate ?? '9999')
      })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tasks, view, query, status, subsystem, owner, sort, ctx.memberId])

  const openTask = tasks.find((t) => t.id === openId) ?? null
  const perms = openTask
    ? {
        edit: can.editTask(ctx, openTask),
        work: can.workOnTask(ctx, openTask),
        verify: can.verifyTask(ctx, openTask),
        remove: can.deleteCritical(ctx),
      }
    : { edit: false, work: false, verify: false, remove: false }

  const groups = groupTasks(view, filtered, refs)

  return (
    <>
      <PageHeader
        title="Tareas"
        description="Un único registro de trabajo, con distintas vistas. El avance de fases e hitos se calcula desde acá."
        actions={
          canCreate && (
            <Button size="sm" onClick={() => setFormInitial({})}>
              <Plus /> Nueva tarea
            </Button>
          )
        }
      />

      <div className="flex flex-col gap-3 border-b px-4 py-3 md:px-8">
        <div role="tablist" aria-label="Vistas de tareas" className="-mx-1 flex gap-1 overflow-x-auto">
          {VIEWS.map((v) => (
            <button
              key={v.id}
              role="tab"
              aria-selected={view === v.id}
              onClick={() => changeView(v.id)}
              className={cn(
                'shrink-0 rounded-md px-2.5 py-1 text-sm whitespace-nowrap transition-colors',
                view === v.id ? 'bg-secondary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {v.label}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2 md:flex md:flex-wrap md:items-center">
          <div className="relative col-span-2 md:w-64">
            <Search className="pointer-events-none absolute top-1/2 left-2.5 size-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input aria-label="Buscar tareas" placeholder="Buscar…" className="pl-8" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <NativeSelect aria-label="Filtrar por estado" className="md:w-36" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Todo estado</option>
            {TASK_STATUSES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </NativeSelect>
          <NativeSelect aria-label="Filtrar por subsistema" className="md:w-40" value={subsystem} onChange={(e) => setSubsystem(e.target.value)}>
            <option value="">Todo subsistema</option>
            {subsystems.map((s) => (
              <option key={s.id} value={s.id}>
                {s.parentId ? `— ${s.name}` : s.name}
              </option>
            ))}
          </NativeSelect>
          <NativeSelect aria-label="Filtrar por responsable" className="md:w-40" value={owner} onChange={(e) => setOwner(e.target.value)}>
            <option value="">Todo responsable</option>
            <option value="none">Sin asignar</option>
            {members.map((m) => (
              <option key={m.id} value={m.id}>
                {m.fullName}
              </option>
            ))}
          </NativeSelect>
          <NativeSelect aria-label="Ordenar" className="md:w-40" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)}>
            <option value="vencimiento">Por vencimiento</option>
            <option value="prioridad">Por prioridad</option>
            <option value="actualizada">Recientes</option>
          </NativeSelect>
        </div>
      </div>

      <div className="flex-1 px-4 py-5 md:px-8">
        {view === 'mias' && ctx.memberId === null ? (
          <EmptyState
            icon={ListChecks}
            title="Tu cuenta no está vinculada a un integrante"
            description="Pedile a un profesor que te vincule desde Equipo para ver tus tareas asignadas."
          />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={ListChecks}
            title={tasks.length === 0 ? 'Todavía no hay tareas' : 'Ninguna tarea coincide con los filtros'}
            description={tasks.length === 0 ? 'Creá la primera tarea y vinculala a una fase o hito para que sume al avance.' : 'Probá limpiar la búsqueda o los filtros.'}
            action={
              tasks.length === 0 && canCreate ? (
                <Button size="sm" onClick={() => setFormInitial({})}>
                  <Plus /> Nueva tarea
                </Button>
              ) : undefined
            }
          />
        ) : view === 'kanban' ? (
          <Kanban tasks={filtered} onOpen={setOpenId} />
        ) : (
          <div className="flex flex-col gap-6">
            {groups.map((g) => (
              <section key={g.key} className="flex flex-col gap-2">
                {g.label && (
                  <h2 className="flex items-center gap-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">
                    {g.label} <span className="font-mono">{g.tasks.length}</span>
                  </h2>
                )}
                <TaskTable tasks={g.tasks} onOpen={setOpenId} />
              </section>
            ))}
          </div>
        )}
      </div>

      <TaskSheet
        task={openTask}
        tasks={tasks}
        members={members}
        perms={perms}
        onClose={() => setOpenId(null)}
        onEdit={(t) => setFormInitial(taskToInput(t))}
        onDuplicate={(t) => canCreateHere(t.subsystemId) && setFormInitial(taskToInput(t, true))}
        onOpenTask={setOpenId}
      />
      <TaskFormDialog open={formInitial !== null} onOpenChange={(o) => !o && setFormInitial(null)} initial={formInitial} refs={refs} />
    </>
  )
}

function groupTasks(view: View, tasks: Task[], refs: TaskFormRefs) {
  if (view === 'responsable') {
    const map = new Map<string, Task[]>()
    for (const t of tasks) {
      const k = t.ownerName ?? 'Sin asignar'
      map.set(k, [...(map.get(k) ?? []), t])
    }
    return [...map].map(([k, list]) => ({ key: k, label: k, tasks: list }))
  }
  if (view === 'subsistema') {
    const groupOf = (id: number | null) => {
      const s = refs.subsystems.find((x) => x.id === id)
      if (!s) return 'General'
      return s.parentId ? (refs.subsystems.find((x) => x.id === s.parentId)?.name ?? s.name) : s.name
    }
    const map = new Map<string, Task[]>()
    for (const t of tasks) {
      const k = groupOf(t.subsystemId)
      map.set(k, [...(map.get(k) ?? []), t])
    }
    return [...map].map(([k, list]) => ({ key: k, label: k, tasks: list }))
  }
  if (view === 'vencimiento') {
    const today = todayISO()
    const buckets = [
      { key: 'vencidas', label: 'Vencidas', tasks: [] as Task[] },
      { key: 'semana', label: 'Próximos 7 días', tasks: [] as Task[] },
      { key: 'luego', label: 'Más adelante', tasks: [] as Task[] },
      { key: 'sin', label: 'Sin fecha', tasks: [] as Task[] },
      { key: 'cerradas', label: 'Cerradas', tasks: [] as Task[] },
    ]
    for (const t of tasks) {
      if (t.status === 'Completada' || t.status === 'Cancelada') buckets[4].tasks.push(t)
      else if (!t.dueDate) buckets[3].tasks.push(t)
      else if (t.dueDate < today) buckets[0].tasks.push(t)
      else if (daysBetween(today, t.dueDate) <= 7) buckets[1].tasks.push(t)
      else buckets[2].tasks.push(t)
    }
    return buckets.filter((b) => b.tasks.length > 0)
  }
  return [{ key: 'all', label: '', tasks }]
}

function TaskTable({ tasks, onOpen }: { tasks: Task[]; onOpen: (id: number) => void }) {
  return (
    <div className="overflow-hidden rounded-lg border">
      <ul className="divide-y">
        {tasks.map((t) => {
          const overdue = isOverdue(t.dueDate, t.status)
          return (
            <li key={t.id}>
              <button
                type="button"
                onClick={() => onOpen(t.id)}
                className="grid w-full grid-cols-[1fr_auto] items-center gap-x-4 gap-y-1 px-3 py-2.5 text-left transition-colors hover:bg-muted/60 md:grid-cols-[minmax(0,1fr)_7rem_9rem_8rem_5rem_5.5rem]"
              >
                <span className="flex min-w-0 items-center gap-2">
                  {t.parentTaskId !== null && <span className="text-muted-foreground" aria-label="Subtarea">↳</span>}
                  <span className="truncate text-sm font-medium">{t.title}</span>
                  {t.isDemo && <DemoBadge />}
                </span>
                <StatusBadge status={t.status} className="justify-self-end md:justify-self-start" />
                <span className="truncate text-xs text-muted-foreground">{t.ownerName ?? 'Sin asignar'}</span>
                <span className="hidden truncate text-xs text-muted-foreground md:block">{t.subsystemName ?? 'General'}</span>
                <span className="hidden md:block">
                  <PriorityTag priority={t.priority} />
                </span>
                <span className={cn('justify-self-end font-mono text-xs tabular-nums', overdue ? 'font-medium text-destructive' : 'text-muted-foreground')}>
                  {formatDate(t.dueDate)}
                </span>
              </button>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

function Kanban({ tasks, onOpen }: { tasks: Task[]; onOpen: (id: number) => void }) {
  return (
    <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-2 md:-mx-8 md:px-8">
      {TASK_STATUSES.map((s) => {
        const col = tasks.filter((t) => t.status === s)
        return (
          <section key={s} className="flex w-64 shrink-0 flex-col gap-2 rounded-lg bg-muted/50 p-2">
            <h2 className="flex items-center justify-between px-1 text-xs font-medium text-muted-foreground">
              {s} <span className="font-mono">{col.length}</span>
            </h2>
            {col.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => onOpen(t.id)}
                className="flex flex-col gap-2 rounded-md border bg-card p-2.5 text-left shadow-xs transition-colors hover:border-ring"
              >
                <span className="text-sm leading-snug font-medium text-pretty">{t.title}</span>
                <span className="flex items-center justify-between gap-2">
                  <PriorityTag priority={t.priority} />
                  <span className={cn('font-mono text-xs', isOverdue(t.dueDate, t.status) ? 'text-destructive' : 'text-muted-foreground')}>
                    {formatDate(t.dueDate)}
                  </span>
                </span>
                <span className="truncate text-xs text-muted-foreground">
                  {t.ownerName ?? 'Sin asignar'} · {t.subsystemName ?? 'General'}
                </span>
              </button>
            ))}
            {col.length === 0 && <p className="px-1 py-3 text-center text-xs text-muted-foreground">Vacío</p>}
          </section>
        )
      })}
    </div>
  )
}
