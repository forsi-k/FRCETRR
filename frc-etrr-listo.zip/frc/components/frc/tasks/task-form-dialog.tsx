'use client'

import { useState, useTransition } from 'react'
import { toast } from 'sonner'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Field, NativeSelect } from '@/components/frc/field'
import { saveTask, type TaskInput } from '@/app/actions/frc-tasks'
import { TASK_PRIORITIES, TASK_STATUSES } from '@/lib/frc/roles'
import type { Member, Phase, Subsystem, Task } from '@/lib/frc/data'

export type TaskFormRefs = {
  members: Member[]
  subsystems: Subsystem[]
  phases: Phase[]
  tasks: Task[]
}

const blank: TaskInput = {
  title: '',
  description: '',
  ownerMemberId: null,
  collaboratorIds: [],
  subsystemId: null,
  phaseId: null,
  milestoneId: null,
  parentTaskId: null,
  dependsOnIds: [],
  priority: 'Media',
  status: 'Pendiente',
  blockedReason: '',
  startDate: null,
  dueDate: null,
  deliverable: '',
  acceptanceCriteria: '',
}

export function taskToInput(t: Task, duplicate = false): TaskInput {
  return {
    id: duplicate ? undefined : t.id,
    title: duplicate ? `${t.title} (copia)` : t.title,
    description: t.description,
    ownerMemberId: t.ownerMemberId,
    collaboratorIds: t.collaboratorIds,
    subsystemId: t.subsystemId,
    phaseId: t.phaseId,
    milestoneId: t.milestoneId,
    parentTaskId: t.parentTaskId,
    dependsOnIds: duplicate ? [] : t.dependsOnIds,
    priority: t.priority,
    status: duplicate ? 'Pendiente' : t.status,
    blockedReason: t.blockedReason ?? '',
    startDate: t.startDate,
    dueDate: t.dueDate,
    deliverable: t.deliverable,
    acceptanceCriteria: t.acceptanceCriteria,
  }
}

const toId = (v: string) => (v ? Number(v) : null)

export function TaskFormDialog({
  open,
  onOpenChange,
  initial,
  refs,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  initial: Partial<TaskInput> | null
  refs: TaskFormRefs
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-2xl">
        {open && <TaskForm key={initial?.id ?? 'new'} initial={{ ...blank, ...initial }} refs={refs} onDone={() => onOpenChange(false)} />}
      </DialogContent>
    </Dialog>
  )
}

function TaskForm({ initial, refs, onDone }: { initial: TaskInput; refs: TaskFormRefs; onDone: () => void }) {
  const [form, setForm] = useState<TaskInput>(initial)
  const [pending, startTransition] = useTransition()
  const set = <K extends keyof TaskInput>(key: K, value: TaskInput[K]) => setForm((f) => ({ ...f, [key]: value }))

  const activeMembers = refs.members.filter((m) => m.status === 'activo' || m.id === form.ownerMemberId)
  const milestones = refs.phases.flatMap((p) => p.milestones).filter((m) => !form.phaseId || m.phaseId === form.phaseId)
  const otherTasks = refs.tasks.filter((t) => t.id !== form.id)
  const groups = refs.subsystems.filter((s) => s.parentId === null)

  const toggle = (key: 'collaboratorIds' | 'dependsOnIds', id: number) =>
    set(key, form[key].includes(id) ? form[key].filter((x) => x !== id) : [...form[key], id])

  function submit(e: React.FormEvent) {
    e.preventDefault()
    startTransition(async () => {
      const res = await saveTask(form)
      if (res.ok) {
        toast.success(form.id ? 'Tarea actualizada' : 'Tarea creada')
        onDone()
      } else toast.error(res.error)
    })
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-5">
      <DialogHeader>
        <DialogTitle>{form.id ? 'Editar tarea' : 'Nueva tarea'}</DialogTitle>
      </DialogHeader>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Título" htmlFor="t-title" className="sm:col-span-2">
          <Input id="t-title" required maxLength={200} value={form.title} onChange={(e) => set('title', e.target.value)} />
        </Field>
        <Field label="Descripción" htmlFor="t-desc" className="sm:col-span-2">
          <Textarea id="t-desc" rows={3} value={form.description} onChange={(e) => set('description', e.target.value)} />
        </Field>

        <Field label="Responsable" htmlFor="t-owner">
          <NativeSelect id="t-owner" value={form.ownerMemberId ?? ''} onChange={(e) => set('ownerMemberId', toId(e.target.value))}>
            <option value="">Sin asignar</option>
            {activeMembers.map((m) => (
              <option key={m.id} value={m.id}>
                {m.fullName}
              </option>
            ))}
          </NativeSelect>
        </Field>
        <Field label="Subsistema" htmlFor="t-sub">
          <NativeSelect id="t-sub" value={form.subsystemId ?? ''} onChange={(e) => set('subsystemId', toId(e.target.value))}>
            <option value="">General</option>
            {groups.map((g) => (
              <optgroup key={g.id} label={g.name}>
                <option value={g.id}>{g.name} (general)</option>
                {refs.subsystems
                  .filter((s) => s.parentId === g.id)
                  .map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
              </optgroup>
            ))}
          </NativeSelect>
        </Field>

        <Field label="Prioridad" htmlFor="t-prio">
          <NativeSelect id="t-prio" value={form.priority} onChange={(e) => set('priority', e.target.value)}>
            {TASK_PRIORITIES.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </NativeSelect>
        </Field>
        <Field label="Estado" htmlFor="t-status">
          <NativeSelect id="t-status" value={form.status} onChange={(e) => set('status', e.target.value)}>
            {TASK_STATUSES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </NativeSelect>
        </Field>
        {form.status === 'Bloqueada' && (
          <Field label="Motivo del bloqueo" htmlFor="t-block" className="sm:col-span-2">
            <Input id="t-block" required value={form.blockedReason} onChange={(e) => set('blockedReason', e.target.value)} />
          </Field>
        )}

        <Field label="Inicio" htmlFor="t-start">
          <Input id="t-start" type="date" value={form.startDate ?? ''} onChange={(e) => set('startDate', e.target.value || null)} />
        </Field>
        <Field label="Vencimiento" htmlFor="t-due">
          <Input id="t-due" type="date" value={form.dueDate ?? ''} onChange={(e) => set('dueDate', e.target.value || null)} />
        </Field>

        <Field label="Fase" htmlFor="t-phase">
          <NativeSelect
            id="t-phase"
            value={form.phaseId ?? ''}
            onChange={(e) => setForm((f) => ({ ...f, phaseId: toId(e.target.value), milestoneId: null }))}
          >
            <option value="">Sin fase</option>
            {refs.phases.map((p) => (
              <option key={p.id} value={p.id}>
                {p.sort}. {p.name}
              </option>
            ))}
          </NativeSelect>
        </Field>
        <Field label="Hito" htmlFor="t-ms">
          <NativeSelect id="t-ms" value={form.milestoneId ?? ''} onChange={(e) => set('milestoneId', toId(e.target.value))}>
            <option value="">Sin hito</option>
            {milestones.map((m) => (
              <option key={m.id} value={m.id}>
                {m.title}
              </option>
            ))}
          </NativeSelect>
        </Field>

        <Field label="Tarea padre" htmlFor="t-parent" hint="Convierte esta tarea en subtarea." className="sm:col-span-2">
          <NativeSelect id="t-parent" value={form.parentTaskId ?? ''} onChange={(e) => set('parentTaskId', toId(e.target.value))}>
            <option value="">Ninguna</option>
            {otherTasks
              .filter((t) => t.parentTaskId === null)
              .map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title}
                </option>
              ))}
          </NativeSelect>
        </Field>

        <Field label="Entregable" htmlFor="t-deliv">
          <Input id="t-deliv" value={form.deliverable} onChange={(e) => set('deliverable', e.target.value)} />
        </Field>
        <Field label="Criterios de aceptación" htmlFor="t-ac" hint="Si los cargás, la tarea requiere verificación.">
          <Input id="t-ac" value={form.acceptanceCriteria} onChange={(e) => set('acceptanceCriteria', e.target.value)} />
        </Field>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <CheckList
          label="Colaboradores"
          items={activeMembers.filter((m) => m.id !== form.ownerMemberId).map((m) => ({ id: m.id, label: m.fullName }))}
          selected={form.collaboratorIds}
          onToggle={(id) => toggle('collaboratorIds', id)}
          empty="No hay otros integrantes activos."
        />
        <CheckList
          label="Depende de"
          items={otherTasks.map((t) => ({ id: t.id, label: t.title }))}
          selected={form.dependsOnIds}
          onToggle={(id) => toggle('dependsOnIds', id)}
          empty="No hay otras tareas."
        />
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onDone}>
          Cancelar
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? 'Guardando…' : 'Guardar'}
        </Button>
      </DialogFooter>
    </form>
  )
}

function CheckList({
  label,
  items,
  selected,
  onToggle,
  empty,
}: {
  label: string
  items: { id: number; label: string }[]
  selected: number[]
  onToggle: (id: number) => void
  empty: string
}) {
  return (
    <fieldset className="flex flex-col gap-1.5">
      <legend className="mb-1.5 text-xs font-medium text-muted-foreground">
        {label} {selected.length > 0 && <span className="font-mono">({selected.length})</span>}
      </legend>
      <div className="flex max-h-36 flex-col overflow-y-auto rounded-md border p-1">
        {items.length === 0 && <p className="px-2 py-1.5 text-xs text-muted-foreground">{empty}</p>}
        {items.map((i) => (
          <label key={i.id} className="flex cursor-pointer items-center gap-2 rounded px-2 py-1 text-sm hover:bg-muted">
            <input type="checkbox" className="accent-primary" checked={selected.includes(i.id)} onChange={() => onToggle(i.id)} />
            <span className="truncate">{i.label}</span>
          </label>
        ))}
      </div>
    </fieldset>
  )
}
