'use client'

import { useTransition } from 'react'
import { toast } from 'sonner'
import { Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { NativeSelect } from '@/components/frc/field'
import { deleteDemoData, setAccountRole } from '@/app/actions/frc-team'
import { ROLE_LABELS, type PlatformRole } from '@/lib/frc/roles'

const PLATFORM_ROLES = Object.keys(ROLE_LABELS) as PlatformRole[]
const ROLE_LABEL = ROLE_LABELS

type Account = { id: string; name: string; email: string; role: string }

export function AccountsTable({ accounts, selfId }: { accounts: Account[]; selfId: string }) {
  const [pending, startTransition] = useTransition()
  return (
    <ul className="divide-y rounded-lg border">
      {accounts.map((a) => (
        <li key={a.id} className="flex flex-col gap-2 px-4 py-2.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex min-w-0 flex-col">
            <span className="truncate text-sm font-medium">{a.name}</span>
            <span className="truncate text-xs text-muted-foreground">{a.email}</span>
          </div>
          <NativeSelect
            aria-label={`Rol de ${a.name}`}
            className="sm:w-44"
            defaultValue={a.role}
            disabled={pending || a.id === selfId}
            onChange={(e) => {
              const role = e.target.value
              startTransition(async () => {
                const res = await setAccountRole(a.id, role)
                if (res.ok) toast.success('Rol actualizado')
                else toast.error(res.error)
              })
            }}
          >
            {PLATFORM_ROLES.map((r) => (
              <option key={r} value={r}>
                {ROLE_LABEL[r]}
              </option>
            ))}
          </NativeSelect>
        </li>
      ))}
    </ul>
  )
}

export function DemoDataButton() {
  const [pending, startTransition] = useTransition()
  return (
    <Button
      variant="outline"
      className="self-start text-destructive"
      disabled={pending}
      onClick={() => {
        if (!window.confirm('¿Borrar todos los datos de ejemplo? Los datos reales no se tocan.')) return
        startTransition(async () => {
          const res = await deleteDemoData()
          if (res.ok) toast.success('Datos de ejemplo eliminados')
          else toast.error(res.error)
        })
      }}
    >
      <Trash2 /> Borrar datos de ejemplo
    </Button>
  )
}
