import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string
  description?: string
  actions?: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-3 border-b px-4 py-5 md:flex-row md:items-end md:justify-between md:px-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-xl font-semibold tracking-tight text-balance">{title}</h1>
        {description && <p className="text-sm text-muted-foreground text-pretty">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon
  title: string
  description: string
  action?: React.ReactNode
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed px-6 py-14 text-center">
      <Icon className="size-6 text-muted-foreground" aria-hidden />
      <div className="flex max-w-sm flex-col gap-1">
        <p className="text-sm font-medium">{title}</p>
        <p className="text-sm text-muted-foreground text-pretty">{description}</p>
      </div>
      {action}
    </div>
  )
}

const STATUS_STYLES: Record<string, string> = {
  Pendiente: 'bg-muted text-muted-foreground',
  'En curso': 'bg-info/15 text-info',
  Bloqueada: 'bg-destructive/15 text-destructive',
  'En revisión': 'bg-primary/15 text-primary',
  Completada: 'bg-success/15 text-success',
  Cancelada: 'bg-muted text-muted-foreground line-through',
}

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  return (
    <span className={cn('inline-flex items-center rounded px-1.5 py-0.5 text-xs font-medium whitespace-nowrap', STATUS_STYLES[status] ?? STATUS_STYLES.Pendiente, className)}>
      {status}
    </span>
  )
}

const PRIORITY_DOT: Record<string, string> = {
  Baja: 'bg-muted-foreground/40',
  Media: 'bg-info',
  Alta: 'bg-primary',
  Crítica: 'bg-destructive',
}

export function PriorityTag({ priority }: { priority: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-xs whitespace-nowrap text-muted-foreground">
      <span className={cn('size-1.5 rounded-full', PRIORITY_DOT[priority])} aria-hidden />
      {priority}
    </span>
  )
}

export function DemoBadge() {
  return (
    <span className="rounded border border-dashed px-1 font-mono text-[10px] uppercase tracking-wide text-muted-foreground">
      Demo
    </span>
  )
}

export function ProgressBar({ value, className, label }: { value: number | null; className?: string; label?: string }) {
  return (
    <div className={cn('flex items-center gap-2', className)}>
      <div
        className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={value ?? 0}
        aria-label={label}
      >
        <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${value ?? 0}%` }} />
      </div>
      <span className="w-9 text-right font-mono text-xs tabular-nums text-muted-foreground">
        {value === null ? '—' : `${value}%`}
      </span>
    </div>
  )
}
