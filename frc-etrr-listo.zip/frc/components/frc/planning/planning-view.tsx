'use client'

import { useState, useTransition } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { CalendarRange, CheckCircle2, ChevronLeft, ChevronRight, Flag, Pencil, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, NativeSelect } from '@/components/frc/field'
import { DemoBadge, EmptyState, PageHeader, ProgressBar } from '@/components/frc/shared'
import { formatDate, todayISO } from '@/components/frc/format'
import { saveMilestone, savePhase, setMilestoneStatus, type MilestoneInput, type PhaseInput } from '@/app/actions/frc-team'
import type { Milestone, Phase, Task } from '@/lib/frc/data'
import { cn } from '@/lib/utils'

const VIEWS = [
  { id: 'cronograma', label: 'Cronograma' },
  { id: 'calendario', label: 'Calendario' },
  { id: 'fases', label: 'Fases e hitos' },
] as const
type View = (typeof VIEWS)[number]['id']

const MS_LABEL: Record<string, string> = { pendiente: 'Pendiente', en_riesgo: 'En riesgo', alcanzado: 'Alcanzado' }

type Props = { phases: Phase[]; tasks: Task[]; initialView: string; canManage: boolean; canVerify: boolean }

export function PlanningView({ phases, tasks, initialView, canManage, canVerify }: Props) {
  const router = useRouter()
  const pathname = usePathname()
  const [view, setView] = useState<View>(VIEWS.some((v) => v.id === initialView) ? (initialView as View) : 'cronograma')
  const [phaseForm, setPhaseForm] = useState<PhaseInput | null>(null)
  const [msForm, setMsForm] = useState<MilestoneInput | null>(null)

  const changeView = (v: View) => {
    setView(v)
    router.replace(`${pathname}?vista=${v}`, { scroll: false })
  }

  const newPhase = () =>
    setPhaseForm({ name: '', description: '', plannedStart: null, plannedEnd: null, actualStart: null, actualEnd: null })
  const editPhase = (p: Phase) =>
    setPhaseForm({
      id: p.id,
      name: p.name,
      description: p.description,
      plannedStart: p.plannedStart,
      plannedEnd: p.plannedEnd,
      actualStart: p.actualStart,
      actualEnd: p.actualEnd,
    })
  const newMs = (phaseId: number) => setMsForm({ phaseId, title: '', description: '', dueDate: null, acceptanceCriteria: '' })
  const editMs = (m: Milestone) =>
    setMsForm({ id: m.id, phaseId: m.phaseId, title: m.title, description: m.description, dueDate: m.dueDate, acceptanceCriteria: m.acceptanceCriteria })

  return (
    <>
      <PageHeader
        title="Planificación"
        description="Fases, hitos y cronograma. El avance se calcula a partir de las tareas vinculadas."
        actions={
          canManage && (
            <Button size="sm" onClick={newPhase}>
              <Plus /> Nueva fase
            </Button>
          )
        }
      />
      <div className="border-b px-4 py-3 md:px-8">
        <div role="tablist" aria-label="Vistas de planificación" className="flex gap-1">
          {VIEWS.map((v) => (
            <button
              key={v.id}
              role="tab"
              aria-selected={view === v.id}
              onClick={() => changeView(v.id)}
              className={cn(
                'rounded-md px-2.5 py-1 text-sm transition-colors',
                view === v.id ? 'bg-secondary font-medium' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {v.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 px-4 py-5 md:px-8">
        {phases.length === 0 ? (
          <EmptyState icon={CalendarRange} title="Sin fases" description="Creá la primera fase para empezar a planificar la temporada." />
        ) : view === 'cronograma' ? (
          <Gantt phases={phases} />
        ) : view === 'calendario' ? (
          <MonthCalendar phases={phases} tasks={tasks} />
        ) : (
          <PhaseList phases={phases} canManage={canManage} canVerify={canVerify} onEditPhase={editPhase} onNewMs={newMs} onEditMs={editMs} />
        )}
      </div>

      <PhaseDialog value={phaseForm} onClose={() => setPhaseForm(null)} />
      <MilestoneDialog value={msForm} phases={phases} onClose={() => setMsForm(null)} />
    </>
  )
}

const toDay = (iso: string) => Date.parse(`${iso}T00:00:00Z`) / 86_400_000

function Gantt({ phases }: { phases: Phase[] }) {
  const dated = phases.filter((p) => p.plannedStart && p.plannedEnd)
  if (dated.length === 0)
    return <EmptyState icon={CalendarRange} title="Sin fechas planificadas" description="Cargá inicio y fin en las fases para ver el cronograma." />

  const start = Math.min(...dated.map((p) => toDay(p.plannedStart!)))
  const end = Math.max(...dated.map((p) => toDay(p.actualEnd ?? p.plannedEnd!)))
  const span = Math.max(end - start, 1)
  const pct = (iso: string) => ((toDay(iso) - start) / span) * 100
  const today = todayISO()
  const todayPct = pct(today)

  const months: { label: string; left: number }[] = []
  const d = new Date(start * 86_400_000)
  d.setUTCDate(1)
  while (d.getTime() / 86_400_000 <= end) {
    const iso = d.toISOString().slice(0, 10)
    const left = pct(iso)
    if (left >= 0) months.push({ label: d.toLocaleDateString('es-AR', { month: 'short', timeZone: 'UTC' }), left })
    d.setUTCMonth(d.getUTCMonth() + 1)
  }

  return (
    <div className="overflow-x-auto rounded-lg border">
      <div className="min-w-[720px]">
        <div className="grid grid-cols-[14rem_1fr] border-b bg-muted/40 text-xs text-muted-foreground">
          <div className="px-3 py-2">Fase</div>
          <div className="relative h-8">
            {months.map((m) => (
              <span key={m.left} className="absolute top-2 font-mono capitalize" style={{ left: `${m.left}%` }}>
                {m.label}
              </span>
            ))}
          </div>
        </div>
        {phases.map((p) => {
          const late = p.plannedEnd && p.plannedEnd < today && (p.progress ?? 0) < 100 && !p.actualEnd
          return (
            <div key={p.id} className="grid grid-cols-[14rem_1fr] border-b last:border-b-0">
              <div className="flex min-w-0 flex-col gap-0.5 px-3 py-2">
                <span className="flex items-center gap-1.5 truncate text-sm">
                  <span className="font-mono text-xs text-muted-foreground">{String(p.sort).padStart(2, '0')}</span>
                  <span className="truncate">{p.name}</span>
                </span>
                <span className="font-mono text-xs text-muted-foreground">
                  {p.progress === null ? 'sin tareas' : `${p.progress}%`}
                  {late && <span className="text-destructive"> · retrasada</span>}
                </span>
              </div>
              <div className="relative h-full min-h-12">
                {todayPct >= 0 && todayPct <= 100 && (
                  <div className="absolute inset-y-0 w-px bg-destructive/60" style={{ left: `${todayPct}%` }} aria-hidden />
                )}
                {p.plannedStart && p.plannedEnd && (
                  <div
                    className="absolute top-3 h-3 overflow-hidden rounded-sm bg-primary/25"
                    style={{ left: `${pct(p.plannedStart)}%`, width: `max(${pct(p.plannedEnd) - pct(p.plannedStart)}%, 4px)` }}
                    title={`Planificado ${formatDate(p.plannedStart)} – ${formatDate(p.plannedEnd)}`}
                  >
                    <div className="h-full bg-primary" style={{ width: `${p.progress ?? 0}%` }} />
                  </div>
                )}
                {p.actualStart && (
                  <div
                    className="absolute top-7 h-1.5 rounded-sm bg-foreground/50"
                    style={{
                      left: `${pct(p.actualStart)}%`,
                      width: `max(${pct(p.actualEnd ?? today) - pct(p.actualStart)}%, 4px)`,
                    }}
                    title="Real"
                  />
                )}
                {p.milestones.map(
                  (m) =>
                    m.dueDate && (
                      <Flag
                        key={m.id}
                        className={cn('absolute top-1.5 size-3 -translate-x-1/2', m.status === 'alcanzado' ? 'text-success' : 'text-foreground')}
                        style={{ left: `${pct(m.dueDate)}%` }}
                        aria-label={`Hito ${m.title}`}
                      />
                    ),
                )}
              </div>
            </div>
          )
        })}
      </div>
      <div className="flex flex-wrap gap-4 border-t px-3 py-2 text-xs text-muted-foreground">
        <Legend className="bg-primary">Planificado (relleno = avance)</Legend>
        <Legend className="bg-foreground/50">Real</Legend>
        <Legend className="bg-destructive/60">Hoy</Legend>
      </div>
    </div>
  )
}

function Legend({ className, children }: { className: string; children: React.ReactNode }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className={cn('h-2 w-4 rounded-sm', className)} aria-hidden />
      {children}
    </span>
  )
}

const WEEKDAYS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']

function MonthCalendar({ phases, tasks }: { phases: Phase[]; tasks: Task[] }) {
  const [cursor, setCursor] = useState(() => {
    const now = new Date()
    return { y: now.getFullYear(), m: now.getMonth() }
  })
  const first = new Date(Date.UTC(cursor.y, cursor.m, 1))
  const offset = (first.getUTCDay() + 6) % 7
  const daysInMonth = new Date(Date.UTC(cursor.y, cursor.m + 1, 0)).getUTCDate()
  const cells = Array.from({ length: Math.ceil((offset + daysInMonth) / 7) * 7 }, (_, i) => {
    const day = i - offset + 1
    return day < 1 || day > daysInMonth ? null : `${cursor.y}-${String(cursor.m + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
  })
  const milestones = phases.flatMap((p) => p.milestones)
  const today = todayISO()
  const move = (delta: number) =>
    setCursor((c) => {
      const d = new Date(Date.UTC(c.y, c.m + delta, 1))
      return { y: d.getUTCFullYear(), m: d.getUTCMonth() }
    })

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <Button variant="outline" size="icon-sm" aria-label="Mes anterior" onClick={() => move(-1)}>
          <ChevronLeft />
        </Button>
        <Button variant="outline" size="icon-sm" aria-label="Mes siguiente" onClick={() => move(1)}>
          <ChevronRight />
        </Button>
        <h2 className="text-sm font-medium capitalize">
          {first.toLocaleDateString('es-AR', { month: 'long', year: 'numeric', timeZone: 'UTC' })}
        </h2>
      </div>
      <div className="grid grid-cols-7 overflow-hidden rounded-lg border">
        {WEEKDAYS.map((w) => (
          <div key={w} className="border-b bg-muted/40 px-2 py-1.5 text-xs text-muted-foreground">
            {w}
          </div>
        ))}
        {cells.map((iso, i) => {
          const dayMs = iso ? milestones.filter((m) => m.dueDate === iso) : []
          const dayTasks = iso ? tasks.filter((t) => t.dueDate === iso) : []
          const phaseStarts = iso ? phases.filter((p) => p.plannedStart === iso) : []
          return (
            <div key={i} className={cn('flex min-h-20 flex-col gap-1 border-b border-r p-1.5 text-xs [&:nth-child(7n)]:border-r-0', !iso && 'bg-muted/20')}>
              {iso && (
                <span className={cn('font-mono', iso === today ? 'font-bold text-primary' : 'text-muted-foreground')}>{Number(iso.slice(8))}</span>
              )}
              {phaseStarts.map((p) => (
                <span key={`p${p.id}`} className="truncate rounded bg-secondary px-1 py-0.5">
                  ▸ {p.name}
                </span>
              ))}
              {dayMs.map((m) => (
                <span key={`m${m.id}`} className="flex items-center gap-1 truncate rounded bg-primary/15 px-1 py-0.5 text-foreground">
                  <Flag className="size-3 shrink-0" aria-hidden /> <span className="truncate">{m.title}</span>
                </span>
              ))}
              {dayTasks.slice(0, 2).map((t) => (
                <span key={`t${t.id}`} className="truncate text-muted-foreground">
                  · {t.title}
                </span>
              ))}
              {dayTasks.length > 2 && <span className="text-muted-foreground">+{dayTasks.length - 2} más</span>}
            </div>
          )
        })}
      </div>
    </div>
  )
}

function PhaseList({
  phases,
  canManage,
  canVerify,
  onEditPhase,
  onNewMs,
  onEditMs,
}: {
  phases: Phase[]
  canManage: boolean
  canVerify: boolean
  onEditPhase: (p: Phase) => void
  onNewMs: (phaseId: number) => void
  onEditMs: (m: Milestone) => void
}) {
  const [pending, startTransition] = useTransition()
  const today = todayISO()

  function setStatus(m: Milestone, status: 'pendiente' | 'en_riesgo' | 'alcanzado') {
    if (status === 'alcanzado' && !window.confirm(`¿Confirmás que «${m.title}» cumple sus criterios de aceptación?`)) return
    startTransition(async () => {
      const res = await setMilestoneStatus(m.id, status)
      if (res.ok) toast.success('Hito actualizado')
      else toast.error(res.error)
    })
  }

  return (
    <ol className="flex flex-col gap-4">
      {phases.map((p) => {
        const late = p.plannedEnd && p.plannedEnd < today && (p.progress ?? 0) < 100 && !p.actualEnd
        return (
          <li key={p.id} className="rounded-lg border">
            <div className="flex flex-col gap-3 p-4 md:flex-row md:items-start md:justify-between">
              <div className="flex min-w-0 flex-col gap-1">
                <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold">
                  <span className="font-mono text-xs text-muted-foreground">{String(p.sort).padStart(2, '0')}</span>
                  {p.name}
                  {p.isDemo && <DemoBadge />}
                  {late && <span className="text-xs font-normal text-destructive">Retrasada</span>}
                </h3>
                {p.description && <p className="text-sm text-muted-foreground text-pretty">{p.description}</p>}
                <p className="font-mono text-xs text-muted-foreground">
                  Plan {formatDate(p.plannedStart)} – {formatDate(p.plannedEnd)}
                  {p.actualStart && ` · Real ${formatDate(p.actualStart)} – ${p.actualEnd ? formatDate(p.actualEnd) : 'en curso'}`}
                </p>
              </div>
              <div className="flex items-center gap-2 md:w-64">
                <ProgressBar value={p.progress} className="flex-1" label={`Avance de ${p.name}`} />
                {canManage && (
                  <Button variant="ghost" size="icon-sm" aria-label={`Editar ${p.name}`} onClick={() => onEditPhase(p)}>
                    <Pencil />
                  </Button>
                )}
              </div>
            </div>
            {(p.milestones.length > 0 || canManage) && (
              <ul className="divide-y border-t">
                {p.milestones.map((m) => (
                  <li key={m.id} className="flex flex-col gap-2 px-4 py-3 md:flex-row md:items-center">
                    <Flag className={cn('hidden size-4 shrink-0 md:block', m.status === 'alcanzado' ? 'text-success' : 'text-muted-foreground')} aria-hidden />
                    <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                      <span className="flex items-center gap-2 text-sm font-medium">
                        {m.title} {m.isDemo && <DemoBadge />}
                      </span>
                      <span className="text-xs text-muted-foreground text-pretty">
                        {formatDate(m.dueDate, true)} · {m.taskCount} tareas
                        {m.acceptanceCriteria && ` · Criterio: ${m.acceptanceCriteria}`}
                      </span>
                    </div>
                    <ProgressBar value={m.progress} className="md:w-36" label={`Avance de ${m.title}`} />
                    <span
                      className={cn(
                        'text-xs font-medium',
                        m.status === 'alcanzado' ? 'text-success' : m.status === 'en_riesgo' ? 'text-destructive' : 'text-muted-foreground',
                      )}
                    >
                      {MS_LABEL[m.status]}
                      {m.status !== 'alcanzado' && m.progress === 100 && ' · listo para verificar'}
                    </span>
                    <div className="flex gap-1">
                      {canVerify && m.status !== 'alcanzado' && (
                        <Button size="sm" variant="outline" disabled={pending} onClick={() => setStatus(m, 'alcanzado')}>
                          <CheckCircle2 /> Verificar
                        </Button>
                      )}
                      {canManage && m.status === 'pendiente' && (
                        <Button size="sm" variant="ghost" disabled={pending} onClick={() => setStatus(m, 'en_riesgo')}>
                          En riesgo
                        </Button>
                      )}
                      {canManage && m.status !== 'pendiente' && (
                        <Button size="sm" variant="ghost" disabled={pending} onClick={() => setStatus(m, 'pendiente')}>
                          Reabrir
                        </Button>
                      )}
                      {canManage && (
                        <Button variant="ghost" size="icon-sm" aria-label={`Editar ${m.title}`} onClick={() => onEditMs(m)}>
                          <Pencil />
                        </Button>
                      )}
                    </div>
                  </li>
                ))}
                {canManage && (
                  <li className="px-4 py-2">
                    <Button size="sm" variant="ghost" onClick={() => onNewMs(p.id)}>
                      <Plus /> Agregar hito
                    </Button>
                  </li>
                )}
              </ul>
            )}
          </li>
        )
      })}
    </ol>
  )
}

function PhaseDialog({ value, onClose }: { value: PhaseInput | null; onClose: () => void }) {
  const [form, setForm] = useState<PhaseInput | null>(value)
  const [pending, startTransition] = useTransition()
  const [prev, setPrev] = useState(value)
  if (value !== prev) {
    setPrev(value)
    setForm(value)
  }
  const set = (k: keyof PhaseInput, v: string) => setForm((f) => (f ? { ...f, [k]: k === 'name' || k === 'description' ? v : v || null } : f))

  return (
    <Dialog open={!!value} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        {form && (
          <form
            className="flex flex-col gap-4"
            onSubmit={(e) => {
              e.preventDefault()
              startTransition(async () => {
                const res = await savePhase(form)
                if (res.ok) {
                  toast.success('Fase guardada')
                  onClose()
                } else toast.error(res.error)
              })
            }}
          >
            <DialogHeader>
              <DialogTitle>{form.id ? 'Editar fase' : 'Nueva fase'}</DialogTitle>
            </DialogHeader>
            <Field label="Nombre" htmlFor="ph-name">
              <Input id="ph-name" required value={form.name} onChange={(e) => set('name', e.target.value)} />
            </Field>
            <Field label="Descripción" htmlFor="ph-desc">
              <Textarea id="ph-desc" rows={2} value={form.description} onChange={(e) => set('description', e.target.value)} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              {(
                [
                  ['plannedStart', 'Inicio planificado'],
                  ['plannedEnd', 'Fin planificado'],
                  ['actualStart', 'Inicio real'],
                  ['actualEnd', 'Fin real'],
                ] as const
              ).map(([k, label]) => (
                <Field key={k} label={label} htmlFor={`ph-${k}`}>
                  <Input id={`ph-${k}`} type="date" value={form[k] ?? ''} onChange={(e) => set(k, e.target.value)} />
                </Field>
              ))}
            </div>
            {form.id && <p className="text-xs text-muted-foreground">Los cambios de fechas planificadas quedan registrados en la auditoría.</p>}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancelar
              </Button>
              <Button type="submit" disabled={pending}>
                Guardar
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  )
}

function MilestoneDialog({ value, phases, onClose }: { value: MilestoneInput | null; phases: Phase[]; onClose: () => void }) {
  const [form, setForm] = useState<MilestoneInput | null>(value)
  const [pending, startTransition] = useTransition()
  const [prev, setPrev] = useState(value)
  if (value !== prev) {
    setPrev(value)
    setForm(value)
  }

  return (
    <Dialog open={!!value} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        {form && (
          <form
            className="flex flex-col gap-4"
            onSubmit={(e) => {
              e.preventDefault()
              startTransition(async () => {
                const res = await saveMilestone(form)
                if (res.ok) {
                  toast.success('Hito guardado')
                  onClose()
                } else toast.error(res.error)
              })
            }}
          >
            <DialogHeader>
              <DialogTitle>{form.id ? 'Editar hito' : 'Nuevo hito'}</DialogTitle>
            </DialogHeader>
            <Field label="Título" htmlFor="ms-title">
              <Input id="ms-title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </Field>
            <Field label="Fase" htmlFor="ms-phase">
              <NativeSelect id="ms-phase" value={form.phaseId} onChange={(e) => setForm({ ...form, phaseId: Number(e.target.value) })}>
                {phases.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.sort}. {p.name}
                  </option>
                ))}
              </NativeSelect>
            </Field>
            <Field label="Fecha objetivo" htmlFor="ms-due">
              <Input id="ms-due" type="date" value={form.dueDate ?? ''} onChange={(e) => setForm({ ...form, dueDate: e.target.value || null })} />
            </Field>
            <Field label="Descripción" htmlFor="ms-desc">
              <Textarea id="ms-desc" rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </Field>
            <Field label="Criterios de aceptación" htmlFor="ms-ac" hint="Se confirman al verificar el hito.">
              <Textarea
                id="ms-ac"
                rows={2}
                value={form.acceptanceCriteria}
                onChange={(e) => setForm({ ...form, acceptanceCriteria: e.target.value })}
              />
            </Field>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancelar
              </Button>
              <Button type="submit" disabled={pending}>
                Guardar
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  )
}
