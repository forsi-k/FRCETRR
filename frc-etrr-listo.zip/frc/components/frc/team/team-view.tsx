'use client'

import { useState, useTransition } from 'react'
import { toast } from 'sonner'
import { Pencil, Plus, Trash2, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, NativeSelect } from '@/components/frc/field'
import { DemoBadge, EmptyState, PageHeader } from '@/components/frc/shared'
import { initials } from '@/components/frc/format'
import { deleteMember, saveMember, type MemberInput } from '@/app/actions/frc-team'
import { TEAM_ROLES } from '@/lib/frc/roles'
import type { Member, Subsystem } from '@/lib/frc/data'
import { cn } from '@/lib/utils'

type Account = { id: string; name: string; email: string; role: string }
type Props = {
  members: Member[]
  subsystems: Subsystem[]
  accounts: Account[]
  load: Record<number, { open: number; critical: number }>
  limits: { open: number; critical: number }
  canManage: boolean
  canDelete: boolean
}

const toInput = (m?: Member): MemberInput => ({
  id: m?.id,
  fullName: m?.fullName ?? '',
  email: m?.email ?? '',
  teamRole: m?.teamRole ?? 'Integrante',
  primarySubsystemId: m?.primarySubsystemId ?? null,
  availability: m?.availability ?? '',
  status: m?.status === 'inactivo' ? 'inactivo' : 'activo',
  skills: m?.skills ?? [],
  subsystems: m?.subsystems ?? [],
  userId: m?.userId ?? null,
})

export function TeamView({ members, subsystems, accounts, load, limits, canManage, canDelete }: Props) {
  const [form, setForm] = useState<MemberInput | null>(null)
  const [pending, startTransition] = useTransition()
  const subName = (id: number | null) => subsystems.find((s) => s.id === id)?.name ?? '—'

  return (
    <>
      <PageHeader
        title="Equipo"
        description="Integrantes, roles, áreas y carga de trabajo actual."
        actions={
          canManage && (
            <Button size="sm" onClick={() => setForm(toInput())}>
              <Plus /> Agregar integrante
            </Button>
          )
        }
      />
      <div className="flex-1 px-4 py-5 md:px-8">
        {members.length === 0 ? (
          <EmptyState icon={Users} title="Todavía no hay integrantes" description="Agregá a los estudiantes, mentores y profesores del equipo." />
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {members.map((m) => {
              const l = load[m.id] ?? { open: 0, critical: 0 }
              const over = l.open > limits.open || l.critical > limits.critical
              const leads = m.subsystems.filter((s) => s.isLead).map((s) => subName(s.id))
              return (
                <li key={m.id} className={cn('flex flex-col gap-3 rounded-lg border p-4', m.status === 'inactivo' && 'opacity-60')}>
                  <div className="flex items-start gap-3">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-secondary font-mono text-xs font-medium">
                      {initials(m.fullName)}
                    </span>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <span className="flex items-center gap-2 truncate text-sm font-medium">
                        <span className="truncate">{m.fullName}</span>
                        {m.isDemo && <DemoBadge />}
                      </span>
                      <span className="truncate text-xs text-muted-foreground">
                        {m.teamRole} · {subName(m.primarySubsystemId)}
                      </span>
                    </div>
                    {canManage && (
                      <Button variant="ghost" size="icon-sm" aria-label={`Editar ${m.fullName}`} onClick={() => setForm(toInput(m))}>
                        <Pencil />
                      </Button>
                    )}
                  </div>
                  {leads.length > 0 && <p className="text-xs text-muted-foreground">Referente de {leads.join(', ')}</p>}
                  {m.skills.length > 0 && (
                    <ul className="flex flex-wrap gap-1">
                      {m.skills.map((s) => (
                        <li key={s} className="rounded bg-muted px-1.5 py-0.5 text-xs">
                          {s}
                        </li>
                      ))}
                    </ul>
                  )}
                  <div className="mt-auto flex items-center justify-between border-t pt-3 text-xs">
                    <span className={cn('font-mono', over ? 'font-medium text-destructive' : 'text-muted-foreground')}>
                      {l.open} abiertas · {l.critical} críticas{over && ' · sobrecarga'}
                    </span>
                    <span className="text-muted-foreground">
                      {m.userId ? (m.accountRole ?? 'cuenta') : 'sin cuenta'}
                      {m.status === 'inactivo' && ' · inactivo'}
                    </span>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </div>

      <Dialog open={!!form} onOpenChange={(o) => !o && setForm(null)}>
        <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-lg">
          {form && (
            <form
              className="flex flex-col gap-4"
              onSubmit={(e) => {
                e.preventDefault()
                startTransition(async () => {
                  const res = await saveMember(form)
                  if (res.ok) {
                    toast.success('Integrante guardado')
                    setForm(null)
                  } else toast.error(res.error)
                })
              }}
            >
              <DialogHeader>
                <DialogTitle>{form.id ? 'Editar integrante' : 'Nuevo integrante'}</DialogTitle>
              </DialogHeader>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Nombre completo" htmlFor="m-name" className="sm:col-span-2">
                  <Input id="m-name" required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
                </Field>
                <Field label="Email" htmlFor="m-email">
                  <Input id="m-email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </Field>
                <Field label="Rol en el equipo" htmlFor="m-role">
                  <NativeSelect id="m-role" value={form.teamRole} onChange={(e) => setForm({ ...form, teamRole: e.target.value })}>
                    {TEAM_ROLES.map((r) => (
                      <option key={r}>{r}</option>
                    ))}
                  </NativeSelect>
                </Field>
                <Field label="Subsistema principal" htmlFor="m-sub">
                  <NativeSelect
                    id="m-sub"
                    value={form.primarySubsystemId ?? ''}
                    onChange={(e) => setForm({ ...form, primarySubsystemId: e.target.value ? Number(e.target.value) : null })}
                  >
                    <option value="">—</option>
                    {subsystems.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.parentId ? `— ${s.name}` : s.name}
                      </option>
                    ))}
                  </NativeSelect>
                </Field>
                <Field label="Estado" htmlFor="m-status">
                  <NativeSelect
                    id="m-status"
                    value={form.status}
                    onChange={(e) => setForm({ ...form, status: e.target.value as MemberInput['status'] })}
                  >
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>
                  </NativeSelect>
                </Field>
                <Field label="Disponibilidad" htmlFor="m-avail" className="sm:col-span-2">
                  <Input
                    id="m-avail"
                    placeholder="Ej.: martes y jueves por la tarde"
                    value={form.availability}
                    onChange={(e) => setForm({ ...form, availability: e.target.value })}
                  />
                </Field>
                <Field label="Habilidades" htmlFor="m-skills" hint="Separadas por coma." className="sm:col-span-2">
                  <Input
                    id="m-skills"
                    value={form.skills.join(', ')}
                    onChange={(e) => setForm({ ...form, skills: e.target.value.split(',').map((s) => s.trimStart()) })}
                  />
                </Field>
                {accounts.length > 0 && (
                  <Field label="Cuenta vinculada" htmlFor="m-user" hint="Permite que vea «Mis tareas» y trabaje sobre las suyas." className="sm:col-span-2">
                    <NativeSelect id="m-user" value={form.userId ?? ''} onChange={(e) => setForm({ ...form, userId: e.target.value || null })}>
                      <option value="">Sin cuenta</option>
                      {accounts.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name} ({a.email})
                        </option>
                      ))}
                    </NativeSelect>
                  </Field>
                )}
              </div>
              <fieldset className="flex flex-col gap-1.5">
                <legend className="mb-1.5 text-xs font-medium text-muted-foreground">Áreas y referencia</legend>
                <div className="flex max-h-40 flex-col overflow-y-auto rounded-md border p-1">
                  {subsystems.map((s) => {
                    const entry = form.subsystems.find((x) => x.id === s.id)
                    const update = (next: { id: number; isLead: boolean } | null) =>
                      setForm({ ...form, subsystems: [...form.subsystems.filter((x) => x.id !== s.id), ...(next ? [next] : [])] })
                    return (
                      <div key={s.id} className="flex items-center justify-between gap-2 rounded px-2 py-1 text-sm hover:bg-muted">
                        <label className="flex items-center gap-2">
                          <input type="checkbox" className="accent-primary" checked={!!entry} onChange={() => update(entry ? null : { id: s.id, isLead: false })} />
                          {s.parentId ? `— ${s.name}` : s.name}
                        </label>
                        {entry && (
                          <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <input type="checkbox" className="accent-primary" checked={entry.isLead} onChange={() => update({ id: s.id, isLead: !entry.isLead })} />
                            Referente
                          </label>
                        )}
                      </div>
                    )
                  })}
                </div>
              </fieldset>
              <DialogFooter className="sm:justify-between">
                {form.id && canDelete ? (
                  <Button
                    type="button"
                    variant="ghost"
                    className="text-destructive"
                    disabled={pending}
                    onClick={() => {
                      if (!window.confirm(`¿Quitar a ${form.fullName} del equipo? Sus tareas quedan sin responsable.`)) return
                      startTransition(async () => {
                        const res = await deleteMember(form.id!)
                        if (res.ok) {
                          toast.success('Integrante eliminado')
                          setForm(null)
                        } else toast.error(res.error)
                      })
                    }}
                  >
                    <Trash2 /> Eliminar
                  </Button>
                ) : (
                  <span />
                )}
                <div className="flex gap-2">
                  <Button type="button" variant="outline" onClick={() => setForm(null)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={pending}>
                    Guardar
                  </Button>
                </div>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
