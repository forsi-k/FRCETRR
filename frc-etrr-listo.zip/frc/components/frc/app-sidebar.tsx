'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import {
  Activity,
  BookOpen,
  CalendarRange,
  GraduationCap,
  LayoutDashboard,
  ListChecks,
  LogOut,
  Settings,
  Users,
} from 'lucide-react'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from '@/components/ui/sidebar'
import { Button } from '@/components/ui/button'
import { authClient } from '@/lib/auth-client'
import { initials } from './format'

const NAV = [
  { href: '/', label: 'Resumen', icon: LayoutDashboard },
  { href: '/tareas', label: 'Tareas', icon: ListChecks },
  { href: '/planificacion', label: 'Planificación', icon: CalendarRange },
  { href: '/equipo', label: 'Equipo', icon: Users },
  { href: '/capacitacion', label: 'Capacitación', icon: GraduationCap },
  { href: '/documentacion', label: 'Documentación', icon: BookOpen },
  { href: '/actividad', label: 'Actividad', icon: Activity },
]

type Props = {
  projectName: string
  season: string
  user: { name: string; email: string; roleLabel: string }
  isAdmin: boolean
}

export function AppSidebar({ projectName, season, user, isAdmin }: Props) {
  const pathname = usePathname()
  const router = useRouter()
  const { setOpenMobile } = useSidebar()
  const isActive = (href: string) => (href === '/' ? pathname === '/' : pathname.startsWith(href))
  const items = isAdmin ? [...NAV, { href: '/configuracion', label: 'Configuración', icon: Settings }] : NAV

  async function signOut() {
    await authClient.signOut()
    router.push('/sign-in')
    router.refresh()
  }

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex size-8 items-center justify-center rounded-md bg-primary font-mono text-xs font-bold text-primary-foreground">
            ETRR
          </div>
          <div className="flex min-w-0 flex-col">
            <span className="truncate text-sm font-semibold">{projectName}</span>
            <span className="font-mono text-xs text-muted-foreground">FRC · temporada {season}</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Proyecto</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    isActive={isActive(item.href)}
                    render={<Link href={item.href} onClick={() => setOpenMobile(false)} />}
                  >
                    <item.icon />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border">
        <div className="flex items-center gap-2 px-1 py-1">
          <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-sidebar-accent text-xs font-medium">
            {initials(user.name)}
          </div>
          <div className="flex min-w-0 flex-1 flex-col">
            <span className="truncate text-sm font-medium">{user.name}</span>
            <span className="truncate text-xs text-muted-foreground">{user.roleLabel}</span>
          </div>
          <Button variant="ghost" size="icon-sm" aria-label="Cerrar sesión" onClick={signOut}>
            <LogOut />
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
