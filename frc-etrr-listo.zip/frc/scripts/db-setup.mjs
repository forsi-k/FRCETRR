// Crea las tablas y carga los datos iniciales. Uso: node --env-file=.env.local scripts/db-setup.mjs
import { readFileSync } from 'node:fs'
import pg from 'pg'

const url = process.env.DATABASE_URL
if (!url) {
  console.error('Falta DATABASE_URL (ver .env.example)')
  process.exit(1)
}
const ssl = /sslmode=require|neon\.tech|supabase\.co/.test(url) ? { rejectUnauthorized: false } : undefined
const client = new pg.Client({ connectionString: url, ssl })
await client.connect()
try {
  for (const file of ['db/schema.sql', 'db/seed.sql']) {
    await client.query(readFileSync(new URL(`../${file}`, import.meta.url), 'utf8'))
    console.log(`✔ ${file}`)
  }
} finally {
  await client.end()
}
