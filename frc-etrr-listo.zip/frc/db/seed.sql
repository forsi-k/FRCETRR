-- Datos iniciales mínimos: el proyecto (id=1, lo exige lib/frc/session.ts) y la estructura de subsistemas.
-- Los registros marcados is_demo = true se pueden borrar desde Configuración.
INSERT INTO frc_projects (id, name, institution, season, objective)
VALUES (1, 'FRC ETRR', 'ETRR', '2027', 'Diseñar, construir y competir con un robot en FIRST Robotics Competition.')
ON CONFLICT (id) DO NOTHING;

INSERT INTO frc_subsystems (project_id, name, sort)
SELECT 1, s.name, s.sort FROM (VALUES
  ('Mecánica', 1), ('Electrónica', 2), ('Programación', 3), ('Estrategia', 4), ('Diseño y comunicación', 5)
) AS s(name, sort)
WHERE NOT EXISTS (SELECT 1 FROM frc_subsystems WHERE project_id = 1);

INSERT INTO frc_phases (project_id, name, description, sort, is_demo)
SELECT 1, 'Kickoff y estrategia', 'Análisis del juego y definición de prioridades.', 1, true
WHERE NOT EXISTS (SELECT 1 FROM frc_phases WHERE project_id = 1);
