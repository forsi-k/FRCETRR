-- FRC Virtual Hub · esquema completo (idempotente: se puede correr varias veces)
-- Uso: node scripts/db-setup.mjs   (o psql "$DATABASE_URL" -f db/schema.sql)

-- ───────── better-auth (usuarios y sesiones) ─────────
CREATE TABLE IF NOT EXISTS "user" (
  id              text PRIMARY KEY,
  name            text NOT NULL,
  email           text NOT NULL UNIQUE,
  "emailVerified" boolean NOT NULL DEFAULT false,
  image           text,
  "createdAt"     timestamptz NOT NULL DEFAULT now(),
  "updatedAt"     timestamptz NOT NULL DEFAULT now(),
  role            text NOT NULL DEFAULT 'member',
  -- columnas del módulo Ecodesafío (legado)
  area            text NOT NULL DEFAULT '',
  team_role       text NOT NULL DEFAULT 'colaborador'
);

CREATE TABLE IF NOT EXISTS session (
  id          text PRIMARY KEY,
  "expiresAt" timestamptz NOT NULL,
  token       text NOT NULL UNIQUE,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now(),
  "ipAddress" text,
  "userAgent" text,
  "userId"    text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS session_user_idx ON session ("userId");

CREATE TABLE IF NOT EXISTS account (
  id                      text PRIMARY KEY,
  "accountId"             text NOT NULL,
  "providerId"            text NOT NULL,
  "userId"                text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  "accessToken"           text,
  "refreshToken"          text,
  "idToken"               text,
  "accessTokenExpiresAt"  timestamptz,
  "refreshTokenExpiresAt" timestamptz,
  scope                   text,
  password                text,
  "createdAt"             timestamptz NOT NULL DEFAULT now(),
  "updatedAt"             timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS account_user_idx ON account ("userId");

CREATE TABLE IF NOT EXISTS verification (
  id          text PRIMARY KEY,
  identifier  text NOT NULL,
  value       text NOT NULL,
  "expiresAt" timestamptz NOT NULL,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now()
);

-- ───────── FRC: proyecto, subsistemas, equipo ─────────
CREATE TABLE IF NOT EXISTS frc_projects (
  id                       integer PRIMARY KEY,
  name                     text NOT NULL,
  institution              text NOT NULL DEFAULT '',
  competition              text NOT NULL DEFAULT 'FIRST Robotics Competition',
  season                   text NOT NULL DEFAULT '',
  kickoff_date             date,
  team_number              text,
  event_name               text,
  event_date               date,
  objective                text NOT NULL DEFAULT '',
  overload_open_threshold  integer NOT NULL DEFAULT 5,
  overload_critical_threshold integer NOT NULL DEFAULT 2
);

CREATE TABLE IF NOT EXISTS frc_subsystems (
  id         serial PRIMARY KEY,
  project_id integer NOT NULL REFERENCES frc_projects(id) ON DELETE CASCADE,
  name       text NOT NULL,
  parent_id  integer REFERENCES frc_subsystems(id) ON DELETE SET NULL,
  sort       integer NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS frc_team_members (
  id                   serial PRIMARY KEY,
  project_id           integer NOT NULL REFERENCES frc_projects(id) ON DELETE CASCADE,
  user_id              text UNIQUE REFERENCES "user"(id) ON DELETE SET NULL,
  full_name            text NOT NULL,
  email                text,
  team_role            text NOT NULL DEFAULT 'Integrante',
  primary_subsystem_id integer REFERENCES frc_subsystems(id) ON DELETE SET NULL,
  availability         text NOT NULL DEFAULT '',
  participation_status text NOT NULL DEFAULT 'activo' CHECK (participation_status IN ('activo','inactivo')),
  skills               text[] NOT NULL DEFAULT '{}',
  is_demo              boolean NOT NULL DEFAULT false,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS frc_member_subsystems (
  member_id    integer NOT NULL REFERENCES frc_team_members(id) ON DELETE CASCADE,
  subsystem_id integer NOT NULL REFERENCES frc_subsystems(id) ON DELETE CASCADE,
  is_lead      boolean NOT NULL DEFAULT false,
  PRIMARY KEY (member_id, subsystem_id)
);

-- ───────── FRC: planificación ─────────
CREATE TABLE IF NOT EXISTS frc_phases (
  id            serial PRIMARY KEY,
  project_id    integer NOT NULL REFERENCES frc_projects(id) ON DELETE CASCADE,
  name          text NOT NULL,
  description   text NOT NULL DEFAULT '',
  sort          integer NOT NULL DEFAULT 0,
  planned_start date,
  planned_end   date,
  actual_start  date,
  actual_end    date,
  is_demo       boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS frc_milestones (
  id                  serial PRIMARY KEY,
  phase_id            integer NOT NULL REFERENCES frc_phases(id) ON DELETE CASCADE,
  title               text NOT NULL,
  description         text NOT NULL DEFAULT '',
  due_date            date,
  acceptance_criteria text NOT NULL DEFAULT '',
  status              text NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente','en_riesgo','alcanzado')),
  achieved_at         timestamptz,
  verified_by         text,
  is_demo             boolean NOT NULL DEFAULT false,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

-- ───────── FRC: tareas ─────────
CREATE TABLE IF NOT EXISTS frc_tasks (
  id                  serial PRIMARY KEY,
  project_id          integer NOT NULL REFERENCES frc_projects(id) ON DELETE CASCADE,
  title               text NOT NULL,
  description         text NOT NULL DEFAULT '',
  owner_member_id     integer REFERENCES frc_team_members(id) ON DELETE SET NULL,
  subsystem_id        integer REFERENCES frc_subsystems(id) ON DELETE SET NULL,
  phase_id            integer REFERENCES frc_phases(id) ON DELETE SET NULL,
  milestone_id        integer REFERENCES frc_milestones(id) ON DELETE SET NULL,
  parent_task_id      integer REFERENCES frc_tasks(id) ON DELETE CASCADE,
  priority            text NOT NULL DEFAULT 'Media' CHECK (priority IN ('Baja','Media','Alta','Crítica')),
  status              text NOT NULL DEFAULT 'Pendiente'
                      CHECK (status IN ('Pendiente','En curso','Bloqueada','En revisión','Completada','Cancelada')),
  blocked_reason      text,
  start_date          date,
  due_date            date,
  deliverable         text NOT NULL DEFAULT '',
  acceptance_criteria text NOT NULL DEFAULT '',
  verified_by         text,
  verified_at         timestamptz,
  completed_at        timestamptz,
  created_by          text REFERENCES "user"(id) ON DELETE SET NULL,
  is_demo             boolean NOT NULL DEFAULT false,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS frc_tasks_project_due_idx ON frc_tasks (project_id, due_date);
CREATE INDEX IF NOT EXISTS frc_tasks_parent_idx ON frc_tasks (parent_task_id);

CREATE TABLE IF NOT EXISTS frc_task_collaborators (
  task_id   integer NOT NULL REFERENCES frc_tasks(id) ON DELETE CASCADE,
  member_id integer NOT NULL REFERENCES frc_team_members(id) ON DELETE CASCADE,
  PRIMARY KEY (task_id, member_id)
);

CREATE TABLE IF NOT EXISTS frc_task_dependencies (
  task_id       integer NOT NULL REFERENCES frc_tasks(id) ON DELETE CASCADE,
  depends_on_id integer NOT NULL REFERENCES frc_tasks(id) ON DELETE CASCADE,
  PRIMARY KEY (task_id, depends_on_id),
  CHECK (task_id <> depends_on_id)
);

CREATE TABLE IF NOT EXISTS frc_task_comments (
  id             serial PRIMARY KEY,
  task_id        integer NOT NULL REFERENCES frc_tasks(id) ON DELETE CASCADE,
  author_user_id text REFERENCES "user"(id) ON DELETE SET NULL,
  author_name    text NOT NULL,
  body           text NOT NULL,
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS frc_task_comments_task_idx ON frc_task_comments (task_id, created_at);

-- ───────── FRC: auditoría y capacitación ─────────
CREATE TABLE IF NOT EXISTS frc_audit_logs (
  id            serial PRIMARY KEY,
  actor_user_id text,
  actor_name    text NOT NULL,
  actor_role    text NOT NULL DEFAULT '',
  action        text NOT NULL,
  entity_type   text NOT NULL,
  entity_id     integer,
  summary       text NOT NULL,
  changes       jsonb,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS frc_audit_entity_idx ON frc_audit_logs (entity_type, entity_id, created_at DESC);
CREATE INDEX IF NOT EXISTS frc_audit_created_idx ON frc_audit_logs (created_at DESC);

-- La interfaz de capacitación aún no existe; la tabla ya la usa "borrar datos demo".
CREATE TABLE IF NOT EXISTS frc_training_modules (
  id          serial PRIMARY KEY,
  project_id  integer NOT NULL REFERENCES frc_projects(id) ON DELETE CASCADE,
  title       text NOT NULL,
  description text NOT NULL DEFAULT '',
  subsystem_id integer REFERENCES frc_subsystems(id) ON DELETE SET NULL,
  is_demo     boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- ───────── Ecodesafío (módulo legado) ─────────
CREATE TABLE IF NOT EXISTS ecodesafio_tasks (
  id         serial PRIMARY KEY,
  title      text NOT NULL,
  area       text NOT NULL DEFAULT '',
  owner      text NOT NULL DEFAULT '',
  due_date   date,
  started_at date,
  status     text NOT NULL DEFAULT 'Pendiente',
  priority   text NOT NULL DEFAULT 'Media',
  progress   integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ecodesafio_tool_requests (
  id          serial PRIMARY KEY,
  tool        text NOT NULL,
  quantity    integer NOT NULL DEFAULT 1,
  responsible text NOT NULL DEFAULT '',
  week        text NOT NULL DEFAULT '',
  status      text NOT NULL DEFAULT 'Pendiente',
  installed   boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ecodesafio_milestones (
  id         serial PRIMARY KEY,
  title      text NOT NULL,
  event_date date,
  tone       text NOT NULL DEFAULT 'orange',
  task_id    integer REFERENCES ecodesafio_tasks(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS ecodesafio_sponsors (
  id           serial PRIMARY KEY,
  name         text NOT NULL,
  contribution text NOT NULL DEFAULT '',
  kind         text NOT NULL DEFAULT 'Físico',
  amount       numeric NOT NULL DEFAULT 0,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ecodesafio_work_sessions (
  id           serial PRIMARY KEY,
  session_date date NOT NULL,
  hours        numeric NOT NULL DEFAULT 0,
  deliverable  text NOT NULL DEFAULT '',
  notes        text NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS ecodesafio_session_deliverables (
  id          serial PRIMARY KEY,
  session_id  integer NOT NULL REFERENCES ecodesafio_work_sessions(id) ON DELETE CASCADE,
  area        text NOT NULL,
  description text NOT NULL DEFAULT '',
  status      text NOT NULL DEFAULT 'Pendiente',
  comment     text NOT NULL DEFAULT '',
  defined_by  text,
  reported_by text,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, area)
);

CREATE TABLE IF NOT EXISTS ecodesafio_activity_log (
  id           serial PRIMARY KEY,
  actor_name   text NOT NULL,
  actor_role   text NOT NULL DEFAULT '',
  action       text NOT NULL,
  entity_type  text NOT NULL,
  entity_label text NOT NULL,
  detail       text,
  created_at   timestamptz NOT NULL DEFAULT now()
);
