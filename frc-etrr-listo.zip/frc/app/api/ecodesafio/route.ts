import { NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { sql } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { logActivity } from '@/lib/activity-log'

type AppRole = 'admin' | 'coordinacion' | 'member'
const DELIVERABLE_AREAS = ['Mecánica', 'Electrónica', 'Electricidad']
const DELIVERABLE_STATUSES = ['Pendiente', 'Cumplido', 'Parcial', 'No cumplido']

async function getSessionUser(): Promise<{ id: string; name: string; role: AppRole } | null> {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return null
  const rawRole = (session.user as { role?: string }).role
  const role: AppRole = rawRole === 'admin' || rawRole === 'coordinacion' ? rawRole : 'member'
  return { id: session.user.id, name: session.user.name, role }
}

const canDefineDeliverables = (role: AppRole) => role === 'coordinacion' || role === 'admin'

const SESSION_SELECT = sql`SELECT s.id, s.session_date::text as date, s.hours, s.deliverable, s.notes,
  COALESCE(json_agg(json_build_object('id', d.id, 'area', d.area, 'description', d.description, 'status', d.status, 'comment', d.comment, 'definedBy', d.defined_by, 'reportedBy', d.reported_by, 'updatedAt', d.updated_at) ORDER BY array_position(ARRAY['Mecánica','Electrónica','Electricidad'], d.area)) FILTER (WHERE d.id IS NOT NULL), '[]') as deliverables
  FROM ecodesafio_work_sessions s LEFT JOIN ecodesafio_session_deliverables d ON d.session_id = s.id`

async function loadSession(id: number) {
  const result = await db.execute(sql`${SESSION_SELECT} WHERE s.id = ${id} GROUP BY s.id`)
  return result.rows[0]
}

export async function GET() {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  const [tasks, members, tools, milestones, logs, sponsors, sessions] = await Promise.all([
    db.execute(sql`SELECT id, title, area, owner, due_date as due, started_at as "startedAt", status, priority, progress FROM ecodesafio_tasks ORDER BY due_date NULLS LAST, id`),
    db.execute(sql`SELECT id, name, role, area, team_role as "teamRole" FROM "user" ORDER BY "createdAt" ASC`),
    db.execute(sql`SELECT id, tool, quantity, responsible, week, status, installed FROM ecodesafio_tool_requests ORDER BY created_at DESC`),
    db.execute(sql`SELECT id, title, event_date as "eventDate", tone, task_id as "taskId" FROM ecodesafio_milestones ORDER BY event_date, id`),
    db.execute(sql`SELECT id, actor_name as "actorName", actor_role as "actorRole", action, entity_type as "entityType", entity_label as "entityLabel", detail, created_at as "createdAt" FROM ecodesafio_activity_log ORDER BY created_at DESC LIMIT 80`),
    db.execute(sql`SELECT id, name, contribution, kind, amount FROM ecodesafio_sponsors ORDER BY created_at DESC`),
    db.execute(sql`${SESSION_SELECT} GROUP BY s.id ORDER BY s.session_date`),
  ])
  return NextResponse.json({ tasks: tasks.rows, members: members.rows, tools: tools.rows, milestones: milestones.rows, logs: logs.rows, sponsors: sponsors.rows, sessions: sessions.rows, viewerRole: user.role })
}

export async function POST(request: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  const body = await request.json()
  if (body.type === 'task') {
    const result = await db.execute(sql`INSERT INTO ecodesafio_tasks (title, area, owner, due_date, status, priority, progress) VALUES (${body.title}, ${body.area}, ${body.owner ?? ''}, ${body.due || null}, 'Pendiente', ${body.priority ?? 'Media'}, 0) RETURNING id, title, area, owner, due_date as due, started_at as "startedAt", status, priority, progress`)
    await logActivity(user, 'Creó', 'la tarea', body.title)
    return NextResponse.json(result.rows[0], { status: 201 })
  }
  if (body.type === 'tool') {
    const result = await db.execute(sql`INSERT INTO ecodesafio_tool_requests (tool, quantity, week, status, installed) VALUES (${body.tool}, ${Number(body.quantity)}, 'Semana actual', 'Pendiente', ${Boolean(body.installed)}) RETURNING id, tool, quantity, installed`)
    await logActivity(user, 'Agregó', 'la herramienta', `${body.tool} (x${body.quantity})`)
    return NextResponse.json(result.rows[0], { status: 201 })
  }
  if (body.type === 'milestone') {
    const result = await db.execute(sql`INSERT INTO ecodesafio_milestones (title, event_date, tone, task_id) VALUES (${body.title}, ${body.eventDate}, 'orange', ${body.taskId ? Number(body.taskId) : null}) RETURNING id, title, event_date as "eventDate", tone, task_id as "taskId"`)
    await logActivity(user, 'Creó', 'el hito', body.title)
    return NextResponse.json(result.rows[0], { status: 201 })
  }
  if (body.type === 'sponsor') {
    const kind = ['Dinero', 'Físico', 'Servicio'].includes(body.kind) ? body.kind : 'Físico'
    const amount = kind === 'Dinero' ? Number(body.amount) || 0 : 0
    const contribution = kind === 'Dinero' ? `Aporte de $${amount.toLocaleString('es-AR')}` : (body.contribution ?? '')
    const result = await db.execute(sql`INSERT INTO ecodesafio_sponsors (name, contribution, kind, amount) VALUES (${body.name}, ${contribution}, ${kind}, ${amount}) RETURNING id, name, contribution, kind, amount`)
    await logActivity(user, 'Agregó', 'al sponsor', body.name, contribution)
    return NextResponse.json(result.rows[0], { status: 201 })
  }
  return NextResponse.json({ error: 'Tipo no soportado' }, { status: 400 })
}

export async function PATCH(request: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  const body = await request.json()
  if (body.type === 'task') {
    const status = body.status ?? 'Pendiente'
    if (status === 'En curso' && !body.startedAt) {
      return NextResponse.json({ error: 'Ingresá la fecha de inicio para poner la tarea en curso' }, { status: 400 })
    }
    const startedAt = body.startedAt || null
    const result = await db.execute(sql`UPDATE ecodesafio_tasks SET title = ${body.title}, area = ${body.area}, owner = ${body.owner ?? ''}, started_at = ${startedAt}, due_date = ${body.due || null}, status = ${status}, priority = ${body.priority ?? 'Media'}, progress = CASE ${status} WHEN 'Completada' THEN 100 WHEN 'En curso' THEN 50 WHEN 'Bloqueada' THEN 25 ELSE 0 END WHERE id = ${Number(body.id)} RETURNING id, title, area, owner, due_date as due, started_at as "startedAt", status, priority, progress`)
    if (!result.rows[0]) return NextResponse.json({ error: 'Tarea no encontrada' }, { status: 404 })
    await logActivity(user, 'Actualizó', 'la tarea', body.title, `Estado: ${status}${startedAt ? ` · Inicio: ${startedAt}` : ''}`)
    return NextResponse.json(result.rows[0])
  }
  if (body.type === 'tool') {
    const result = await db.execute(sql`UPDATE ecodesafio_tool_requests SET tool = ${body.tool}, quantity = ${Number(body.quantity)}, installed = ${Boolean(body.installed)} WHERE id = ${Number(body.id)} RETURNING id, tool, quantity, installed`)
    if (!result.rows[0]) return NextResponse.json({ error: 'Herramienta no encontrada' }, { status: 404 })
    await logActivity(user, 'Actualizó', 'la herramienta', String(result.rows[0].tool))
    return NextResponse.json(result.rows[0])
  }
  const text = (value: unknown) => String(value ?? '').trim().slice(0, 2000)
  if (body.type === 'session-plan') {
    if (!canDefineDeliverables(user.role)) {
      return NextResponse.json({ error: 'Solo coordinación puede definir los entregables' }, { status: 403 })
    }
    const sessionId = Number(body.id)
    const plan = (body.deliverables ?? {}) as Record<string, unknown>
    const updated = await db.execute(sql`UPDATE ecodesafio_work_sessions SET deliverable = ${text(body.deliverable)} WHERE id = ${sessionId} RETURNING session_date::text as date`)
    if (!updated.rows[0]) return NextResponse.json({ error: 'Jornada no encontrada' }, { status: 404 })
    for (const area of DELIVERABLE_AREAS) {
      if (!(area in plan)) continue
      await db.execute(sql`INSERT INTO ecodesafio_session_deliverables (session_id, area, description, defined_by, updated_at)
        VALUES (${sessionId}, ${area}, ${text(plan[area])}, ${user.name}, now())
        ON CONFLICT (session_id, area) DO UPDATE SET description = EXCLUDED.description, defined_by = EXCLUDED.defined_by, updated_at = now()
        WHERE ecodesafio_session_deliverables.description IS DISTINCT FROM EXCLUDED.description`)
    }
    await logActivity(user, 'Definió', 'los entregables de la jornada', String(updated.rows[0].date))
    return NextResponse.json(await loadSession(sessionId))
  }
  if (body.type === 'deliverable-report') {
    const status = DELIVERABLE_STATUSES.includes(body.status) ? body.status : 'Pendiente'
    const result = await db.execute(sql`UPDATE ecodesafio_session_deliverables SET status = ${status}, comment = ${text(body.comment)}, reported_by = ${user.name}, updated_at = now() WHERE id = ${Number(body.id)} RETURNING session_id as "sessionId", area`)
    const row = result.rows[0] as { sessionId: number; area: string } | undefined
    if (!row) return NextResponse.json({ error: 'Entregable no encontrado' }, { status: 404 })
    const session = await loadSession(Number(row.sessionId))
    await logActivity(user, 'Reportó', `el entregable de ${row.area}`, String(session?.date ?? ''), `${status}${text(body.comment) ? ` · ${text(body.comment)}` : ''}`)
    return NextResponse.json(session)
  }
  return NextResponse.json({ error: 'Tipo no soportado' }, { status: 400 })
}

export async function DELETE(request: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  const body = await request.json()
  if (body.type === 'milestone') {
    const result = await db.execute(sql`DELETE FROM ecodesafio_milestones WHERE id = ${Number(body.id)} RETURNING id, title`)
    if (result.rows[0]) await logActivity(user, 'Eliminó', 'el hito', String(result.rows[0].title))
    return NextResponse.json({ ok: true })
  }
  if (body.type === 'task') {
    const result = await db.execute(sql`DELETE FROM ecodesafio_tasks WHERE id = ${Number(body.id)} RETURNING id, title`)
    if (!result.rows[0]) return NextResponse.json({ error: 'Tarea no encontrada' }, { status: 404 })
    await logActivity(user, 'Eliminó', 'la tarea', String(result.rows[0].title))
    return NextResponse.json({ ok: true, id: result.rows[0].id })
  }
  if (body.type === 'tool') {
    const result = await db.execute(sql`DELETE FROM ecodesafio_tool_requests WHERE id = ${Number(body.id)} RETURNING id, tool`)
    if (!result.rows[0]) return NextResponse.json({ error: 'Herramienta no encontrada' }, { status: 404 })
    await logActivity(user, 'Eliminó', 'la herramienta', String(result.rows[0].tool))
    return NextResponse.json({ ok: true, id: result.rows[0].id })
  }
  if (body.type === 'sponsor') {
    const result = await db.execute(sql`DELETE FROM ecodesafio_sponsors WHERE id = ${Number(body.id)} RETURNING id, name`)
    if (!result.rows[0]) return NextResponse.json({ error: 'Sponsor no encontrado' }, { status: 404 })
    await logActivity(user, 'Eliminó', 'al sponsor', String(result.rows[0].name))
    return NextResponse.json({ ok: true, id: result.rows[0].id })
  }
  return NextResponse.json({ error: 'Tipo no soportado' }, { status: 400 })
}
