import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { sql } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { AppShell } from '@/components/app-shell'

export const metadata = { title: 'Panel anterior' }

type AppRole = 'admin' | 'coordinacion' | 'member'
// New FRC roles map onto the legacy app's three roles.
const normalizeRole = (value: unknown): AppRole =>
  value === 'admin' ? 'admin' : value === 'coordinacion' || value === 'profesor' ? 'coordinacion' : 'member'

export default async function EcodesafioPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect('/sign-in')
  const role = normalizeRole((session.user as { role?: string }).role)

  let accounts: { id: string; name: string; email: string; role: AppRole; area: string; teamRole: 'lider' | 'colaborador' }[] = []
  if (role === 'admin') {
    const result = await db.execute(sql`SELECT id, name, email, role, area, team_role as "teamRole" FROM "user" ORDER BY "createdAt" ASC`)
    accounts = result.rows.map((row) => ({
      id: String(row.id),
      name: String(row.name),
      email: String(row.email),
      role: normalizeRole(row.role),
      area: String(row.area ?? ''),
      teamRole: row.teamRole === 'lider' ? 'lider' : 'colaborador',
    }))
  }

  return (
    <div className="ecodesafio">
      <AppShell role={role} userName={session.user.name} accounts={accounts} />
    </div>
  )
}
