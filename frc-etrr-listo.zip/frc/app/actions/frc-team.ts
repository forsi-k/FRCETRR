'use server'

import { revalidatePath } from 'next/cache'
import { sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import { requireActionContext, PROJECT_ID } from '@/lib/frc/session'
import { can } from '@/lib/frc/permissions'
import { audit } from '@/lib/frc/audit'
import { normalizeRole } from '@/lib/frc/roles'

type Result = { ok: true; id?: number } | { ok: false; error: string }
const isDate = (v: string | null) => v === null || /^\d{4}-\d{2}-\d{2}$/.test(v)

export type MemberInput = {
  id?: number
  fullName: string
  email: string
  teamRole: string
  primarySubsystemId: number | null
  availability: string
  status: 'activo' | 'inactivo'
  skills: string[]
  subsystems: { id: number; isLead: boolean }[]
  userId: string | null
}

export async function saveMember(input: MemberInput): Promise<Result> {
  const ctx = await requireActionContext()
  if (!can.manageTeam(ctx)) return { ok: false, error: 'Solo profesores y administradores gestionan el equipo' }
  const fullName = input.fullName?.trim()
  if (!fullName) return { ok: false, error: 'El nombre es obligatorio' }
  const email = input.email?.trim().toLowerCase() || null
  const status = input.status === 'inactivo' ? 'inactivo' : 'activo'
  const skills = (input.skills ?? []).map((s) => s.trim()).filter(Boolean).slice(0, 30)
  const skillsLiteral = `{${skills.map((s) => `"${s.replace(/["\\]/g, '')}"`).join(',')}}`
  const primary = input.primarySubsystemId && input.primarySubsystemId > 0 ? input.primarySubsystemId : null
  const userId = input.userId || null

  if (userId) {
    const taken = await db.execute(
      sql`SELECT id FROM frc_team_members WHERE user_id = ${userId} AND id <> ${input.id ?? 0}`,
    )
    if (taken.rows[0]) return { ok: false, error: 'Esa cuenta ya está vinculada a otro integrante' }
  }

  let id: number
  if (input.id) {
    await db.execute(sql`
      UPDATE frc_team_members SET full_name = ${fullName}, email = ${email}, team_role = ${input.teamRole || 'Integrante'},
        primary_subsystem_id = ${primary}, availability = ${input.availability?.trim() ?? ''}, participation_status = ${status},
        skills = ${skillsLiteral}::text[], user_id = ${userId}, updated_at = now()
      WHERE id = ${input.id} AND project_id = ${PROJECT_ID}`)
    id = input.id
    await audit(ctx, { action: 'Editó', entityType: 'member', entityId: id, summary: `Actualizó a ${fullName}` })
  } else {
    const r = await db.execute(sql`
      INSERT INTO frc_team_members (project_id, user_id, full_name, email, team_role, primary_subsystem_id, availability, participation_status, skills)
      VALUES (${PROJECT_ID}, ${userId}, ${fullName}, ${email}, ${input.teamRole || 'Integrante'}, ${primary}, ${input.availability?.trim() ?? ''}, ${status}, ${skillsLiteral}::text[])
      RETURNING id`)
    id = Number(r.rows[0].id)
    await audit(ctx, { action: 'Agregó', entityType: 'member', entityId: id, summary: `Sumó a ${fullName} al equipo` })
  }

  await db.execute(sql`DELETE FROM frc_member_subsystems WHERE member_id = ${id}`)
  const subs = new Map<number, boolean>()
  for (const s of input.subsystems ?? []) if (Number.isInteger(s.id) && s.id > 0) subs.set(s.id, !!s.isLead)
  if (primary && !subs.has(primary)) subs.set(primary, false)
  for (const [subsystemId, isLead] of subs) {
    await db.execute(sql`INSERT INTO frc_member_subsystems (member_id, subsystem_id, is_lead) VALUES (${id}, ${subsystemId}, ${isLead})`)
  }

  revalidatePath('/', 'layout')
  return { ok: true, id }
}

export async function deleteMember(id: number): Promise<Result> {
  const ctx = await requireActionContext()
  if (!can.deleteCritical(ctx)) return { ok: false, error: 'No tenés permiso' }
  const r = await db.execute(sql`SELECT full_name FROM frc_team_members WHERE id = ${id} AND project_id = ${PROJECT_ID}`)
  if (!r.rows[0]) return { ok: false, error: 'Integrante no encontrado' }
  await db.execute(sql`DELETE FROM frc_team_members WHERE id = ${id}`)
  await audit(ctx, { action: 'Eliminó', entityType: 'member', entityId: id, summary: `Quitó a ${r.rows[0].full_name} del equipo` })
  revalidatePath('/', 'layout')
  return { ok: true }
}

export async function setAccountRole(userId: string, role: string): Promise<Result> {
  const ctx = await requireActionContext()
  if (!can.configure(ctx)) return { ok: false, error: 'Solo un administrador puede cambiar roles' }
  if (userId === ctx.userId) return { ok: false, error: 'No podés cambiar tu propio rol' }
  const next = normalizeRole(role)
  const r = await db.execute(sql`UPDATE "user" SET role = ${next} WHERE id = ${userId} RETURNING name`)
  if (!r.rows[0]) return { ok: false, error: 'Cuenta no encontrada' }
  await audit(ctx, { action: 'Cambió rol', entityType: 'user', summary: `${r.rows[0].name} → ${next}` })
  revalidatePath('/configuracion')
  return { ok: true }
}

export type PhaseInput = {
  id?: number
  name: string
  description: string
  plannedStart: string | null
  plannedEnd: string | null
  actualStart: string | null
  actualEnd: string | null
}

export async function savePhase(input: PhaseInput): Promise<Result> {
  const ctx = await requireActionContext()
  if (!can.managePlanning(ctx)) return { ok: false, error: 'Solo profesores y administradores editan la planificación' }
  const name = input.name?.trim()
  if (!name) return { ok: false, error: 'El nombre es obligatorio' }
  const dates = [input.plannedStart, input.plannedEnd, input.actualStart, input.actualEnd]
  if (!dates.every(isDate)) return { ok: false, error: 'Fecha inválida' }
  if (input.plannedStart && input.plannedEnd && input.plannedStart > input.plannedEnd)
    return { ok: false, error: 'El inicio planificado es posterior al fin' }

  if (input.id) {
    const prev = await db.execute(sql`SELECT planned_start::text AS ps, planned_end::text AS pe FROM frc_phases WHERE id = ${input.id}`)
    await db.execute(sql`
      UPDATE frc_phases SET name = ${name}, description = ${input.description?.trim() ?? ''}, planned_start = ${input.plannedStart},
        planned_end = ${input.plannedEnd}, actual_start = ${input.actualStart}, actual_end = ${input.actualEnd}, updated_at = now()
      WHERE id = ${input.id} AND project_id = ${PROJECT_ID}`)
    const p = prev.rows[0]
    const moved = p && (p.ps !== input.plannedStart || p.pe !== input.plannedEnd)
    await audit(ctx, {
      action: moved ? 'Replanificó' : 'Editó',
      entityType: 'phase',
      entityId: input.id,
      summary: moved ? `${name}: ${p.ps ?? '—'}–${p.pe ?? '—'} → ${input.plannedStart ?? '—'}–${input.plannedEnd ?? '—'}` : `Actualizó la fase ${name}`,
      changes: moved ? { before: { start: p.ps, end: p.pe }, after: { start: input.plannedStart, end: input.plannedEnd } } : undefined,
    })
    revalidatePath('/', 'layout')
    return { ok: true, id: input.id }
  }
  const r = await db.execute(sql`
    INSERT INTO frc_phases (project_id, name, description, sort, planned_start, planned_end, actual_start, actual_end)
    VALUES (${PROJECT_ID}, ${name}, ${input.description?.trim() ?? ''},
      (SELECT COALESCE(MAX(sort), 0) + 1 FROM frc_phases WHERE project_id = ${PROJECT_ID}),
      ${input.plannedStart}, ${input.plannedEnd}, ${input.actualStart}, ${input.actualEnd})
    RETURNING id`)
  const id = Number(r.rows[0].id)
  await audit(ctx, { action: 'Creó', entityType: 'phase', entityId: id, summary: `Creó la fase ${name}` })
  revalidatePath('/', 'layout')
  return { ok: true, id }
}

export type MilestoneInput = {
  id?: number
  phaseId: number
  title: string
  description: string
  dueDate: string | null
  acceptanceCriteria: string
}

export async function saveMilestone(input: MilestoneInput): Promise<Result> {
  const ctx = await requireActionContext()
  if (!can.managePlanning(ctx)) return { ok: false, error: 'Solo profesores y administradores editan hitos' }
  const title = input.title?.trim()
  if (!title) return { ok: false, error: 'El título es obligatorio' }
  if (!isDate(input.dueDate)) return { ok: false, error: 'Fecha inválida' }
  if (input.id) {
    await db.execute(sql`
      UPDATE frc_milestones SET phase_id = ${input.phaseId}, title = ${title}, description = ${input.description?.trim() ?? ''},
        due_date = ${input.dueDate}, acceptance_criteria = ${input.acceptanceCriteria?.trim() ?? ''}, updated_at = now()
      WHERE id = ${input.id}`)
    await audit(ctx, { action: 'Editó', entityType: 'milestone', entityId: input.id, summary: `Actualizó el hito ${title}` })
    revalidatePath('/', 'layout')
    return { ok: true, id: input.id }
  }
  const r = await db.execute(sql`
    INSERT INTO frc_milestones (phase_id, title, description, due_date, acceptance_criteria)
    VALUES (${input.phaseId}, ${title}, ${input.description?.trim() ?? ''}, ${input.dueDate}, ${input.acceptanceCriteria?.trim() ?? ''})
    RETURNING id`)
  const id = Number(r.rows[0].id)
  await audit(ctx, { action: 'Creó', entityType: 'milestone', entityId: id, summary: `Creó el hito ${title}` })
  revalidatePath('/', 'layout')
  return { ok: true, id }
}

export async function setMilestoneStatus(id: number, status: 'pendiente' | 'en_riesgo' | 'alcanzado'): Promise<Result> {
  const ctx = await requireActionContext()
  if (!['pendiente', 'en_riesgo', 'alcanzado'].includes(status)) return { ok: false, error: 'Estado inválido' }
  if (!can.verifyMilestone(ctx)) return { ok: false, error: 'Solo profesores y administradores verifican hitos' }
  const r = await db.execute(sql`
    UPDATE frc_milestones SET status = ${status},
      achieved_at = CASE WHEN ${status} = 'alcanzado' THEN now() ELSE NULL END,
      verified_by = CASE WHEN ${status} = 'alcanzado' THEN ${ctx.name} ELSE NULL END, updated_at = now()
    WHERE id = ${id} RETURNING title`)
  if (!r.rows[0]) return { ok: false, error: 'Hito no encontrado' }
  await audit(ctx, {
    action: status === 'alcanzado' ? 'Verificó' : 'Cambió estado',
    entityType: 'milestone',
    entityId: id,
    summary: `Hito ${r.rows[0].title}: ${status.replace('_', ' ')}`,
  })
  revalidatePath('/', 'layout')
  return { ok: true }
}

export async function deleteDemoData(): Promise<Result> {
  const ctx = await requireActionContext()
  if (!can.configure(ctx)) return { ok: false, error: 'Solo un administrador puede borrar datos de demostración' }
  await db.execute(sql`DELETE FROM frc_tasks WHERE is_demo = true AND project_id = ${PROJECT_ID}`)
  await db.execute(sql`DELETE FROM frc_training_modules WHERE is_demo = true AND project_id = ${PROJECT_ID}`)
  await db.execute(sql`DELETE FROM frc_milestones WHERE is_demo = true`)
  await db.execute(sql`DELETE FROM frc_phases WHERE is_demo = true AND project_id = ${PROJECT_ID}`)
  await audit(ctx, { action: 'Eliminó', entityType: 'project', summary: 'Borró los datos de demostración' })
  revalidatePath('/', 'layout')
  return { ok: true }
}
