'use server'

import { revalidatePath } from 'next/cache'
import { sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import { requireActionContext, PROJECT_ID, type FrcContext } from '@/lib/frc/session'
import { can } from '@/lib/frc/permissions'
import { audit } from '@/lib/frc/audit'
import { TASK_PRIORITIES, TASK_STATUSES } from '@/lib/frc/roles'

export type TaskInput = {
  id?: number
  title: string
  description: string
  ownerMemberId: number | null
  collaboratorIds: number[]
  subsystemId: number | null
  phaseId: number | null
  milestoneId: number | null
  parentTaskId: number | null
  dependsOnIds: number[]
  priority: string
  status: string
  blockedReason: string
  startDate: string | null
  dueDate: string | null
  deliverable: string
  acceptanceCriteria: string
}

type Result = { ok: true; id?: number } | { ok: false; error: string }

const isDate = (v: string | null) => v === null || /^\d{4}-\d{2}-\d{2}$/.test(v)
const intOrNull = (v: unknown) => (typeof v === 'number' && Number.isInteger(v) && v > 0 ? v : null)
const intList = (v: unknown) => (Array.isArray(v) ? [...new Set(v.filter((x) => Number.isInteger(x) && x > 0))] : []) as number[]

async function loadScope(taskId: number) {
  const r = await db.execute(sql`
    SELECT t.id, t.title, t.status, t.owner_member_id, t.subsystem_id, t.acceptance_criteria,
      COALESCE((SELECT array_agg(member_id) FROM frc_task_collaborators WHERE task_id = t.id), '{}') AS collabs
    FROM frc_tasks t WHERE t.id = ${taskId} AND t.project_id = ${PROJECT_ID}`)
  const t = r.rows[0]
  if (!t) return null
  return {
    id: Number(t.id),
    title: String(t.title),
    status: String(t.status),
    acceptanceCriteria: String(t.acceptance_criteria),
    ownerMemberId: t.owner_member_id === null ? null : Number(t.owner_member_id),
    subsystemId: t.subsystem_id === null ? null : Number(t.subsystem_id),
    collaboratorIds: ((t.collabs as number[]) ?? []).map(Number),
  }
}

async function createsCycle(taskId: number, dependsOnIds: number[]) {
  if (dependsOnIds.includes(taskId)) return true
  if (dependsOnIds.length === 0) return false
  // Walk dependencies from the proposed prerequisites; reaching taskId means a cycle.
  const r = await db.execute(sql`
    WITH RECURSIVE chain(id) AS (
      SELECT unnest(${`{${dependsOnIds.join(',')}}`}::int[])
      UNION
      SELECT d.depends_on_id FROM frc_task_dependencies d JOIN chain c ON d.task_id = c.id
    ) SELECT 1 FROM chain WHERE id = ${taskId} LIMIT 1`)
  return r.rows.length > 0
}

// Students cannot close tasks themselves: completion goes through review.
function resolveStatus(ctx: FrcContext, scope: { subsystemId: number | null; ownerMemberId: number | null; collaboratorIds: number[] }, requested: string) {
  if (requested === 'Completada' && !can.verifyTask(ctx, scope)) return 'En revisión'
  return requested
}

export async function saveTask(input: TaskInput): Promise<Result> {
  const ctx = await requireActionContext()
  const title = input.title?.trim()
  if (!title) return { ok: false, error: 'El título es obligatorio' }
  if (!TASK_PRIORITIES.includes(input.priority as never)) return { ok: false, error: 'Prioridad inválida' }
  if (!TASK_STATUSES.includes(input.status as never)) return { ok: false, error: 'Estado inválido' }
  if (!isDate(input.startDate) || !isDate(input.dueDate)) return { ok: false, error: 'Fecha inválida' }
  if (input.startDate && input.dueDate && input.startDate > input.dueDate)
    return { ok: false, error: 'La fecha de inicio no puede ser posterior al vencimiento' }
  if (input.status === 'Bloqueada' && !input.blockedReason?.trim())
    return { ok: false, error: 'Indicá el motivo del bloqueo' }

  const subsystemId = intOrNull(input.subsystemId)
  const collaboratorIds = intList(input.collaboratorIds)
  const dependsOnIds = intList(input.dependsOnIds)
  const fields = {
    description: input.description?.trim() ?? '',
    ownerMemberId: intOrNull(input.ownerMemberId),
    phaseId: intOrNull(input.phaseId),
    milestoneId: intOrNull(input.milestoneId),
    parentTaskId: intOrNull(input.parentTaskId),
    blockedReason: input.status === 'Bloqueada' ? input.blockedReason.trim() : null,
    deliverable: input.deliverable?.trim() ?? '',
    acceptanceCriteria: input.acceptanceCriteria?.trim() ?? '',
  }

  let taskId: number
  if (input.id) {
    const scope = await loadScope(input.id)
    if (!scope) return { ok: false, error: 'Tarea no encontrada' }
    if (!can.editTask(ctx, scope)) return { ok: false, error: 'No tenés permiso para editar esta tarea' }
    if (fields.parentTaskId === input.id) return { ok: false, error: 'Una tarea no puede ser subtarea de sí misma' }
    if (await createsCycle(input.id, dependsOnIds)) return { ok: false, error: 'Esa dependencia genera un ciclo' }
    const status = resolveStatus(ctx, { ...scope, subsystemId }, input.status)
    await db.execute(sql`
      UPDATE frc_tasks SET title = ${title}, description = ${fields.description}, owner_member_id = ${fields.ownerMemberId},
        subsystem_id = ${subsystemId}, phase_id = ${fields.phaseId}, milestone_id = ${fields.milestoneId},
        parent_task_id = ${fields.parentTaskId}, priority = ${input.priority}, status = ${status},
        blocked_reason = ${fields.blockedReason}, start_date = ${input.startDate}, due_date = ${input.dueDate},
        deliverable = ${fields.deliverable}, acceptance_criteria = ${fields.acceptanceCriteria},
        completed_at = CASE WHEN ${status} = 'Completada' THEN COALESCE(completed_at, now()) ELSE NULL END,
        updated_at = now()
      WHERE id = ${input.id}`)
    taskId = input.id
    await audit(ctx, {
      action: 'Editó',
      entityType: 'task',
      entityId: taskId,
      summary: status !== scope.status ? `${title}: ${scope.status} → ${status}` : `Actualizó «${title}»`,
    })
  } else {
    if (!can.createTask(ctx, subsystemId)) return { ok: false, error: 'No tenés permiso para crear tareas en ese subsistema' }
    const status = resolveStatus(ctx, { subsystemId, ownerMemberId: fields.ownerMemberId, collaboratorIds }, input.status)
    const r = await db.execute(sql`
      INSERT INTO frc_tasks (project_id, title, description, owner_member_id, subsystem_id, phase_id, milestone_id, parent_task_id,
        priority, status, blocked_reason, start_date, due_date, deliverable, acceptance_criteria, created_by, completed_at)
      VALUES (${PROJECT_ID}, ${title}, ${fields.description}, ${fields.ownerMemberId}, ${subsystemId}, ${fields.phaseId},
        ${fields.milestoneId}, ${fields.parentTaskId}, ${input.priority}, ${status}, ${fields.blockedReason}, ${input.startDate},
        ${input.dueDate}, ${fields.deliverable}, ${fields.acceptanceCriteria}, ${ctx.userId},
        ${status === 'Completada' ? new Date().toISOString() : null})
      RETURNING id`)
    taskId = Number(r.rows[0].id)
    if (await createsCycle(taskId, dependsOnIds)) return { ok: false, error: 'Esa dependencia genera un ciclo' }
    await audit(ctx, { action: 'Creó', entityType: 'task', entityId: taskId, summary: `Creó «${title}»` })
  }

  await db.execute(sql`DELETE FROM frc_task_collaborators WHERE task_id = ${taskId}`)
  for (const memberId of collaboratorIds.filter((m) => m !== fields.ownerMemberId)) {
    await db.execute(sql`INSERT INTO frc_task_collaborators (task_id, member_id) VALUES (${taskId}, ${memberId}) ON CONFLICT DO NOTHING`)
  }
  await db.execute(sql`DELETE FROM frc_task_dependencies WHERE task_id = ${taskId}`)
  for (const dep of dependsOnIds) {
    await db.execute(sql`INSERT INTO frc_task_dependencies (task_id, depends_on_id) VALUES (${taskId}, ${dep}) ON CONFLICT DO NOTHING`)
  }

  revalidatePath('/', 'layout')
  return { ok: true, id: taskId }
}

export async function changeTaskStatus(taskId: number, status: string, blockedReason?: string): Promise<Result> {
  const ctx = await requireActionContext()
  if (!TASK_STATUSES.includes(status as never)) return { ok: false, error: 'Estado inválido' }
  const scope = await loadScope(taskId)
  if (!scope) return { ok: false, error: 'Tarea no encontrada' }
  if (!can.workOnTask(ctx, scope)) return { ok: false, error: 'No participás de esta tarea' }
  if (status === 'Bloqueada' && !blockedReason?.trim()) return { ok: false, error: 'Indicá el motivo del bloqueo' }
  const next = resolveStatus(ctx, scope, status)
  await db.execute(sql`
    UPDATE frc_tasks SET status = ${next}, blocked_reason = ${next === 'Bloqueada' ? blockedReason!.trim() : null},
      completed_at = CASE WHEN ${next} = 'Completada' THEN COALESCE(completed_at, now()) ELSE NULL END,
      verified_at = CASE WHEN ${next} = 'Completada' THEN verified_at ELSE NULL END,
      updated_at = now()
    WHERE id = ${taskId}`)
  await audit(ctx, { action: 'Cambió estado', entityType: 'task', entityId: taskId, summary: `${scope.title}: ${scope.status} → ${next}` })
  revalidatePath('/', 'layout')
  return next === status ? { ok: true } : { ok: false, error: 'Quedó en revisión: un profesor o referente debe verificarla' }
}

export async function verifyTask(taskId: number): Promise<Result> {
  const ctx = await requireActionContext()
  const scope = await loadScope(taskId)
  if (!scope) return { ok: false, error: 'Tarea no encontrada' }
  if (!can.verifyTask(ctx, scope)) return { ok: false, error: 'Solo un profesor o referente del área puede verificar' }
  await db.execute(sql`
    UPDATE frc_tasks SET status = 'Completada', verified_by = ${ctx.name}, verified_at = now(),
      completed_at = COALESCE(completed_at, now()), updated_at = now() WHERE id = ${taskId}`)
  await audit(ctx, { action: 'Verificó', entityType: 'task', entityId: taskId, summary: `Verificó «${scope.title}»` })
  revalidatePath('/', 'layout')
  return { ok: true }
}

export async function deleteTask(taskId: number): Promise<Result> {
  const ctx = await requireActionContext()
  if (!can.deleteCritical(ctx)) return { ok: false, error: 'Solo un profesor o administrador puede eliminar tareas' }
  const scope = await loadScope(taskId)
  if (!scope) return { ok: false, error: 'Tarea no encontrada' }
  await db.execute(sql`DELETE FROM frc_tasks WHERE id = ${taskId}`)
  await audit(ctx, { action: 'Eliminó', entityType: 'task', entityId: taskId, summary: `Eliminó «${scope.title}»` })
  revalidatePath('/', 'layout')
  return { ok: true }
}

export async function addTaskComment(taskId: number, body: string): Promise<Result> {
  const ctx = await requireActionContext()
  const text = body?.trim()
  if (!text) return { ok: false, error: 'El comentario está vacío' }
  if (text.length > 4000) return { ok: false, error: 'El comentario es demasiado largo' }
  const scope = await loadScope(taskId)
  if (!scope) return { ok: false, error: 'Tarea no encontrada' }
  if (!can.workOnTask(ctx, scope)) return { ok: false, error: 'No participás de esta tarea' }
  await db.execute(
    sql`INSERT INTO frc_task_comments (task_id, author_user_id, author_name, body) VALUES (${taskId}, ${ctx.userId}, ${ctx.name}, ${text})`,
  )
  revalidatePath('/tareas')
  return { ok: true }
}

export async function loadTaskActivity(taskId: number) {
  await requireActionContext()
  const { getTaskActivity } = await import('@/lib/frc/data')
  return getTaskActivity(taskId)
}
