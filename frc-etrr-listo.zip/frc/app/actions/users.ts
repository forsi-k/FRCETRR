'use server'

import { headers } from 'next/headers'
import { sql } from 'drizzle-orm'
import { hashPassword } from 'better-auth/crypto'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { logActivity } from '@/lib/activity-log'

type AppRole = 'admin' | 'coordinacion' | 'member'
const normalizeRole = (role: unknown): AppRole => (role === 'admin' || role === 'coordinacion' ? role : 'member')

async function requireAdmin() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error('No autorizado')
  const role = (session.user as { role?: string }).role === 'admin' ? 'admin' : 'member'
  if (role !== 'admin') throw new Error('Solo un administrador puede gestionar cuentas')
  return session.user
}

export async function createAccount(input: { name: string; email: string; password: string; role: AppRole; area?: string; teamRole?: string }) {
  const admin = await requireAdmin()
  const name = input.name.trim()
  const email = input.email.trim().toLowerCase()
  const area = (input.area ?? '').trim()
  const teamRole = input.teamRole === 'lider' ? 'lider' : 'colaborador'
  if (!name || !email) throw new Error('Nombre y email son obligatorios')
  if (!input.password) throw new Error('La contraseña es obligatoria')

  const existing = await db.execute(sql`SELECT id FROM "user" WHERE email = ${email}`)
  if (existing.rows[0]) throw new Error('Ya existe una cuenta con ese email')

  const result = await auth.api.signUpEmail({ body: { email, password: input.password, name } })
  const userId = result.user?.id
  if (!userId) throw new Error('No se pudo crear la cuenta')

  const role = normalizeRole(input.role)
  await db.execute(sql`UPDATE "user" SET role = ${role}, area = ${area}, team_role = ${teamRole} WHERE id = ${userId}`)

  await logActivity({ name: admin.name, role: 'admin' }, 'Creó', 'la cuenta', `${name} (${email})`)

  return { id: userId, name, email, role, area, teamRole }
}

export async function updateAccount(input: { id: string; name: string; email: string; role: AppRole; area?: string; teamRole?: string; password?: string }) {
  const admin = await requireAdmin()
  const name = input.name.trim()
  const email = input.email.trim().toLowerCase()
  const area = (input.area ?? '').trim()
  const teamRole = input.teamRole === 'lider' ? 'lider' : 'colaborador'
  if (!name || !email) throw new Error('Nombre y email son obligatorios')

  const existing = await db.execute(sql`SELECT id FROM "user" WHERE id = ${input.id}`)
  if (!existing.rows[0]) throw new Error('Cuenta no encontrada')

  const emailTaken = await db.execute(sql`SELECT id FROM "user" WHERE email = ${email} AND id != ${input.id}`)
  if (emailTaken.rows[0]) throw new Error('Ya existe otra cuenta con ese email')

  const role = normalizeRole(input.role)
  await db.execute(
    sql`UPDATE "user" SET name = ${name}, email = ${email}, role = ${role}, area = ${area}, team_role = ${teamRole} WHERE id = ${input.id}`,
  )

  if (input.password) {
    const hashed = await hashPassword(input.password)
    await db.execute(
      sql`UPDATE "account" SET password = ${hashed} WHERE "userId" = ${input.id} AND "providerId" = 'credential'`,
    )
  }

  await logActivity(
    { name: admin.name, role: 'admin' },
    'Actualizó',
    'la cuenta',
    `${name} (${email})`,
    input.password ? 'Cambió nombre, email y contraseña' : 'Cambió nombre y email',
  )

  return { id: input.id, name, email, role, area, teamRole }
}

export async function deleteAccount(id: string) {
  const admin = await requireAdmin()
  if (admin.id === id) throw new Error('No podés eliminar tu propia cuenta')
  const existing = await db.execute(sql`SELECT name, email FROM "user" WHERE id = ${id}`)
  await db.execute(sql`DELETE FROM "user" WHERE id = ${id}`)
  const target = existing.rows[0]
  await logActivity({ name: admin.name, role: 'admin' }, 'Eliminó', 'la cuenta', target ? `${target.name} (${target.email})` : id)
}
