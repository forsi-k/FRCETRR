import Link from 'next/link'
import { redirect } from 'next/navigation'
import { PageHeader } from '@/components/frc/shared'
import { formatDate } from '@/components/frc/format'
import { AccountsTable, DemoDataButton } from '@/components/frc/settings/settings-client'
import { requirePageContext } from '@/lib/frc/session'
import { getAccounts, getProject } from '@/lib/frc/data'
import { can } from '@/lib/frc/permissions'
import { PROGRESS_RULES } from '@/lib/frc/progress'

export const metadata = { title: 'Configuración' }

export default async function ConfiguracionPage() {
  const ctx = await requirePageContext()
  if (!can.configure(ctx)) redirect('/')
  const [project, accounts] = await Promise.all([getProject(), getAccounts()])

  const facts: [string, string][] = [
    ['Proyecto', project.name],
    ['Institución', project.institution],
    ['Competencia', `${project.competition} ${project.season}`],
    ['Kickoff', formatDate(project.kickoffDate, true)],
    ['Número de equipo', project.teamNumber ?? 'Pendiente'],
    ['Evento', project.eventName ?? 'Pendiente'],
    ['Umbral de sobrecarga', `${project.overloadOpen} abiertas o ${project.overloadCritical} críticas`],
  ]

  return (
    <>
      <PageHeader title="Configuración" description="Datos del proyecto, cuentas y reglas del sistema." />
      <div className="flex max-w-4xl flex-col gap-10 px-4 py-6 md:px-8">
        <Section title="Proyecto">
          <dl className="grid grid-cols-1 gap-x-8 gap-y-2 text-sm sm:grid-cols-[12rem_1fr]">
            {facts.map(([k, v]) => (
              <div key={k} className="contents">
                <dt className="text-muted-foreground">{k}</dt>
                <dd>{v}</dd>
              </div>
            ))}
          </dl>
          {project.objective && <p className="text-sm leading-relaxed text-muted-foreground text-pretty">{project.objective}</p>}
        </Section>

        <Section title="Cuentas y roles" description="Los roles definen qué puede ver y editar cada persona.">
          <AccountsTable accounts={accounts} selfId={ctx.userId} />
        </Section>

        <Section title="Cálculo de avance">
          <ul className="flex flex-col gap-1.5 text-sm leading-relaxed">
            {PROGRESS_RULES.map((r) => (
              <li key={r} className="flex gap-2">
                <span className="text-primary" aria-hidden>
                  ·
                </span>
                {r}
              </li>
            ))}
          </ul>
        </Section>

        <Section title="Datos de ejemplo" description="Los registros marcados como «Ejemplo» pueden borrarse de una vez.">
          <DemoDataButton />
        </Section>

        <Section title="Proyecto anterior">
          <p className="text-sm text-muted-foreground">
            El panel anterior de FRC ETRR sigue disponible en{' '}
            <Link href="/ecodesafio" className="text-foreground underline underline-offset-4">
              /ecodesafio
            </Link>
            .
          </p>
        </Section>
      </div>
    </>
  )
}

function Section({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-4">
      <div className="flex flex-col gap-1 border-b pb-2">
        <h2 className="text-sm font-semibold">{title}</h2>
        {description && <p className="text-xs text-muted-foreground">{description}</p>}
      </div>
      {children}
    </section>
  )
}
