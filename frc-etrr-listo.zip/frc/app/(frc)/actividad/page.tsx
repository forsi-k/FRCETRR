import { Activity } from 'lucide-react'
import { EmptyState, PageHeader } from '@/components/frc/shared'
import { formatDateTime } from '@/components/frc/format'
import { requirePageContext } from '@/lib/frc/session'
import { getRecentAudit } from '@/lib/frc/data'

export const metadata = { title: 'Actividad' }

const ENTITY: Record<string, string> = { task: 'Tarea', phase: 'Fase', milestone: 'Hito', member: 'Equipo', user: 'Cuenta', project: 'Proyecto' }

export default async function ActividadPage() {
  await requirePageContext()
  const entries = await getRecentAudit(200)
  return (
    <>
      <PageHeader title="Actividad" description="Registro de cambios relevantes: quién hizo qué y cuándo." />
      <div className="flex-1 px-4 py-5 md:px-8">
        {entries.length === 0 ? (
          <EmptyState icon={Activity} title="Sin actividad todavía" description="Los cambios en tareas, fases, hitos y equipo aparecen acá." />
        ) : (
          <ol className="divide-y rounded-lg border">
            {entries.map((e) => (
              <li key={e.id} className="grid grid-cols-1 gap-1 px-4 py-2.5 text-sm md:grid-cols-[9rem_6rem_1fr] md:gap-4">
                <span className="font-mono text-xs text-muted-foreground">{formatDateTime(e.createdAt)}</span>
                <span className="text-xs text-muted-foreground">{ENTITY[e.entityType] ?? e.entityType}</span>
                <span className="text-pretty">
                  <span className="font-medium">{e.actorName}</span> <span className="text-muted-foreground">· {e.action} ·</span> {e.summary}
                </span>
              </li>
            ))}
          </ol>
        )}
      </div>
    </>
  )
}
