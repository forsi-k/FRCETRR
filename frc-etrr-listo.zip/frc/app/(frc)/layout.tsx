import { SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar'
import { Separator } from '@/components/ui/separator'
import { AppSidebar } from '@/components/frc/app-sidebar'
import { requirePageContext } from '@/lib/frc/session'
import { getProject } from '@/lib/frc/data'
import { ROLE_LABELS } from '@/lib/frc/roles'

export default async function FrcLayout({ children }: { children: React.ReactNode }) {
  const [ctx, project] = await Promise.all([requirePageContext(), getProject()])
  return (
    <SidebarProvider>
      <AppSidebar
        projectName={project.name}
        season={project.season}
        user={{ name: ctx.name, email: ctx.email, roleLabel: ROLE_LABELS[ctx.role] }}
        isAdmin={ctx.role === 'admin'}
      />
      <SidebarInset>
        <header className="sticky top-0 z-10 flex h-12 items-center gap-2 border-b bg-background/90 px-3 backdrop-blur md:hidden">
          <SidebarTrigger />
          <Separator orientation="vertical" className="h-4" />
          <span className="font-mono text-sm font-medium">{project.name}</span>
        </header>
        <div className="flex flex-1 flex-col">{children}</div>
      </SidebarInset>
    </SidebarProvider>
  )
}
