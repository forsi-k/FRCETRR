import { PlanningView } from '@/components/frc/planning/planning-view'
import { requirePageContext } from '@/lib/frc/session'
import { getPhases, getTasks } from '@/lib/frc/data'
import { can } from '@/lib/frc/permissions'

export const metadata = { title: 'Planificación' }

export default async function PlanificacionPage({ searchParams }: { searchParams: Promise<{ vista?: string }> }) {
  const [ctx, { vista }, tasks] = await Promise.all([requirePageContext(), searchParams, getTasks()])
  const phases = await getPhases(tasks)
  return (
    <PlanningView
      phases={phases}
      tasks={tasks}
      initialView={vista ?? 'cronograma'}
      canManage={can.managePlanning(ctx)}
      canVerify={can.verifyMilestone(ctx)}
    />
  )
}
