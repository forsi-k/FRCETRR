import { GraduationCap } from 'lucide-react'
import { EmptyState, PageHeader } from '@/components/frc/shared'
import { requirePageContext } from '@/lib/frc/session'

export const metadata = { title: 'Capacitación' }

export default async function CapacitacionPage() {
  await requirePageContext()
  return (
    <>
      <PageHeader title="Capacitación" description="Módulos de formación por área, con evidencias y validación." />
      <div className="flex-1 px-4 py-5 md:px-8">
        <EmptyState
          icon={GraduationCap}
          title="Módulo en preparación"
          description="La base de datos ya está lista para módulos, asignaciones y evidencias. La interfaz llega en la próxima etapa."
        />
      </div>
    </>
  )
}
