import { TasksView } from '@/components/frc/tasks/tasks-view'
import { requirePageContext } from '@/lib/frc/session'
import { getMembers, getPhases, getSubsystems, getTasks } from '@/lib/frc/data'

export const metadata = { title: 'Tareas' }

export default async function TareasPage({ searchParams }: { searchParams: Promise<{ vista?: string }> }) {
  const [ctx, { vista }, tasks, members, subsystems] = await Promise.all([
    requirePageContext(),
    searchParams,
    getTasks(),
    getMembers(),
    getSubsystems(),
  ])
  const phases = await getPhases(tasks)
  return <TasksView refs={{ tasks, members, subsystems, phases }} ctx={ctx} initialView={vista ?? 'lista'} />
}
