import { TeamView } from '@/components/frc/team/team-view'
import { requirePageContext } from '@/lib/frc/session'
import { getAccounts, getMembers, getSubsystems, getTasks, getProject } from '@/lib/frc/data'
import { can } from '@/lib/frc/permissions'

export const metadata = { title: 'Equipo' }

export default async function EquipoPage() {
  const ctx = await requirePageContext()
  const manage = can.manageTeam(ctx)
  const [members, subsystems, tasks, project, accounts] = await Promise.all([
    getMembers(),
    getSubsystems(),
    getTasks(),
    getProject(),
    manage ? getAccounts() : Promise.resolve([]),
  ])
  const load = Object.fromEntries(
    members.map((m) => {
      const open = tasks.filter((t) => t.ownerMemberId === m.id && t.status !== 'Completada' && t.status !== 'Cancelada')
      return [m.id, { open: open.length, critical: open.filter((t) => t.priority === 'Crítica').length }]
    }),
  )
  return (
    <TeamView
      members={members}
      subsystems={subsystems}
      accounts={accounts}
      load={load}
      limits={{ open: project.overloadOpen, critical: project.overloadCritical }}
      canManage={manage}
      canDelete={can.deleteCritical(ctx)}
    />
  )
}
