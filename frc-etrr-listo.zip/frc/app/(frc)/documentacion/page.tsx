import { BookOpen } from 'lucide-react'
import { EmptyState, PageHeader } from '@/components/frc/shared'
import { requirePageContext } from '@/lib/frc/session'

export const metadata = { title: 'Documentación' }

export default async function DocumentacionPage() {
  await requirePageContext()
  return (
    <>
      <PageHeader title="Documentación" description="Bitácoras, decisiones de diseño, manuales y versiones de documentos." />
      <div className="flex-1 px-4 py-5 md:px-8">
        <EmptyState
          icon={BookOpen}
          title="Módulo en preparación"
          description="La base de datos ya está lista para documentos y versiones. La interfaz llega en la próxima etapa."
        />
      </div>
    </>
  )
}
