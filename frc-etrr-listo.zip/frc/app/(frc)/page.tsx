import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { PageHeader, ProgressBar, StatusBadge, PriorityTag, DemoBadge } from '@/components/frc/shared'
import { formatDate, formatDateTime, daysBetween } from '@/components/frc/format'
import { requirePageContext } from '@/lib/frc/session'
import { getMembers, getPhases, getProject, getRecentAudit, getSubsystems, getTasks } from '@/lib/frc/data'
import { isOverdue, todayISO, weightedProgress } from '@/lib/frc/progress'

export const metadata = { title: 'Resumen' }

const OPEN = (s: string) => s !== 'Completada' && s !== 'Cancelada'

export default async function ResumenPage() {
  const [ctx, project, tasks, members, subsystems, audit] = await Promise.all([
    requirePageContext(),
    getProject(),
    getTasks(),
    getMembers(),
    getSubsystems(),
    getRecentAudit(8),
  ])
  const phases = await getPhases(tasks)
  const today = todayISO()

  const global = weightedProgress(tasks)
  const open = tasks.filter((t) => OPEN(t.status))
  const overdue = open.filter((t) => isOverdue(t.dueDate, t.status))
  const blocked = open.filter((t) => t.status === 'Bloqueada')
  const review = open.filter((t) => t.status === 'En revisión')
  const kickoffIn = project.kickoffDate ? daysBetween(today, project.kickoffDate) : null

  const milestones = phases
    .flatMap((p) => p.milestones.map((m) => ({ ...m, phaseName: p.name })))
    .filter((m) => m.status !== 'alcanzado')
    .sort((a, b) => (a.dueDate ?? '9999').localeCompare(b.dueDate ?? '9999'))
    .slice(0, 5)

  const priority = open
    .filter((t) => t.priority === 'Crítica' || t.priority === 'Alta' || isOverdue(t.dueDate, t.status) || t.status === 'Bloqueada')
    .sort((a, b) => (a.dueDate ?? '9999').localeCompare(b.dueDate ?? '9999'))
    .slice(0, 6)

  const groups = subsystems.filter((s) => s.parentId === null)
  const groupProgress = groups.map((g) => {
    const ids = [g.id, ...subsystems.filter((s) => s.parentId === g.id).map((s) => s.id)]
    const list = tasks.filter((t) => t.subsystemId !== null && ids.includes(t.subsystemId))
    return { ...g, progress: weightedProgress(list), count: list.length }
  })

  const loads = members
    .filter((m) => m.status === 'activo')
    .map((m) => {
      const mine = open.filter((t) => t.ownerMemberId === m.id)
      return { m, open: mine.length, critical: mine.filter((t) => t.priority === 'Crítica').length }
    })
    .filter((l) => l.open > project.overloadOpen || l.critical > project.overloadCritical)

  return (
    <>
      <PageHeader
        title={project.name}
        description={`${project.institution} · ${project.competition} ${project.season}${project.teamNumber ? ` · Equipo ${project.teamNumber}` : ''}`}
      />
      <div className="flex flex-col gap-8 px-4 py-6 md:px-8">
        <section aria-label="Indicadores" className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border bg-border lg:grid-cols-5">
          <Kpi label="Avance global" value={global === null ? '—' : `${global}%`} hint="ponderado por prioridad" />
          <Kpi label="Tareas abiertas" value={open.length} hint={`${tasks.length} en total`} />
          <Kpi label="Vencidas" value={overdue.length} tone={overdue.length ? 'bad' : undefined} />
          <Kpi label="Bloqueadas" value={blocked.length} tone={blocked.length ? 'bad' : undefined} hint={`${review.length} en revisión`} />
          <Kpi
            label="Kickoff"
            value={kickoffIn === null ? '—' : kickoffIn > 0 ? `${kickoffIn} d` : 'en curso'}
            hint={formatDate(project.kickoffDate, true)}
            className="col-span-2 lg:col-span-1"
          />
        </section>

        <div className="grid gap-8 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
          <Panel title="Tareas prioritarias" href="/tareas?vista=vencimiento">
            {priority.length === 0 ? (
              <Empty>No hay tareas críticas, bloqueadas ni vencidas.</Empty>
            ) : (
              <ul className="divide-y">
                {priority.map((t) => (
                  <li key={t.id} className="flex items-center gap-3 py-2.5">
                    <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                      <span className="flex items-center gap-2 truncate text-sm font-medium">
                        <span className="truncate">{t.title}</span>
                        {t.isDemo && <DemoBadge />}
                      </span>
                      <span className="truncate text-xs text-muted-foreground">
                        {t.ownerName ?? 'Sin asignar'} · {t.subsystemName ?? 'General'}
                      </span>
                    </div>
                    <PriorityTag priority={t.priority} />
                    <StatusBadge status={t.status} />
                    <span className={`w-14 text-right font-mono text-xs ${isOverdue(t.dueDate, t.status) ? 'text-destructive' : 'text-muted-foreground'}`}>
                      {formatDate(t.dueDate)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel title="Próximos hitos" href="/planificacion">
            {milestones.length === 0 ? (
              <Empty>No hay hitos pendientes.</Empty>
            ) : (
              <ul className="flex flex-col gap-3">
                {milestones.map((m) => (
                  <li key={m.id} className="flex flex-col gap-1.5">
                    <div className="flex items-baseline justify-between gap-3">
                      <span className="truncate text-sm font-medium">{m.title}</span>
                      <span className="shrink-0 font-mono text-xs text-muted-foreground">{formatDate(m.dueDate)}</span>
                    </div>
                    <span className="truncate text-xs text-muted-foreground">
                      {m.phaseName}
                      {m.status === 'en_riesgo' && <span className="text-destructive"> · en riesgo</span>}
                    </span>
                    <ProgressBar value={m.progress} label={`Avance de ${m.title}`} />
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <Panel title="Avance por subsistema">
            <ul className="flex flex-col gap-3">
              {groupProgress.map((g) => (
                <li key={g.id} className="flex flex-col gap-1">
                  <div className="flex justify-between text-sm">
                    <span>{g.name}</span>
                    <span className="font-mono text-xs text-muted-foreground">{g.count} tareas</span>
                  </div>
                  <ProgressBar value={g.progress} label={`Avance de ${g.name}`} />
                </li>
              ))}
            </ul>
          </Panel>

          <Panel title="Fases" href="/planificacion?vista=fases">
            <ul className="flex flex-col gap-2">
              {phases.slice(0, 7).map((p) => {
                const current = p.plannedStart && p.plannedEnd && p.plannedStart <= today && today <= p.plannedEnd
                return (
                  <li key={p.id} className="grid grid-cols-[1.5rem_1fr_5.5rem] items-center gap-2 text-sm">
                    <span className="font-mono text-xs text-muted-foreground">{String(p.sort).padStart(2, '0')}</span>
                    <span className={`truncate ${current ? 'font-medium text-primary' : ''}`}>{p.name}</span>
                    <ProgressBar value={p.progress} label={`Avance de ${p.name}`} />
                  </li>
                )
              })}
            </ul>
          </Panel>

          <Panel title="Actividad reciente" href="/actividad">
            {audit.length === 0 ? (
              <Empty>Todavía no hay movimientos.</Empty>
            ) : (
              <ol className="flex flex-col gap-2.5">
                {audit.map((a) => (
                  <li key={a.id} className="flex flex-col text-sm">
                    <span className="text-pretty">
                      <span className="font-medium">{a.actorName}</span> <span className="text-muted-foreground">{a.summary}</span>
                    </span>
                    <span className="font-mono text-xs text-muted-foreground">{formatDateTime(a.createdAt)}</span>
                  </li>
                ))}
              </ol>
            )}
          </Panel>
        </div>

        {loads.length > 0 && (
          <Panel title="Sobrecarga del equipo" href="/equipo">
            <ul className="flex flex-wrap gap-2">
              {loads.map((l) => (
                <li key={l.m.id} className="rounded-md border border-destructive/30 bg-destructive/5 px-2.5 py-1 text-sm">
                  {l.m.fullName} <span className="font-mono text-xs text-destructive">{l.open} abiertas · {l.critical} críticas</span>
                </li>
              ))}
            </ul>
          </Panel>
        )}

        {ctx.memberId === null && ctx.role !== 'admin' && (
          <p className="text-sm text-muted-foreground">
            Tu cuenta todavía no está vinculada a un integrante del equipo. Pedile a un profesor que la vincule desde Equipo.
          </p>
        )}
      </div>
    </>
  )
}

function Kpi({
  label,
  value,
  hint,
  tone,
  className,
}: {
  label: string
  value: React.ReactNode
  hint?: string
  tone?: 'bad'
  className?: string
}) {
  return (
    <div className={`flex flex-col gap-1 bg-card px-4 py-4 ${className ?? ''}`}>
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`font-mono text-2xl font-semibold tabular-nums ${tone === 'bad' ? 'text-destructive' : ''}`}>{value}</span>
      {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
    </div>
  )
}

function Panel({ title, href, children }: { title: string; href?: string; children: React.ReactNode }) {
  return (
    <section className="flex min-w-0 flex-col gap-3">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold">{title}</h2>
        {href && (
          <Link href={href} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
            Ver todo <ArrowRight className="size-3" aria-hidden />
          </Link>
        )}
      </div>
      {children}
    </section>
  )
}

function Empty({ children }: { children: React.ReactNode }) {
  return <p className="rounded-md border border-dashed px-3 py-6 text-center text-sm text-muted-foreground">{children}</p>
}
