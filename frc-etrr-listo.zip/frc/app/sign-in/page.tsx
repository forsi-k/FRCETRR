import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { ensureAdmins } from '@/lib/seed-admins'
import { SignInForm } from '@/components/sign-in-form'

export default async function SignInPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect('/')
  await ensureAdmins()
  return <SignInForm />
}
